<?php echo $seguimiento;?>
<form action="/index.html" method="post">           
    <input type="submit" value="reiniciar">
</form>