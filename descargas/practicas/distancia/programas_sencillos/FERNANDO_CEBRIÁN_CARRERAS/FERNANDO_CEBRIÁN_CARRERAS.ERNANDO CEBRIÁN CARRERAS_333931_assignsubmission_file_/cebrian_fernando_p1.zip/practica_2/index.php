<!DOCTYPE html>
 
<html>
<head>
    <meta charset="UTF-8">
    <title></title>
</head>
<body>
<?php 
//Defino dos variables con mi nombre y apellidos
$nombre="Fernando";
$apellidos="Cebrián Carreras";

echo "<h1>Práctica 2. Probando instrucciones de php</h1>";

//Visualizo el texto con echo y print, por ejemplo en mi caso (deben de aparecer las comillas del ejemplo
// mi nombre es "Manuel" y mi apellido es "Romero"
 
//1)con echo pasando varios argumentos (separadados por coma)
echo "1. Mi nombre es \"$nombre\"", " y mis apellidos \"$apellidos\"<br />";
 
//2)con print
print "2. Mi nombre es \"$nombre\" y mis apellidos \"$apellidos\"<br />";
 
//3,4 y 5)Explica en el fichero diferencias entre echo y print y semejanzas.
echo "3. echo imprime cadenas de caracteres como parámetros, uno o más<br />";
echo "4. print sólo puede imprimer un parámetro y devuelve un valor al ejecutarse<br />";
echo "5. echo y print tienen la misma funcionalidad y uso, la impresión por pantalla<br />";
 
//6) Indica Por qué puedes pasar los argumentos sin usar paréntesis
echo "6. echo y print pueden usarse con paréntesis y sin paréntesis porque son constructores del lenguaje no funciones predefinidas<br />"; 
 
/*7) Sintaxis heredoc,*/
//Asigna a una variable llamada informe un texto de cinco líneas,
//la etiqueta de finalización es FIN
//Posteriormente visualizas el texto
// El contenido de 'informe' es:
//   ........
// aquí aparecer el contenido del informe
// debe de respetarse el número de 5 líneas asignadas previamente";
//Tener cuidado con que la etiqueta no lleve en esa línea ningún otro carácter (espacios en blanco o tabulacones)
$informe=<<<FIN
<pre>7. Este es un informe que tiene cinco líneas
esta es la primera
a continuación va la segunda
la tercera ya en el medio
la cuarta que es la penúltima
y la última la quinta</pre>    
FIN;
echo $informe;
 
/*PROBANDO VARIABLES (del 8 al 19)*/
//Crea una variable y asígnale un valor
$a=25; 
//visualiza el valor de la variable y el tipo que eś
echo "8. El valor de la variable \$a es ".$a."<br />"." 9. Es es de tipo ". gettype($a)."<br />";
 
//Cambia la variable a los siguientes tipos :boolean, float, string y null,  y visualizar su valor y tipo 
$a=true; 
echo "10. Ahora, el valor de la variable \$a es TRUE (".$a.")<br />"." 11. Es de tipo ". gettype($a)."<br />";
$a=-1.36; 
echo "12. Ahora, el valor de la variable \$a es ".$a."<br />"." 13. Es de tipo ". gettype($a)."<br />";
$a="\"Hola profesor :-)\""; 
echo "14. Ahora, el valor de la variable \$a es ".$a."<br />"." 15. Es de tipo ". gettype($a)."<br />";
$a=null; 
echo "16. Y finalmente, el valor de la variable \$a es NULL".$a."<br />"." 17. Ees de tipo ". gettype($a)."<br />";
 
//Prueba a ver el valor y tipo de una variable no definida previamente
echo "18. La variable \$b no está definida. Su valor es: ".$b."(no muestra valor)"."<br />"; 
echo "19. Es de tipo ".$b."(no muestra valor)<br />";
 
/* 20)Visualiza el código ascii del valor 64 al 122 en carácter usando la función ascii  .. puedes usar la función printf o  bien char() ..*/
echo "20. Códigos ASCII de los carácteres del 64 al 122:<br />";
for($a=64;$a<=122;$a++){
    $valor= chr($a);
    echo $a."=".$valor." ";   
}
 
//21)Visualiza el contenido de la función time() y explica su valor
echo "<br />21. El contenido de la función time() es: ".time(). ", un valor que corresponde al número de segundos transcurridos desde la fecha de 01/01/1970.";
 
//22)Obtén la fecha actual y visualiza su valor con formato dia-mes-año en número usa la función date() para ello
echo "<br />22. La fecha actual es: ".date(d)."-".date(m)."-".date(Y);
 
//23,24,y 25)Obtener los días, luego horas y luego minutos transcurridos desde el 1/1/1970 (round() o floor() para redondear
echo "<br />23. Días pasados desde la fecha 01/01/1970: ".(round(time()/86400))." días";
echo "<br />24. Horas pasadas desde la fecha 01/01/1970: ".(round(time()/86400)*24)." horas";
echo "<br />25. Minutos pasados desde la fecha 01/01/1970: ".(round(time()/86400)*1440)." minutos";

//Usando la función setlocale(...) y strftime(...)
//Puede ser que tengas que habilitar el idioma en el sistema con locale-gen
//26)  Obtén la fecha actual con formato por ejemplo domingo, 28 de octubre de 2018
setlocale(LC_ALL, 'es_ES.utf8');
echo strftime("<br />26. La fecha actual en castellano es: %A".", "." %d "."de "."%B "."de "."%Y");

//27)  Ahora con formato en inglés  Sunday, 28 October 2018
setlocale(LC_TIME, 'en_IN.utf8');
echo strftime("<br />27. La fecha actual en ingles es: %A".", "." %d "."%B "."%Y");

//28) y con formato en francés  dimanche, 28 octobre 2018
//Lo he instalado con sudo locale-gen fr_FR.utf8
setlocale(LC_TIME, 'fr_FR.utf8');
echo strftime("<br />28. La fecha actual en francés es: %A".", "." %d %B %Y<br />");
 
// 29-30)Asigna a una variable la fecha de tu cumpleaños
// Realiza una operación y obtén tu edad en años, meses y días (valor entero).
// tienes 23 años, 10 meses y 4 días
$micumple=mktime(0, 0, 0, 2, 22, 1980);
echo "29. La fecha actual es: ".date(d)."-".date(m)."-".date(Y)." y mi fecha de nacimiento es: ".date("d-m-Y",$micumple);
echo "<br />30. Por tanto, tengo ".((date(Y))-(date("Y",$micumple)))." años, ".((date(m))-(date("m",$micumple)))." meses y ".(abs((date(d))-(date("d",$micumple))))." días";
 
//31-32)Asigna a una variable una fecha de 30/10/1969 (mira las funciones strtotime() o bien mktime() para ello
// Obtén su edad en años, en meses y luego en días siempre redondeando
// tienes xx años
// tienes xx meses
// tienes xx días
$sufecha=mktime(0, 0, 0, 10, 30, 1969);
echo "<br />31. La fecha actual es: ".date(d)."-".date(m)."-".date(Y)." y su fecha de nacimiento es: ".date("d-m-Y",$sufecha);
echo "<br />32. Por tanto, tiene ".((date(Y))-(date("Y",$sufecha)))." años, ".((date(m))-(date("m",$sufecha)))." meses y ".(abs((date(d))-(date("d",$sufecha))))." días<br />";
 
//33-36). Usa la función getdate(...) y visualiza con la función print_r(.) el valor que retorna, comenta el resultado
echo "33. ";
print_r (getdate(time()));
echo "<br />34. Esto es el resultado de usar getdate(time()) y significa obtener un array con los valores de dia,mes,año,hora, etc. del momento de ejecutarlo  ";
//. Si escribo getdate(1) podrías explicar el contenido del array que nos retorna
echo "<br />35. ";
print_r (getdate(1)); 
echo "<br />36. Esto es el resultado de usar getdate(1) y significa obtener un array con los valores del dia,mes,año,hora, etc. de la fecha 01/01/1970 ";
//. Obtener la edad de una persona nacida el 1/1/1969
$suedad=mktime(0, 0, 0, 1, 1, 1969);
echo "<br />37. Una persona nacida el 1/1/1969, actualmente tiene ".((date(Y))-(date("Y",$suedad)))." años";

//38-65)Explica el siguiente código observando el resultado que se produce fuente obtenido en parte de http://php.net/manual/es/function.strtotime.php
echo "<hr>";
echo "<br />38. strtotime(\"now\")= ".strtotime("now"), "<br/>";
echo "39. Devuelve un entero con los segundos pasados desde la fecha 01/01/2970 hasta la marca de tiempo ahora";

echo "<br /><br />40. date('d-m-Y', strtotime(\"now\"))= ".date('d-m-Y', strtotime("now")), "<br/>";
echo "41. Devuelve el valor en entero por separado de día, mes y año, de la fecha obtenida en fecha Unix de la función anterior, en string";

echo "<br /><br />42. strtotime(\"27 September 1970\")= ". strtotime("27 September 1970"), "<br/>";
echo "43. Devuelve un entero con los segundos pasados desde la fecha 01/01/2970 hasta la fecha 27/09/1970";

echo "<br /><br />44. date('d-m-Y',strtotime(\"10 September 2000\"))= ".date('d-m-Y',strtotime("10 September 2000")), "<br/>";
echo "45. Devuelve el valor en entero por separado de día, mes y año, de la fecha obtenida en fecha Unix de la fecha pasada en string ";

echo "<br /><br />46. strtotime(\"+1 day\")= ".strtotime("+1 day"), "<br/>";
echo "47. Devuelve un entero con los segundos pasados desde la fecha 01/01/2970 hasta la fecha un día más al actual";

echo "<br /><br />48. date('d-m-Y',strtotime(\"+1 day\"))= ".date('d-m-Y',strtotime("+1 day")), "<br/>";
echo "49. Devuelve el valor en entero por separado de día, mes y año, de la fecha Unix obtenida de la fecha pasada en string, un días más al actual ";

echo "<br /><br />50. strtotime(\"+1 week\")= ".strtotime("+1 week"), "<br/>";
echo "51. Devuelve un entero con los segundos pasados desde la fecha 01/01/2970 hasta la fecha una semana más a la actual";

echo "<br /><br />52. date('d-m-Y',strtotime(\"+1 week\))= ".date('d-m-Y',strtotime("+1 week")), "<br/>";
echo "53. Devuelve el valor en entero por separado de día, mes y año, de la fecha Unix obtenida de la fecha pasada en string, una semana más a la actual ";

echo "<br /><br />54. strtotime(\"+1 week 2 days 4 hours 2 seconds\")= ".strtotime("+1 week 2 days 4 hours 2 seconds"), "<br/>";
echo "55. Devuelve un entero con los segundos pasados desde la fecha 01/01/2970 hasta la fecha una semana, dos días, 4 horas y 3 segundos más a la actual";

echo "<br /><br />56. date('d-m-Y',strtotime(\"+1 week 2 days 4 hours 2 seconds\"))= ".date('d-m-Y',strtotime("+1 week 2 days 4 hours 2 seconds")), "<br/>";
echo "57. Devuelve el valor en entero por separado de día, mes y año, de la fecha Unix obtenida de la fecha pasada en string, una semana, dos días, 4 horas y 3 segundos más a la actual";

echo "<br /><br />58. strtotime(\"next Thursday\")= ".strtotime("next Thursday"), "<br/>";
echo "59. Devuelve un entero con los segundos pasados desde la fecha 01/01/2970 hasta la fecha del próximo jueves";

echo "<br /><br />60. date('d-m-Y',strtotime(\"next Thursday\"))= ".date('d-m-Y',strtotime("next Thursday")), "<br/>";
echo "61. Devuelve el valor en entero por separado de día, mes y año, de la fecha Unix obtenida de la fecha pasada en string, el próximo jueves";

echo "<br /><br />62. strtotime(\"last Monday\")= ".strtotime("last Monday"), "<br/>";
echo "63. Devuelve un entero con los segundos pasados desde la fecha 01/01/2970 hasta la fecha del último lunes";

echo "<br /><br />64. date('d-m-Y',strtotime(\"last Monday\"))= ".date('d-m-Y',strtotime("last Monday")), "<br/>";
echo "65. Devuelve el valor en entero por separado de día, mes y año, de la fecha Unix obtenida de la fecha pasada en string, el último lunes";

echo "<hr>";
?>
 
</body>
</html>