<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
    <?php
        header("refresh:5;url=index.php");  //función que devuelve a index despues de 5 segundos
        $a=267;
        $b=0252;
        $c=0xbADA14;
        $d=0b0010;
        $e="\"Mi nombre es Fernando Cebrián\"";
        $f="'Mi nombre es Fernando Cebrián'";
        $g=<<<FINAL
        <pre>
        Esto es un ejemplo
        de texto con multilinea
        y termina aquí</pre>        
        FINAL;
        $h=<<<FINAL
        <pre>
             Segundo ejemplo
        de texto multilinea
        y termina aquí</pre>       
        FINAL;
        $i=3.125896584258965882447852;
        $j=14785E3;
        $k=null;
        $l=true;
        $m=true; 
        print "<h1>Variables en PHP</h1>";
        print $a."<br />";
        print $b."<br />";
        print $c."<br />";
        print $d."<br />";
        print $e."<br />";
        print $f."<br />";
        print $g."<br />";
        print $h."<br />";
        print $i."<br />";
        print $j."<br />";
        print $k."<br />";  //No se muestra al ser null
        print $l."<br />";
        print $m."<br />";
    ?>      
    </body>
</html>



