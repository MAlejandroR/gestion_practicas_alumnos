<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
    <?php
    header("refresh:2;url=index.php");  //función que devuelve a index despues de 2 segundos
    const MIEDAD=39;
    echo "<h1>Constantes en PHP</h1>";
    echo "Mi edad actual es: ".MIEDAD." años<br />";
    echo "Me quedan ".(100-MIEDAD)." años para cumplir los 100 años";
    ?>      
    </body>
</html>
