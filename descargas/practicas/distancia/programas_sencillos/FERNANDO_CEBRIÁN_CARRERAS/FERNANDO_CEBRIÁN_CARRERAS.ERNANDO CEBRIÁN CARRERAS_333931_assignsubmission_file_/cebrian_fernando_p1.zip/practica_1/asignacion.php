<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
    <?php
    header("refresh:5;url=index.php");  //función que devuelve a index despues de 5 segundos
    echo "<h1>Asignación en PHP</h1>";
    $v=null;  //Variable que cambiará su valor 
    const A=8; $v=A;  
    echo "Valor constante numérica: ".$v;
    const B="Fernando"; $v=B; 
    echo "<br />Valor constante string: ".$v;
    const C=0xbADA14; $v=C; 
    echo "<br />Valor constante numérica en hexadecimal: ".dechex($v);
    const D=0b1110; $v=D;
    echo "<br />Valor constante numérica en binario: ".decbin($v);
    $v=4*5;
    echo "<br />Valor de una expresión numérica (4*5): ".$v;
    $v="Soy Fernando".", alumno de DWES";
    echo "<br />Valor de una expresión de cadena de caracteres: ".$v;
    $v=print "";
    echo "<br />Valor devuelto por la función print: ".$v;
    $v=($v=11);
    echo "<br />Valor de una expresión de asignación: ".$v;
    ?>
    </body>
</html>
