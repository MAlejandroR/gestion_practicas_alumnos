<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
    <?php
    echo "<h1>Funciones en PHP</h1>";
    $valor1=10;
    $valor2=7;
    echo "Los valores de las dos variables antes de llamar a la función son: ".$valor1." y ".$valor2;    
    function muestra_valores(&$a,$b){   
        echo "<br />Los valores sin modificar dentro de la función son: ".$a." y ".$b; 
        $a=$a*2; 
        $b=$b*2;
        echo "<br />Los valores duplicados dentro de la función son: ".$a." y ".$b; 
        if($a>$b){
            return $a;   //Si a es mayor que b, devuelve a
        }else {
            return $b;  //Si no, es que b es mayor o igual, devuelve b
        }
    }
    $valor_mayor=muestra_valores($valor1,$valor2);
    echo "<br />El valor mayor de las dos variables duplicadas es: ".$valor_mayor;
    echo "<br />Los valores iniciales de las dos variables ahora son: ".$valor1." y ".$valor2." (El primer valor se ha duplicado por haberse pasado por referencia)"; 
    echo "<br /><br /><a href=\"index.php\">Volver a página principal</a>"
    ?>
    </body>
</html>

