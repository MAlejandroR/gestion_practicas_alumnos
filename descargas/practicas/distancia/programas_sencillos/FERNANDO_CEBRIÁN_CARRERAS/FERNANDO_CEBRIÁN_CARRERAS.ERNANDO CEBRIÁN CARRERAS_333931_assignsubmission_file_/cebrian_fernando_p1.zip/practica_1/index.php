<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <h1>Práctica 1. Programas de prueba en PHP</h1>
        <blockquote><a href="variables.php">1. Variables en PHP</a><br />
        <a href="constantes.php">2. Constantes en PHP</a><br />
        <a href="asignacion.php">3. Asignacion en PHP</a><br />
        <a href="seleccion.php">4. Seleccion en PHP</a><br />
        <a href="operador_ternario.php">5. Operador Ternario en PHP</a><br />
        <a href="iteraciones.php">6. Iteraciones en PHP</a><br />
        <a href="funciones.php">7. Funciones en PHP</a></blockquote>
    </body>
</html>
