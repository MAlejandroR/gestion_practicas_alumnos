<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
    <?php
    header("refresh:2;url=index.php");  //función que devuelve a index despues de 2 segundos
    echo "<h1>Operador ternario en PHP</h1>";
    $a=rand(1,1000);
    echo "Valor generado: ".$a."<br />";
    (($a)%2==0)? $a="El número es par": $a="El número es impar";
    echo $a;
    ?>
    </body>
</html>

