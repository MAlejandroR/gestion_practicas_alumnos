<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
    <?php
    header("refresh:2;url=index.php");  //función que devuelve a index despues de 2 segundos
    echo "<h1>Selección en PHP</h1>";
    $a=rand(1,150);
    echo "La edad generada es: ".$a."<br />";
    switch($a){
        case ($a<=11): echo "Pertenece a los niños";
        break;
        case ($a>=12&&$a<=17): echo "Pertenece a los adolescentes";
        break;
        case ($a>=18&&$a<=35): echo "Pertenece a los jóvenes";
        break;
        case ($a>=36&&$a<=65): echo "Pertenece a los adultos";
        break;
        case ($a>=66&&$a<=110): echo "Pertenece a los jubilados";
        break;
        default: echo "Edad no contemplada en nuestra encuesta";
    }
    ?>
    </body>
</html>