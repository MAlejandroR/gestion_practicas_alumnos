<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
    <?php
    header("refresh:2;url=index.php");  //función que devuelve a index despues de 2 segundos
    echo "<h1>Iteraciones en PHP</h1>";
    $suma=0;  //Guarda el valor de la suma de los pares encontrados
    $a=0;  //lleva el conteo de numero de pares encontrados
    $b=1;  //los numeros recorridos que comprueba si son pares. 
    while($a<100){  //Hace un bule hasta que el número de pares es 100
        if(($b%2)==0){ //ha encontrado un par, lo suma
            $suma=$suma+$b;
            $a++;  
        }
        $b++;
    }
    echo "La suma de los primeros 100 valores pares es: ".$suma;
    ?>
    </body>
</html>

