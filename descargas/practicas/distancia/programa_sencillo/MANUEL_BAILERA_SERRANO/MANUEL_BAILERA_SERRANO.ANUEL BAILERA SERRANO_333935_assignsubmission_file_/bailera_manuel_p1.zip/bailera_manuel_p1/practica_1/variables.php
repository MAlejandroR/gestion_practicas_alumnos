<!DOCTYPE html>
 
<html lang="es">
	<head>
		<title>Práctica 1</title>
		<meta charset="utf-8" />
		<link rel="stylesheet" href="./css/estilo.css" />
	</head>
<body>
    <header>
       <h1><a href="./">Programas básicos de pruebas</a></h1>
    </header>
	<aside>
		<ul>
			<li><a href="./variables.php">Variables en php</a></li>
			<li><a href="./constantes.php">Constantes en php</a></li>
			<li><a href="./asignacion.php">Asignación en php</a></li>
			<li><a href="./seleccion.php">Selección en php</a></li>
			<li><a href="./ternario.php">Operador Ternario en php</a></li>
			<li><a href="./iteraciones.php">Iteraciones en php</a></li>
			<li><a href="./funciones.php">Funciones </a></li>
		</ul>
	</aside>
	<main>
		<h2>Declaración de variables</h2>
		<p>Este programa asigna valores a variables y luego los muestra.</p>
		<p>Se vuelve al index automáticamente después de 5 segundos*</p>
        <hr/>
		
		<?php

		// 357; 
			print "<h3>\$v = 357;</h3>";
			$v = 357;
			print "<p class='resultado'>Variable decimal, valor <span>" . $v . "</span></p>";

		// 0874;
		// 0874 produce un error, ya que el 8,no es un dígito o guarismo correcto como valor en una sistema octal, lo cambio por 0774
			print "<h3>\$v = 0774;</h3>";
			$v = 0774;
			printf("<p class='resultado'>Variable octal, valor decimal <span>%u</span> y octal <span>%o</span></p>", $v, $v);

		// 0xAbC34;
			print "<h3>\$v = 0xAbC34;</h3>";
			$v = 0xAbC34;
			printf("<p class='resultado'>Variable hexadecimal, valor decimal <span>%u</span> y hexadecimal <span>%x</span></p>", $v, $v);

		// 0b111;
			print "<h3>\$v = 0b111;</h3>";
			$v = 0b111;
			printf("<p class='resultado'>Variable binaria, valor decimal <span>%u</span> y binario <span>%b</span></p>", $v, $v);

		// "Cadena de caracteres con comillas dobles";
			print "<h3>\$v = \"Cadena de caracteres con comillas dobles\";</h3>";
			$v = "Cadena de caracteres con comillas dobles";
			print "<p class='resultado'>Variable string, valor <span>" . $v . "</span></p>";

		//'Cadena de caracteres con comillas simples';
			print "<h3>\$v = 'Cadena de caracteres con comillas simples';</h3>";
			$v = 'Cadena de caracteres con comillas simples';
			print "<p class='resultado'>Variable string, valor <span>" . $v . "</span></p>";

		/*  
			Texto dividido 
			en 
			varias líneas
		*/

			print "<h3>\$v=<<< FIN <pre>Texto 
dividido
en varias líneas</pre> FIN;</h3>";

			$v = <<<FIN
			Texto dividido 
			en 
			varias líneas
FIN;
			print "<p class='resultado'>Variable string, valor <span>" . $v . "</span></p>";

		/*
			<pre>
			Texto dividido 
			en 
			varias líneas, 
			preformateado
			</pre>
		*/

		print "<h3>\$v=<<< FIN <br /> &lt;pre&gt;<pre>
Texto dividido 
en 
varias líneas, 
preformateado</pre>&lt;/pre&gt; <br />FIN;</h3>";
		
			$v = <<<FIN
			<pre class='resultado'>
Texto dividido 
en 
varias líneas, 
preformateado</pre>
FIN;
			print "<p class='resultado'>Variable string, valor <span>" . $v . "</span></p>";
   
		// 7.598759032101257;
			print "<h3>\$v = 7.598759032101257;</h3>";
			$v = 7.598759032101257;
			printf("<p class='resultado'>Variable float, valor <span>%.15f</span> y en notación científica <span>%e</span></p>", $v, $v);

		// 2568E-1;
			print "<h3>\$v = 2568E-1;</h3>";
			$v = 2568E-1;
			printf("<p class='resultado'>Variable float, valor <span>%.2f</span> y en notación científica <span>%e</span></p>", $v, $v);
		
		// null;
			print "<h3>\$v = null;</h3>";
			$v = null;
			print "<p class='resultado'>Variable null, valor \" <span>" . $v . "</span>\" y en string es <span>" .(($v == null) ? 'null' : $v) . "</span>";

		// true;
			print "<h3>\$v = true;</h3>";
			$v = true;
			print "<p class='resultado'>Variable boolean, valor <span>" . $v . "</span> y en string es <span>" . (boolval($v) ? 'true' : 'false') . "</span>";
		
        // false;
			print "<h3>\$v = false;</h3>";
			$v = false;
			print "<p class='resultado'>Variable null, valor \" <span>" . $v . "</span>\" y en string es <span>" . (boolval($v) ? 'true' : 'false') . "</span>";
			
		
		
		// Volver al index después de 5 segundos 
		header('refresh: 5; url = ./');  

		?>

	</main>
    <footer>
        <p>Manuel Bailera Serrano</p>
    </footer>
</body>
</html>