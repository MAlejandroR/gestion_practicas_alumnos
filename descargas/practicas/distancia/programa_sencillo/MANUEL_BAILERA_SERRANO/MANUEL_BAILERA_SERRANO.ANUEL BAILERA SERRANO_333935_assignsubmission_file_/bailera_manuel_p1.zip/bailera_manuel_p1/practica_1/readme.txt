En el ejercicio de iteraciones, la solución es 10100. 
La solución propuesta en http://manuel.infenlaces.com/distancia/practicas/practica_1/iteraciones.php, 2450, no es correcta.

En el ejercicio de funciones no se indica, que se deba volver al index usando la función header. 
Pienso que es un error, puesto que el resto de ejercicios la incluyen. Por este motivo, incluyo la función para que vuelva al index después de 10 segundos.