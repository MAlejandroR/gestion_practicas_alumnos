<!DOCTYPE html>
 
<html lang="es">
	<head>
		<title>Práctica 2</title>
		<meta charset="utf-8" />
		<link rel="stylesheet" href="./css/estilo.css" />
	</head>
<body>
<h1>Práctica 2</h1>
<?php

//Defino dos variables con mi nombre y apellidos
$nombre = "Manuel";
$apellidos = "Bailera Serrano";
 
// Visualizo el texto con echo y print, por ejemplo en mi caso (deben de aparecer las comillas del ejemplo)
// mi nombre es "Manuel" y mi apellido es "Romero"
// 1) con echo pasando varios argumentos (separadados por coma)
echo "1. Mi nombre es ", "\"$nombre\"", " y mis apellidos son ", "\"$apellidos\"", "<br />";
//2) con print
print "2. Mi nombre es \"$nombre\" y mis apellidos son \"$apellidos\"<br />";
echo "<hr/>";
//3,4 y 5) Explica en el fichero diferencias entre echo y print y semejanzas.
echo "3. echo imprime una cadena como argumentos. Si no se utilizan paréntesis, se puede pasar más de un argumento.<br />";
echo "4. print acepta solamente un argumento. Al evaluar la expresión devuelve un valor booleano (true o false), indicando si ha podido completarse su ejecución con éxito.<br />";
echo "5. Ambas construcciones se utilizan para mostrar una salida de caracteres.<br />";
//6) Indica Por qué puedes pasar los argumentos sin usar paréntesis
echo "6. print y echo no son funciones sino construcciones del lenguaje (como también lo son, por ejemplo, 'if', 'while', ...). Por este motivo pueden usarse con o sin paréntesis.<br />";
echo "<hr/>";

//7) Sintaxis heredoc,
//Asigna a una variable llamada informe un texto de cinco líneas,
//la etiqueta de finalización es FIN
//Posteriormente visualizas el texto
// El contenido de 'informe' es:
//   ........
// aquí aparecer el contenido del informe
// debe de respetarse el número de 5 líneas asignadas previamente";
//Tener cuidado con que la etiqueta no lleve en esa línea ningún otro carácter (espacios en blanco o tabulacones)

echo "7. El contenido del informe es:<br />";

$informe = <<<FIN
<pre>
Este es el contenido del informe, línea 1
esta sería la línea 2
esta sería la línea 3
esta sería la línea 4
esta sería la línea 5</pre>
FIN;

echo $informe;

echo "<hr/>";

/*PROBANDO VARIABLES (del 8 al 19)*/
//Crea una variable y asígnale un valor
$mi_variable = 256;
 
//visualiza el valor de la variable y el tipo que 
print "8 - 9. <b>\$mi_variable = " . $mi_variable . "</b>, variable de tipo " . gettype($mi_variable) . "<br />";
 
//Cambia la variable a los siguientes tipos: boolean, float, string y null, y visualizar su valor y tipo 

// settype ($mi_variable, float);

$mi_variable = true;
print "10 - 11. <b>\$mi_variable = " . $mi_variable . "</b>, variable de tipo " . gettype($mi_variable) . "<br />";

$mi_variable = 3.1416;
print "12 - 13. <b>\$mi_variable = " . $mi_variable . "</b>, variable de tipo " . gettype($mi_variable) . "<br />";

$mi_variable = "Un valor de tipo string";
print "14 - 15. <b>\$mi_variable = " . $mi_variable . "</b>, variable de tipo " . gettype($mi_variable) . "<br />";

$mi_variable = null;
print "16 - 17. <b>\$mi_variable = " . $mi_variable . "</b>, variable de tipo " . gettype($mi_variable) . "<br />";
 
//Prueba a ver el valor y tipo de una variable no definida previamente
print "18 - 19. Variable no definida previamente <b>\$sin_definir = " . $sin_definir . "</b>, variable de tipo " . gettype($sin_definir) . "<br />";

echo "<hr/>";
echo "20. Caracteres ascii del valor 64 al 122";
/* 20)Visualiza el código ascii del valor 64 al 122 en carácter usando la función ascii  
.. puedes usar la función printf o  bien char() ..*/

echo "<p style = 'columns: 6'>";

for ($caracter = 64; $caracter < 123; $caracter++) {
	printf ("Caracter %d: %c<br />", $caracter, $caracter);
	/* Otra opción sería:
	echo "Caracter $caracter:", chr($caracter), "<br />";
	*/
}

echo "</p>";
echo "<hr/>";

//21)Visualiza el contenido de la función time() y explica su valor
echo "21. Valor de la funcion time(): " . time() . "<br />";
echo "Esta función devuelve la fecha Unix actual, el número de segundos transcurridos desde el 01-11-1970 a las 00:00 h<br />";

//22)Obtén la fecha actual y visualiza su valor con formato dia-mes-año en número usa la función date() para ello
echo "22. Fecha actual. Resultado de la funcion date(\"d-m-Y\"): " . date("d-m-Y") . "<br />";

//23,24,y 25)Obtener los días, luego horas y luego minutos transcurridos desde el 1/1/1970 (round() o floor() para redondear
echo "23. Días transcurridos desde el 1/1/1970: " . floor(time()/(60*60*24)) . "<br />";
echo "24. Horas transcurridas desde el 1/1/1970: " . floor(time()/(60*60)) . "<br />";
echo "25. Minutos transcurridos desde el 1/1/1970: " . floor(time()/60) . "<br />";
echo "<hr/>";

 
//Usando la función setlocale(...) y strftime(...)
//Puede ser que tengas que habilitar el idioma en el sistema con locale-gen

//26)  Obtén la fecha actual con formato por ejemplo domingo, 28 de octubre de 2018
echo "26. Fecha con formato español: ";
setlocale (LC_TIME, "es_ES.utf-8");
echo strftime("%A, %d de %B de %Y", time()).'<br/>';

//27)  Ahora con formato en inglés  Sunday, 28 October 2018
echo "27. Fecha con formato inglés: ";
setlocale (LC_TIME, "en_GB.utf-8");
echo strftime("%A, %d %B %Y", time()).'<br/>';

//28) y con formato en francés  dimanche, 28 octobre 2018
echo "28. Fecha con formato francés: ";
setlocale (LC_TIME, "fr_FR.utf-8");
echo strftime("%A, %d %B %Y", time()).'<br/>';

echo "<hr/>";
 
// 29-30)Asigna a una variable la fecha de tu cumpleaños
// Realiza una operación y obtén tu edad en años, meses y días (valor entero).
// tienes 23 años, 10 meses y 4 días
setlocale (LC_TIME, "es_ES.utf-8");

echo "29. Mi fecha de nacimiento: ";
$fecha = strtotime("now");
$cumple = "11-11-1980"; // 11 de noviembre de 1980
$cumple_t = strtotime($cumple);
echo $cumple . "<br/>";

$edad_segundos = $fecha - $cumple_t; // Edad en segundos
$edad = $edad_segundos/(60*60*24*365.25); // Edad en años, con decimales. +0.25 para compensar años bisiestos
$anyos = floor($edad);
$meses = floor(($edad - $anyos)*12);
$dias = floor(($edad - $anyos - $meses/12)*365.25); // +0.25 para compensar años bisiestos
echo "30. Tengo $anyos años, $meses meses y $dias días<br />";
echo "<hr/>";

//31-32)Asigna a una variable una fecha de 30/10/1969 (mira las funciones strtotime() o bien mktime() para ello
// Obtén su edad en años, en meses y luego en días siempre redondeando
echo "31. Fecha de nacimiento: ";
$fecha = strtotime("now");
$cumple = "30-10-1969"; // 30 de octubre de 1969
$cumple_t = strtotime($cumple);
echo $cumple . "<br/>";

$edad_segundos = $fecha - $cumple_t; // Edad en segundos
$edad = $edad_segundos/(60*60*24*365.25); // Edad en años, con decimales. +0.25 para compensar años bisiestos
$anyos = floor($edad);
$meses = floor(($edad - $anyos)*12);
$dias = floor(($edad - $anyos - $meses/12)*365.25); // +0.25 para compensar años bisiestos
echo "32. Tiene $anyos años, $meses meses y $dias días<br />";
echo "<hr/>";
 
//33-36). Usa la función getdate(...) y visualiza con la función print_r(.) el valor que retorna, comenta el resultado
$una_fecha = getdate();
echo "33. ";
print_r($una_fecha);
echo "<br />";
echo "34. getdate() retorna un array asociativo que contiene los datos de la fecha actual (segundos, minutos, horas, dia del mes, día de la semana, mes, año, día del año, día de la semana como texto, mes como texto, tiempo Unix en segundos) como elementos de dicho array. Al no haberle pasado parámetros, se obtiene la fecha actual.<br />La instrucción print_r utilizada aquí, se usa para imprimir datos en un formato legible para los humanos, es útil por ejemplo para imprimir arrays.";
echo "<hr/>";

//. Si escribo getdate(1) podrías explicar el contenido del array que nos retorna
$otra_fecha = getdate(1);
echo "35. ";
print_r($otra_fecha);
echo "<br />";
echo "36. getdate(1) devuelve un array asociativo que contiene los datos (segundos, minutos, horas, dia del mes, día de la semana, mes, año, día del año, día de la semana como texto, mes como texto, tiempo Unix en segundos) del Jueves, 1 de enero de 1970 a las 00:00:01 h (segundo 1 en tiempo Unix).<br />";
echo "<hr/>";

//. Obtener la edad de una persona nacida el 1/1/1969
echo "Edad de una persona nacida el 1 de enero 1969: ";
$fecha = strtotime("now");
$cumple = "01/01/1969"; // 1 de enero de 1969
$cumple_t = strtotime($cumple);

$edad_segundos = $fecha - $cumple_t; // Edad en segundos
$edad = $edad_segundos/(60*60*24*365.25); // Edad en años, con decimales. +0.25 para compensar años bisiestos
$anyos = floor($edad);
echo "$anyos años.<br />";
echo "<hr/>";

//37-64)Explica el siguiente código observando el resultado que se produce fuente obtenido en parte de http://php.net/manual/es/function.strtotime.php

echo "37. strtotime(\"now\"): ". strtotime("now") . "<br/>";
echo "38. Fecha Unix actual, el número de segundos transcurridos desde el 01-11-1970 a las 00:00 h<br /><hr />";
echo "39. date('d-m-Y', strtotime(\"now\")): ". date('d-m-Y', strtotime("now")) . "<br/>";
echo "40. Fecha actual en formato d-m-Y<br /><hr />";
echo "41. strtotime(\"27 September 1970\"): ". strtotime("27 September 1970") . "<br/>";
echo "42. Número de segundos transcurridos desde el 01-11-1970 a las 00:00 h hasta el 27 de septiembre de 1970.<br /><hr />";
echo "43. date('d-m-Y',strtotime(\"10 September 2000\")): ". date('d-m-Y',strtotime("10 September 2000")), "<br/>";
echo "44. Convierte una fecha proporcionada como string en una variable de tipo date con formato d-m-Y.<br /><hr />";
echo "45. strtotime(\"+1 day\"): ". strtotime("+1 day") . "<br/>";
echo "46. Suma un día a la fecha actual. Se devuelve un dato de tiempo Unix en segundos.<br /><hr />";
echo "47. date('d-m-Y', strtotime(\"+1 day\")): " . date('d-m-Y', strtotime("+1 day")) . "<br/>";
echo "48. Suma un día a la fecha actual. Se devuelve un dato en formato d-m-Y.<br /><hr />";
echo "49. strtotime(\"+1 week\"): ". strtotime("+1 week") . "<br/>";
echo "50. Suma una semana a la fecha actual. Se devuelve un dato de tiempo Unix en segundos.<br /><hr />";
echo "51. date('d-m-Y',strtotime(\"+1 week\")): ". date('d-m-Y',strtotime("+1 week")), "<br/>";
echo "52. Suma una semana a la fecha actual. Se devuelve un dato en formato d-m-Y.<br /><hr />";
echo "53. strtotime(\"+1 week 2 days 4 hours 2 seconds\"): ". strtotime("+1 week 2 days 4 hours 2 seconds") . "<br/>";
echo "54. Suma una semana, dos días, 4 horas y 2 segundos a la fecha actual. Se devuelve un dato de tiempo Unix en segundos.<br /><hr />";
echo "55. date('d-m-Y',strtotime(\"+1 week 2 days 4 hours 2 seconds\")): ". date('d-m-Y',strtotime("+1 week 2 days 4 hours 2 seconds")), "<br/>";
echo "56. Suma una semana, dos días, 4 horas y 2 segundos a la fecha actual. Se devuelve un dato en formato d-m-Y.<br /><hr />";
echo "57. strtotime(\"next Thursday\")". strtotime("next Thursday") ."<br/>";
echo "58. Se obtiene la fecha del próximo jueves contando desde la fecha actual. Se devuelve un dato de tiempo Unix en segundos.<br /><hr />";
echo "59. date('d-m-Y',strtotime(\"next Thursday\")): ". date('d-m-Y',strtotime("next Thursday")) . "<br/>";
echo "60. Se obtiene la fecha del próximo jueves contando desde la fecha actual. Se devuelve un dato en formato d-m-Y.<br /><hr />";
echo "61. strtotime(\"last Monday\"): ". strtotime("last Monday") . "<br/>";
echo "62. Se obtiene la fecha del pasado lunes contando desde la fecha actual. Se devuelve un dato de tiempo Unix en segundos.<br /><hr />";
echo "63. date('d-m-Y',strtotime(\"last Monday\")): ". date('d-m-Y',strtotime("last Monday")) . "<br/>";
echo "64. Se obtiene la fecha del pasado lunes contando desde la fecha actual. Se devuelve un dato en formato d-m-Y.<br /><hr />";

?>

<footer>
    <p>Manuel Bailera Serrano</p>
</footer>
 
</body>
</html>