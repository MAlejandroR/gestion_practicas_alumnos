<!DOCTYPE html>
 
<html lang="es">
	<head>
		<title>Práctica 1</title>
		<meta charset="utf-8" />
		<link rel="stylesheet" href="./css/estilo.css" />
	</head>
<body>
    <header>
       <h1><a href="./">Programas básicos de pruebas</a></h1>
    </header>
	<aside>
		<ul>
			<li><a href="./variables.php">Variables en php</a></li>
			<li><a href="./constantes.php">Constantes en php</a></li>
			<li><a href="./asignacion.php">Asignación en php</a></li>
			<li><a href="./seleccion.php">Selección en php</a></li>
			<li><a href="./ternario.php">Operador Ternario en php</a></li>
			<li><a href="./iteraciones.php">Iteraciones en php</a></li>
			<li><a href="./funciones.php">Funciones </a></li>

		</ul>
	</aside>
	<main>
		<h2>Asignación en PHP</h2>
		<p>En este ejercicio se asignan a una variable valores de diferente procedencia. A continuación se visualizan los valores especificando de dónde viene su valor.</p>
        <p>Se vuelve al index automáticamente después de 5 segundos*</p>
        <hr/>
        
		<?php
        // Un valor constante numérico
            print "Un valor constante numérico: <h3>\$a = 28;</h3>";
            $a = 28;
            print "<p class='resultado'>Valor de la expresión: <span>$a</span></p>";

        // Un valor constante string
            print "Un valor constante string: <h3>\$a = \"Esto es una cadena de texto\";</h3>";
            $a = "Esto es una cadena de texto";
            print "<p class='resultado'>Valor de la expresión: <span>$a</span></p>";

        // Un valor constante numérica con valor hexadecimal
            print "Un valor constante numérica con valor hexadecimal: <h3>\$a = 0x5a;</h3>";
            $a = 0x5a;
            print "<p class='resultado'>Valor de la expresión (en formato decimal): <span>$a</span></p>";

        // Un valor constante numérica con valor binario
            print "Un valor constante numérica con valor binario: <h3>\$a = 0b101001;</h3>";
            $a = 0b101001;
            print "<p class='resultado'>Valor de la expresión (en formato decimal): <span>$a</span></p>";

        // Un valor de una expresión numérica
            print "Un valor de una expresión numérica: <h3>\$a = 54 + 7;</h3>";
            $a = 54 + 7;
            print "<p class='resultado'>Valor de la expresión: <span>$a</span></p>";
        
        // Un valor de una expresión de cadena de caracteres
            print "Un valor de una expresión de cadena de caracteres: <h3>\$a = \"cadena\" . \" de texto\";</h3>";
            $a = "cadena" . " de texto";
            print "<p class='resultado'>Valor de la expresión (string): <span>$a</span></p>";

        // Un valor que devuelva una función, por ejemplo la función print
            print "Un valor que devuelva una función: <h3>\$a = print(\"cadena de texto\");</h3>";
            $a = print("cadena de texto");
            print "<p class='resultado'>Valor de la expresión (booleano): <span>$a</span></p>";

        // El valor de una expresión que sea una asignación
            print "El valor de una expresión que es una asignación: <h3>\$a = \$a = (\$v=29);</h3>";
            $a = ($v=29);
            print "<p class='resultado'>Valor de la expresión: <span>$a</span></p>";

		// Volver al index después de 5 segundos 
		header('refresh: 5; url = ./');  

		?>

	</main>
    <footer>
        <p>Manuel Bailera Serrano</p>
    </footer>
</body>
</html>