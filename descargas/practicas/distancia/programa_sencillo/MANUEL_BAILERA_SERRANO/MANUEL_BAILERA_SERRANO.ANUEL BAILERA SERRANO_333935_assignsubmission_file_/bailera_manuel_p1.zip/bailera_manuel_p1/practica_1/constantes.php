<!DOCTYPE html>
 
<html lang="es">
	<head>
		<title>Práctica 1</title>
		<meta charset="utf-8" />
		<link rel="stylesheet" href="./css/estilo.css" />
	</head>
<body>
    <header>
       <h1><a href="./">Programas básicos de pruebas</a></h1>
    </header>
	<aside>
		<ul>
			<li><a href="./variables.php">Variables en php</a></li>
			<li><a href="./constantes.php">Constantes en php</a></li>
			<li><a href="./asignacion.php">Asignación en php</a></li>
			<li><a href="./seleccion.php">Selección en php</a></li>
			<li><a href="./ternario.php">Operador Ternario en php</a></li>
			<li><a href="./iteraciones.php">Iteraciones en php</a></li>
			<li><a href="./funciones.php">Funciones </a></li>
		</ul>
	</aside>
	<main>
		<h2>Constantes en PHP</h2>
		<p>En este ejercicio se define la constante <b>edad</b>.</p>
        <p>A la constante Edad le asigno mi edad (39).</p>
        <p>A continuación se muestran los años que tengo y los años que me quedan para cumplir 100 años</p>
        <p>Se vuelve al index automáticamente después de 2 segundos*</p>
        <hr/>
		
		<?php
         // Constante declarada con define   
            define("edad",39);
            print "<p class='resultado'>Tengo <span>" . edad . "</span> años (Constante declarada con define)</p>";

         // Constante declarada con const  
            const EDAD = 39;
            print "<p class='resultado'>Tengo <span>" . EDAD . "</span> años (Constante declarada con const)</p>";

        // Operación con define  
            print "<p class='resultado'>Para los 100, me faltan <span>" . (100 - edad) . "</span> años (Operación de constante con define)</p>";

        // Operación con const
            print "<p class='resultado'>Para los 100, me faltan <span>" . (100 - EDAD) . "</span> años (Operación de constante con const)</p>";

		// Volver al index después de 2 segundos 
		header('refresh: 2; url = ./');  

		?>

	</main>
    <footer>
        <p>Manuel Bailera Serrano</p>
    </footer>
</body>
</html>