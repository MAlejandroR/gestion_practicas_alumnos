<!DOCTYPE html>
 
<html lang="es">
	<head>
		<title>Práctica 1</title>
		<meta charset="utf-8" />
		<link rel="stylesheet" href="./css/estilo.css" />
	</head>
<body>
    <header>
       <h1><a href="./">Programas básicos de pruebas</a></h1>
    </header>
	<aside>
		<ul>
			<li><a href="./variables.php">Variables en php</a></li>
			<li><a href="./constantes.php">Constantes en php</a></li>
			<li><a href="./asignacion.php">Asignación en php</a></li>
			<li><a href="./seleccion.php">Selección en php</a></li>
			<li><a href="./ternario.php">Operador Ternario en php</a></li>
			<li><a href="./iteraciones.php">Iteraciones en php</a></li>
			<li><a href="./funciones.php">Funciones </a></li>
		</ul>
	</aside>
	<main>
		<h2>Página de inicio</h2>
		<p>Selecciona alguna de las opciones del menú de la izquierda.</p>
	</main>
    <footer>
        <p>Manuel Bailera Serrano</p>
    </footer>
</body>
</html>