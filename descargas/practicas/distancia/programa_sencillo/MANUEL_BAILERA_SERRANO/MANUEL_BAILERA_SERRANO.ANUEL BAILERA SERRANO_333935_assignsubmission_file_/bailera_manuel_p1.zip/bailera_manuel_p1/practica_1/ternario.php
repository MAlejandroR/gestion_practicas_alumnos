<!DOCTYPE html>
 
<html lang="es">
	<head>
		<title>Práctica 1</title>
		<meta charset="utf-8" />
		<link rel="stylesheet" href="./css/estilo.css" />
	</head>
<body>
    <header>
       <h1><a href="./">Programas básicos de pruebas</a></h1>
    </header>
	<aside>
		<ul>
			<li><a href="./variables.php">Variables en php</a></li>
			<li><a href="./constantes.php">Constantes en php</a></li>
			<li><a href="./asignacion.php">Asignación en php</a></li>
			<li><a href="./seleccion.php">Selección en php</a></li>
			<li><a href="./ternario.php">Operador Ternario en php</a></li>
			<li><a href="./iteraciones.php">Iteraciones en php</a></li>
			<li><a href="./funciones.php">Funciones </a></li>
		</ul>
	</aside>
	<main>
		<h2>Operador ternario en PHP</h2>
		<p>Se obtiene un número aleatorio de 1 a 1000 y, usando el operador ternario, se visualiza con un texto si el número es par o impar.</p>
        <p>Se vuelve al index automáticamente después de 2 segundos*</p>
        <hr/>

		<?php

            $numero = rand(1, 1000);
            $resultado = ($numero % 2 == 0)? "par." : "impar";

            echo "<p class='resultado'>El número $numero es $resultado</p>";

            echo '<a href="'.basename(__FILE__).'">Probar con otro número</a>';

		// Volver al index después de 2 segundos 
		header('refresh: 2; url = ./');  
		?>

	</main>
    <footer>
        <p>Manuel Bailera Serrano</p>
    </footer>
</body>
</html>