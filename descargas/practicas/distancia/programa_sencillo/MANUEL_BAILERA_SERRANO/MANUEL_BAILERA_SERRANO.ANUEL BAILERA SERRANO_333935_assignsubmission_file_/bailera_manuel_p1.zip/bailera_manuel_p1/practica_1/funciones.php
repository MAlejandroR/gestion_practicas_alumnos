<!DOCTYPE html>
 
<html lang="es">
	<head>
		<title>Práctica 1</title>
		<meta charset="utf-8" />
		<link rel="stylesheet" href="./css/estilo.css" />
	</head>
<body>
    <header>
       <h1><a href="./">Programas básicos de pruebas</a></h1>
    </header>
	<aside>
		<ul>
			<li><a href="./variables.php">Variables en php</a></li>
			<li><a href="./constantes.php">Constantes en php</a></li>
			<li><a href="./asignacion.php">Asignación en php</a></li>
			<li><a href="./seleccion.php">Selección en php</a></li>
			<li><a href="./ternario.php">Operador Ternario en php</a></li>
			<li><a href="./iteraciones.php">Iteraciones en php</a></li>
			<li><a href="./funciones.php">Funciones </a></li>
		</ul>
	</aside>
	<main>
		<h2>Funciones en PHP</h2>
		<p>La función recibe dos parámetros (referencia y valor), duplica los valores de los parámetros y muestra los valores antes y después de modificarlos. La función devuelve el valor mayor de los dos parámetros.</p>
        <p>El programa principal crea dos variables, muestra sus valores, invoca a la función y vuelve a mostrar los valores.</p>
        <p>Se vuelve al index automáticamente después de 10 segundos*</p>
        <hr/>

		<?php
        // Creo dos valores en variables
        $a = 5;
        $b = 9;

        // Visualizo sus valores
        echo "<p class = 'resultado'>Programa principal, antes de invocar a la función: \$a = $a, \$b = $b</p>";

        function operaciones(&$a, $b) {
            // La función que recibe dos variables $a y $b
            // $a se ha de pasar por referencia $b por valor

            // Visualizo los valores antes de modificarlos
            echo "<p class = 'resultado'>Dentro de la función, antes de modificar los parámetros: \$a = $a, \$b = $b</p>";
            
            // Duplico los valores de los parámetros
            $a = $a * 2;
            $b = $b * 2;

            // Visualizo los valores después de modificarlos
            echo "<p class = 'resultado'>Dentro de la función, después de modificar los parámetros: \$a = $a, \$b = $b</p>";

            // Dentro de la función creo una variable global que es igual al segundo parámetro de la función
            $GLOBALS['c'] = $b;

            // La función devuelve el valor mayor de los dos
            $mayor = $a > $b ? $a : $b;
            return "El valor mayor es: " . $mayor . "<br/>";
        }

        // Invoco la función
        operaciones($a, $b);

        // Después de la llamada a la función se visualizan los valores
        echo "<p class = 'resultado'>Programa principal, después de invocar a la función: \$a = $a, \$b = $b</p>";
        echo "<p class = 'resultado'>Valor de la variable global \$GLOBALS['c'], que he creado dentro de la función, que otiene el valor de \$b: \$c = $c, que es el mismo valor que tenía \$b dentro de la función.</p>";


		// Volver al index después de 5 segundos 
		header('refresh: 10; url = ./');  
		?>

	</main>
    <footer>
        <p>Manuel Bailera Serrano</p>
    </footer>
</body>
</html>