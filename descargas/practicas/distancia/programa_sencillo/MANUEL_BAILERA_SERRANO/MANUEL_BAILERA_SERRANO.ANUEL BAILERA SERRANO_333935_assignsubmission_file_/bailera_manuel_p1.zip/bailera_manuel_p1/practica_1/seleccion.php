<!DOCTYPE html>
 
<html lang="es">
	<head>
		<title>Práctica 1</title>
		<meta charset="utf-8" />
		<link rel="stylesheet" href="./css/estilo.css" />
	</head>
<body>
    <header>
       <h1><a href="./">Programas básicos de pruebas</a></h1>
    </header>
	<aside>
		<ul>
			<li><a href="./variables.php">Variables en php</a></li>
			<li><a href="./constantes.php">Constantes en php</a></li>
			<li><a href="./asignacion.php">Asignación en php</a></li>
			<li><a href="./seleccion.php">Selección en php</a></li>
			<li><a href="./ternario.php">Operador Ternario en php</a></li>
			<li><a href="./iteraciones.php">Iteraciones en php</a></li>
			<li><a href="./funciones.php">Funciones </a></li>
		</ul>
	</aside>
	<main>
		<h2>Selección en PHP</h2>
		<p>Usando la selección del tipo switch, el programa genera una edad aleatoria entre 1 y 150 años y nos dice si somos niños (0-11) adolescentes (12-17) jóvenes (18-35) adultos (36-65) jubilados (66- ...).</p>
        <p>La edad que no esté en el intevalo 0-110 años se visualizará como 'edad no contemplada en nuestra encuesta'.</p>
        <p>Se vuelve al index automáticamente después de 2 segundos*</p>
        <hr/>

		<?php

            $edad = rand(1, 150);

            echo "<p class='resultado'>Tu edad es $edad, ";

            switch ($edad){
                case ($edad < 12):
                    echo "eres un niño";
                    break;
                case ($edad < 36):
                    echo "eres un joven";
                    break;
                case ($edad < 66):
                    echo "eres un adulto";
                    break;
                case ($edad < 111):
                    echo "eres un jubilado";
                    break;
                default:
                    echo "edad no contemplada en la encuesta";
            }

            echo "</p>";
            
            echo '<a href="'.basename(__FILE__).'">Probar con otra edad</a>';

		// Volver al index después de 2 segundos 
		header('refresh: 2; url = ./');  
		?>

	</main>
    <footer>
        <p>Manuel Bailera Serrano</p>
    </footer>
</body>
</html>