<?php
    $edad = rand(0, 150);
    switch (true) {
        case ($edad < 12):
            echo "Eres un niño de $edad años.";
            break;
        case ($edad < 18):
            echo "Eres un adolescente de $edad años.";
            break;
        case ($edad < 36):
            echo "Eres un joven de $edad años.";
            break;
        case ($edad < 66):
            echo "Eres un adulto de $edad años.";
            break;
        case ($edad <= 110):
            echo "Eres un jubilado de $edad años.";
            break;
        default:
            echo "Edad no contemplada en nuestra encuesta.";
    }

    echo '<br>Serás redirigido a la página principal en 2 segundos...';
    header('refresh:2;url=index.php');
