<?php
    $suma = 0;
    for ($i = 2; $i < 100; $i += 2) {
        $suma += $i;
    }

echo "El resultado de sumar $i números pares es $suma.";

echo '<br>Serás redirigido a la página principal en 2 segundos...';
header('refresh:2;url=index.php');
