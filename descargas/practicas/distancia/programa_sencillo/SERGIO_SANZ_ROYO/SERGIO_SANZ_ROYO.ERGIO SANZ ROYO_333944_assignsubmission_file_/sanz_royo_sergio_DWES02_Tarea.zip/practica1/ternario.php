<?php
    $aleatorio = rand(1, 1000);
    echo "El número $aleatorio es " . ($aleatorio % 2 == 0 ? 'par' : 'impar') . '.';

    echo '<br>Serás redirigido a la página principal en 2 segundos...';
    header('refresh:2;url=index.php');
