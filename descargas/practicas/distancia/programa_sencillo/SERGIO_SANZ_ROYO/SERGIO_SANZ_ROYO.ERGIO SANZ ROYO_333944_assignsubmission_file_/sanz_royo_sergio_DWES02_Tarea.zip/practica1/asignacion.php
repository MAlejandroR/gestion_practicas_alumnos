<?php
    $variable = 10;
    echo "10 => $variable<br>";
    $variable = 'Cadena de texto';
    echo "'Cadena de texto' => $variable<br>";
    $variable = 0xa8ef0;
    echo "0xa8ef0 => $variable<br>";
    $variable = 010110;
    echo "010110 => $variable<br>";
    $variable = 10 + 4;
    echo "10 + 4 => $variable<br>";
    $variable = 'String ' . 'compuesto';
    echo  "'String ' . 'compuesto' => $variable<br>";
    $variable = rand(1,2);
    echo "rand(1,2) => $variable";

    echo '<br><br>Serás redirigido a la página principal en 5 segundos...';
    header('refresh:5;url=index.php');
