<?php
    define('EDAD', 21);
    echo 'Tengo ' . EDAD . ' años y me quedan ' . (100 - EDAD) . ' para cumplir los cien.<br><br>';

    echo 'Serás redirigido a la página principal en 2 segundos...';
    header('refresh:2;url=index.php');
