<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Práctica 1</title>
</head>
<body>
    <h1>Lista de programas básicos de pruebas</h1>
    <ul>
        <li><a href="variables.php">Variables en PHP</a></li>
        <li><a href="constantes.php">Constantes en PHP</a></li>
        <li><a href="asignacion.php">Asignación en PHP</a></li>
        <li><a href="seleccion.php">Selección en PHP</a></li>
        <li><a href="ternario.php">Operador ternario en PHP</a></li>
        <li><a href="iteraciones.php">Iteraciones en PHP</a></li>
        <li><a href="funciones.php">Funciones</a></li>
    </ul>
</body>
</html>
