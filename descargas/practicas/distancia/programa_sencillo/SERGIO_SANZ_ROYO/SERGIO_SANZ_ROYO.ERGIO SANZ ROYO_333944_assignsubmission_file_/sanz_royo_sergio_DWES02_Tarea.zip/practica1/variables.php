<?php
    $v1 = 125;
    $v2 = 0674;
    $v3 = 0xAbCD4;
    $v4 = 0b1101;
    $v5 = "Esto es una cadena de caracteres";
    $v6 = 'Esto es otra cadena de caracteres';
    $v7 = "Esto es una cadena<br>
            multilínea<br>
            y termina aquí";
    $v8 = "  Esto es una cadena<br>
            multilínea<br>
            y termina aquí";
    $v9 = 1.23432230003322014000002234101;
    $v10 = 1234E-2;
    $v11 = null;
    $v12 = true;
    $v13 = false;

    print $v1 . '<br>';
    print $v2 . '<br>';
    print $v3 . '<br>';
    print $v4 . '<br>';
    print $v5 . '<br>';
    print $v6 . '<br>';
    print $v7 . '<br>';
    print $v8 . '<br>';
    print $v9 . '<br>';
    print $v10 . '<br>';
    print $v11 . '<br>';
    print $v12 . '<br>';
    print $v13 . '<br>';

    echo 'Serás redirigido a la página principal en 5 segundos...';
    header('refresh:5;url=index.php');
