<?php
    function mayorDuplicados(&$a, $b) {
        $a *= 2;
        $b *= 2;
        return $a > $b ? $a : $b;
    }

    $a = 2;
    $b = 3;

    echo "El valor de A es $a y el de B es $b.<br>";
    $mayor = mayorDuplicados($a, $b);
    echo "Después de llamar a la función, el valor de A es $a y el de B es $b.<br>";
    echo "El valor mayor es $mayor.<br>";
