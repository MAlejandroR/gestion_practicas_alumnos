<!DOCTYPE html>
<html>
<body>
<?php
	define('edad1', 20);
	const edad2 = 50;
  	echo('La edad1 definida con define es igaul a ' . edad1 . '<br><br>');
  
  	echo('La edad2 definida con define es igaul a ' . edad2 . '<br><br>');
  
  	echo('La edad1 le faltan ' . (100 - edad1) . ' para los 100<br><br>');
  
  	echo('La edad2 le faltan ' . (100 - edad2) . ' para los 100<br><br>');
	header( "refresh:2;url=../indexP1.php" );

?> 
</body>
</html>
