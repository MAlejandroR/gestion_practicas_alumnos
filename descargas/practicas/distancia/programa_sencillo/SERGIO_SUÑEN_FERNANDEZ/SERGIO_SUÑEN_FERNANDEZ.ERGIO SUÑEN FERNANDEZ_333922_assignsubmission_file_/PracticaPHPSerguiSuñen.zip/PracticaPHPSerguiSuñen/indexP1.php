<!DOCTYPE html>
<html>
  <body>
  	<h1>Practica 1</h1>
  	<table align="center">
	    <td>
	      <tr><a href="./Practica1/Practica1.php">Ejercicio 1</a></tr> <br><br>
	    </td>
	    <td>
	      <tr><a href="./Practica1/Practica2.php">Ejercicio 2</a></tr> <br><br>
	    </td> 
	    <td>
	      <tr><a href="./Practica1/Practica3.php">Ejercicio 3</a></tr> <br><br>
	    </td>
	    <td>
	      <tr><a href="./Practica1/Practica4.php">Ejercicio 4</a></tr> <br><br>
	    </td> 
	    <td>
	      <tr><a href="./Practica1/Practica5.php">Ejercicio 5</a></tr> <br><br>
	    </td> 
	    <td>
	      <tr><a href="./Practica1/Practica6.php">Ejercicio 6</a></tr> <br><br>
	    </td>
	    <td>
	      <tr><a href="./Practica1/Practica7.php">Ejercicio 7</a></tr> <br><br>
	    </td>  
    </table>
    </td>
  </body>
</html>