<!DOCTYPE html>
<html>
  <body>
    <table>
      <?php
        echo('<tr>');
			  $variable = 125;
			  echo('<td>$variable: ' . $variable . '</td>');
        echo('</tr>');
        echo('<tr>');
			  echo('<td>$variable: 0874 Da un error asi que lo he escrito directamnete, no lo he asignado a una variable</td>');
        echo('</tr>');
        echo('<tr>');
			  $variable = 0xAbC12;
			  echo('<td>$variable: ' . $variable . '</td>');
        echo('</tr>');
        echo('<tr>');
        $variable = 0b1100;
			  echo('<td>$variable: ' . $variable . '</td>');
        echo('</tr>');
        echo('<tr>');
        $variable = 'Esto es una cadena de caracteres';
			  echo('<td>$variable: ' . $variable . '</td>');
        echo('</tr>');
        echo('<tr>');
        $variable = "Esto es otra cadena de caracteres";
			  echo('<td>$variable: ' . $variable . '</td>');
        echo('</tr>');
        echo('<tr>');
        $variable = <<< FIN
Esto es una cadena
multilínea
y termina aquí
FIN;
        echo('<td>$variable: ' . $variable . '</td>');
        echo('</tr>');
        echo('<tr>');
        $variable = <<< FIN
<pre>
Esto es una cadena
multilínea
y termina aquí
</pre>
FIN;
			  echo('<td>$variable: ' . $variable . '</td>');
        echo('</tr>');
        echo('<tr>');
        $variable = 1.23432230003322014000002234101;
			  echo('<td>$variable: ' . $variable . '</td>');
        echo('</tr>');
        echo('<tr>');
        $variable = 1234E-2;
			  echo('<td>$variable: ' . $variable . '</td>');
        echo('</tr>');
        echo('<tr>');
        $variable = null;
			  echo('<td>$variable: ' . $variable . '</td>');
        echo('</tr>');
        echo('<tr>');
        $variable = true;
			  echo('<td>$variable: ' . $variable . '</td>');
        echo('</tr>');
        echo('<tr>');
        $variable = false;
			  echo('<td>$variable: ' . $variable . '</td>');
			  echo('</tr>');

        header( "refresh:5;url=../indexP1.php" );
      ?> 
  </table>
</body>