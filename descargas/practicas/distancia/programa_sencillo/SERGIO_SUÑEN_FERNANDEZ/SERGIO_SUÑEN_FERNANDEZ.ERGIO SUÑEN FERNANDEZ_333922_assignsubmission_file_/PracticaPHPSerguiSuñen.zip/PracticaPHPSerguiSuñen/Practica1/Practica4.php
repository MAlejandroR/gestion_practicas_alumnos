<!DOCTYPE html>
<html>
<body>
<?php
	
	$number = rand(1, 150);
	if($number< 1){
		echo "Edad no contemplada en nuestra encuesta";
	} elseif($number>= 1 && $number<=11){
		echo "Como tienes ". $number . " eres un niño";
	} elseif($number>11 && $number<=17){
		echo "Como tienes". $number . " eres un adolescente";
	} elseif($number> 17 && $number<=35){
		echo "Como tienes ". $number . " eres un joven";
	} elseif($number> 35 && $number<=66){
		echo "Como tienes ". $number . " eres un adulto";
	} elseif($number> 66 && $number<=110){
		echo "Como tienes ". $number . " eres un jubilado";
	} elseif($number> 110){
		echo "Edad no contemplada en nuestra encuesta";
	}

  	header( "refresh:2;url=../indexP1.php" );
     
?> 
</body>
</html>
