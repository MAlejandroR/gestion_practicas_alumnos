<!DOCTYPE html>
<html>
<body>
<?php
	const num = 50;
	echo("Numero: " . num . "<br>");
	const str = "Esto es un String";
	echo("String: " . str . "<br>");
	const nHex =  0x144A3;
	echo("Hexdecimal: ". nHex . "<br>");
	const nBin = 0b01010001;
	echo("Binary: " . nBin . "<br>");
	$expNum = 8.567;
	echo("Expresion numerica: " . $expNum . "<br>");
	$strChar = "Hello "." Wolrd";
	echo("Cadena de characters: " . $strChar . "<br>");
	$func = print "You are welcome";
	echo("Function: " . $func . "<br>");
	$asign = str;
	echo("Asignation: " . $asign . "<br>");
	
  	header( "refresh:5;url=../indexP1.php" );
     
?> 
</body>
</html>
