<!DOCTYPE html>
<html>
<body>
<?php
	
	$number1 = 33;
	$number2 = 17;

	echo "Los valores son: " . $number1 . " y " . $number2 . "<br>";
	function recalculate($a, $b){

		$a *= 2;
		$b *= 2;

		if($a > $b) {
			return $a;
		} else {
			return $b;
		}

	}

	$maxNumber = recalculate($number1, $number2);

	echo "El resultado mayor es: " . $maxNumber;

     
?> 
<br>
<h3><a href="../indexP1.php">Volver</a></h3>
</body>
</html>
