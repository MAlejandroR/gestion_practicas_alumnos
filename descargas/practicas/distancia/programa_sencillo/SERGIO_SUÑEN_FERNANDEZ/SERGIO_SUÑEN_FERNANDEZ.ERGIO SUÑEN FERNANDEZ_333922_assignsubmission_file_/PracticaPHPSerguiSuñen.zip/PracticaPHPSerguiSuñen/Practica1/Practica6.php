<!DOCTYPE html>
<html>
<body>
<?php
	
	$number = 0;
	for ($i=1; $i <= 100 ; $i++) { 
		# code...
		$number += $i;
	}

	echo "El resultado de sumar todos los numeros de 100 es: " . $number;

  	header( "refresh:2;url=../indexP1.php" );
     
?> 
</body>
</html>
