<!DOCTYPE html>
<html>
<body>
<?php
	
	$number = rand(1, 1000);
	if($number % 2 != 0){
		echo "El numero ". $number . " es un numero impar";
	} else {
		echo "El numero ". $number . " es un numero par";
	}

  	header( "refresh:2;url=../indexP1.php" );
     
?> 
</body>
</html>
