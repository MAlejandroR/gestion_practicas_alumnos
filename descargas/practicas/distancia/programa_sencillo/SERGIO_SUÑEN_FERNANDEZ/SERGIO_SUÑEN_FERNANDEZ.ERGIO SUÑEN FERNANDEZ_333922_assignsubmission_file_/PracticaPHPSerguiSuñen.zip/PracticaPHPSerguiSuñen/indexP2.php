<!DOCTYPE html>
 
<html>
<head>
    <meta charset="UTF-8">
    <title></title>
</head>
<body>
<?php
 
 
//Defino dos variables con mi nombre y apellidos
 $nombre = 'Sergio';
 $apellidos = 'Suñen Fernandez';
//Visualizo el texto con echo y print, por ejemplo en mi caso (deben de aparecer las comillas del ejemplo
// mi nombre es "Manuel" y mi apellido es "Romero"
//1)con echo pasando varios argumentos (separadados por coma)
  echo '1) Mi nombre es "' . $nombre . '" y mis apellidos son "' . $apellidos .'" <br>';

 
//2)con print
  print('2) Mi nombre es "' . $nombre . '" y mis apellidos son "' . $apellidos .'"<br>');

//3,4 y 5)Explica en el fichero diferencias entre echo y print y semejanzas.
 echo "3) Con la funcion echo " , "podemos imprimir varias cadenas a la vez <br>";
 print "4) Con la funcion print "; 
 print "solo pueds imprimir una cadena a la vez <br>";

 echo "5) La principal similitud entre ambos es que nos permiten mostrar un output en pantalla";
 
//6) Indica Por qué puedes pasar los argumentos sin usar paréntesis
 echo "6) No requiere parentesis porque realmetne no es una funcion es una construccion del lenguaje.";
 
/*7) Sintaxis heredoc,*/
//Asigna a una variable llamada informe un texto de cinco líneas,
//la etiqueta de finalización es FIN
//Posteriormente visualizas el texto
// El contenido de 'informe' es:
//   ........
// aquí aparecer el contenido del informe
// debe de respetarse el número de 5 líneas asignadas previamente";
//Tener cuidado con que la etiqueta no lleve en esa línea ningún otro carácter (espacios en blanco o tabulacones)
 $informe = <<< FIN
  7)........
 aquí aparecer el contenido del informe
 debe de respetarse el número de 5 líneas asignadas previamente";
Tener cuidado con que la etiqueta no lleve en esa línea ningún otro carácter (espacios en blanco o tabulacones)
FIN;
 
/*PROBANDO VARIABLES (del 8 al 19)*/
//Crea una variable y asígnale un valor
 $numero = 10;
//visualiza el valor de la variable y el tipo que eś
 echo "Numero: ".$numero . " y es de tipo " . gettype($numero);
//Cambia la variable a los siguientes tipos :boolean, float, string y null,  y visualizar su valor y tipo 
 $numero = true;
 echo "Boolean: ".$numero . " y es de tipo " . gettype($numero);
 $numero = 7.123;
 echo "Float: ".$numero . " y es de tipo " . gettype($numero);
 $numero = "Cadena de texto";
 echo "String: ".$numero . " y es de tipo " . gettype($numero);
 $numero = null;
 echo "Nulo: ".$numero . " y es de tipo " . gettype($numero);
 
 
//Prueba a ver el valor y tipo de una variable no definida previamente
 
 echo "Variable no existente: ". $algo . " y es de tipo " . gettype($algo);
 
 
/* 20)Visualiza el código ascii del valor 64 al 122 en carácter usando la función ascii  .. puedes usar la función printf o  bien char() ..*/

for ($i=64; $i <= 122 ; $i++) { 
	# code...
	echo "<br>Character " . $i . " es: " . chr($i);
}
 
 
//21)Visualiza el contenido de la función time() y explica su valor
 
 echo "<br>Funcion Time: " . time() . " Devuelve el momento actual medido como el número de segundos desde la Época Unix (1 de Enero de 1970 00:00:00 GMT)";
//22)Obtén la fecha actual y visualiza su valor con formato dia-mes-año en número usa la función date() para ello
 echo "<br>Fecha actual " . date('d-m-Y');
 
//23,24,y 25)Obtener los días, luego horas y luego minutos transcurridos desde el 1/1/1970 (round() o floor() para redondear
 
// $antiguaFecha = new DateTime("1970-1-1");
// $fechadeHoy = new DateTime("2019-11-05");
// $fechaFinal = $antiguaFecha -> diff($fechadeHoy);
// echo "<br>Diferencia de tiempo " . date($fechaFinal);

//Usando la función setlocale(...) y strftime(...)
//Puede ser que tengas que habilitar el idioma en el sistema con locale-gen
//26)  Obtén la fecha actual con formato por ejemplo domingo, 28 de octubre de 2018
//27)  Ahora con formato en inglés  Sunday, 28 October 2018
//28) y con formato en francés  dimanche, 28 octobre 2018
 
 
// 29-30)Asigna a una variable la fecha de tu cumpleaños
// Realiza una operación y obtén tu edad en años, meses y días (valor entero).
// tienes 23 años, 10 meses y 4 días
 
 
 
 
 
//31-32)Asigna a una variable una fecha de 30/10/1969 (mira las funciones strtotime() o bien mktime() para ello
// Obtén su edad en años, en meses y luego en días siempre redondeando
// tienes xx años
// tienes xx meses
// tienes xx días
 
 
//33-36). Usa la función getdate(...) y visualiza con la función print_r(.) el valor que retorna, comenta el resultado
//. Si escribo getdate(1) podrías explicar el contenido del array que nos retorna
//. Obtener la edad de una persona nacida el 1/1/1969
//37-64)Explica el siguiente código observando el resultado que se produce fuente obtenido en parte de http://php.net/manual/es/function.strtotime.php
echo "<hr>";
echo strtotime("now"), "<br/>";
echo date('d-m-Y', strtotime("now")), "<br/>";
echo strtotime("27 September 1970"), "<br/>";
echo date('d-m-Y',strtotime("10 September 2000")), "<br/>";
echo strtotime("+1 day"), "<br/>";
echo date('d-m-Y',strtotime("+1 day")), "<br/>";
echo strtotime("+1 week"), "<br/>";
echo date('d-m-Y',strtotime("+1 week")), "<br/>";
echo strtotime("+1 week 2 days 4 hours 2 seconds"), "<br/>";
echo date('d-m-Y',strtotime("+1 week 2 days 4 hours 2 seconds")), "<br/>";
echo strtotime("next Thursday"), "<br/>";
echo date('d-m-Y',strtotime("next Thursday")), "<br/>";
echo strtotime("last Monday"), "<br/>";
echo date('d-m-Y',strtotime("last Monday")), "<br/>";
echo "<hr>";
?>
 
</body>
</html>
