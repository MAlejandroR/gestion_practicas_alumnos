<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>Práctica1</title>
        
    <h2>
        <a href="./variables.php">Variables en php</a>
    </h2>
    <h2>
        <a href="./constantes.php">Constantes en php</a>
    </h2>
    <h2>
        <a href="./asignacion.php">Asignación en php</a>
    </h2>
    <h2>
        <a href="./seleccion.php">Selección en php</a>
    </h2>
    <h2>
        <a href="./ternario.php">Operador Ternario en php</a>
    </h2>
    <h2>
        <a href="./iteraciones.php">Iteraciones en php</a>
    </h2>
    <h2>
        <a href="./funciones.php">Funciones</a>
    </h2>
    </head>
    <body>
        <?php
        ?>
    </body>
</html>
