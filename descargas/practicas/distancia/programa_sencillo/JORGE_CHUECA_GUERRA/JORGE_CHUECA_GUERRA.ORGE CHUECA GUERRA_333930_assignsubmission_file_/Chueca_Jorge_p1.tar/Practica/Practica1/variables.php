<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>Variables</title>
    </head>
    <body>
        <?php
        
            //Variables en php
            $var = 1234;
            print "<p>Variable Decimal -> $var</p>";
            //$var = 0493;
            print "<p>Variable Octal -> $var</p>";
            $var = 0xAbC12;
            print "<p>Variable Hexadecimal -> $var</p>";
            $var = 00111;
            print "<p>Variable Binaria -> $var</p>";
            $var = 7.58248250213322014000002234101;
            print "<p>Variable Float -> $var</p>";
            $var = 9.214E-8;
            print "<p>Variable Float en Notación Científica -> $var</p>";
            $var = 00111;
            print "<p>Variable Binaria -> $var</p>";
            $var = null;
            print "<p>Variable Null -> $var</p>";
            $var = true;
            print "<p>Variable Boolean True -> $var</p>";
            $var = false;
            print "<p>Variable Boolean False -> $var</p>";
            $var = "Esto es una cadena de caracteres";
            print "<p>Variable String -> $var</p>";
            $var = 'Esto es una cadena de caracteres';
            print "<p>Variable String -> $var</p>";

    $var = <<< FIN
<p>Esto que ves, </p>
<p>es una cadena</p>
<p>multilínea</p>
<p>y termina aquí</p>
FIN;
            print "<p>Variable String Multilinea -> $var</p>";
    $v=<<< FIN
<pre>
<p>Esto que ves, </p>
 <p>es una cadena</p>
<p>multilínea</p>
<p>y termina aquí</p>
</pre>
FIN;
            print "<p>Variable String Multilinea -> $var</p>";
    
             header( "refresh:5;url=./index.php" );
        
        ?>
    </body>
</html>