<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>Iteraciones</title>
    </head>
    <body>
        <?php

             $total = 0;
            for ($i = 0; $i < 100; $i++){
               if ($i % 2 == 0)
                    $total += $i;
            }
            echo "La suma de los 100 primeros números pares es $total";

            header( "refresh:2;url=./index.php" );
        
        ?>
    </body>
</html>