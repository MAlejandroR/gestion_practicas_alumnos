<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        
            //Defino dos variables con mi nombre y apellidos
            $nombre = "Jorge";
            $apellido = "Chueca";

            //Visualizo el texto con echo y print, por ejemplo en mi caso (deben de aparecer las comillas del ejemplo
            // mi nombre es "Manuel" y mi apellido es "Romero"

            //1)con echo pasando varios argumentos (separadados por coma)
            echo '<p>1.-> Mi nombre es "', $nombre, '" y mi apellido es "', $apellido, '"</p>';

            //2)con print
            print "<p>2.-> Mi nombre es \"$nombre\" y mi apellido es \"$apellido\"</p>";

            //3,4 y 5)Explica en el fichero diferencias entre echo y print y semejanzas.
            echo "<p>3.-> echo permite", " pasar una lista", " de argumentos</p>"; 
            print '<p>4.-> print devuelve un valor booleano que representa si la sentencia ha tenido exito o no</p>';
            echo '<p>5.-> Ambos son iguales en que permiten imprimir por pantalla</p>';

            //6) Indica Por qué puedes pasar los argumentos sin usar paréntesis
            echo '<p>6.-> Tanto echo como print puede usarse con paréntesis y sin paréntesis porque no son funciones</p>';

            /*7) Sintaxis heredoc,*/
            //Asigna a una variable llamada informe un texto de cinco líneas,
            //la etiqueta de finalización es FIN
            //Posteriormente visualizas el texto
            // El contenido de 'informe' es:
            //   ........
            // aquí aparecer el contenido del informe
            // debe de respetarse el número de 5 líneas asignadas previamente";
            //Tener cuidado con que la etiqueta no lleve en esa línea ningún otro carácter (espacios en blanco o tabulacones)
$frase = <<< FIN
<p>Esto es</p>
<p>una frase</p>
<p>multilínea</p>
<p>formada por</p>
<p>5 líneas</p>
FIN;
            print "7-> El contenido de 'informe' es: $frase"; 


            /*PROBANDO VARIABLES (del 8 al 19)*/
            //Crea una variable y asígnale un valor
            $var = 14; 
            echo '<p>8.-> $var = 14. Valor de la variable: ', $var, '</p>'; 

            //visualiza el valor de la variable y el tipo que eś
            echo '<p>9.-> Tipo de la variable es ', gettype($var), '</p>'; 

            //Cambia la variable a los siguientes tipos :boolean, float, string y null,  y visualizar su valor y tipo 
            $var = true; 
            echo '<p>10.-> $var = true. Valor de la variable: ', $var, '</p>';
            echo '<p>11.-> El Tipo de la variable es ', gettype($var), '</p>'; 

            $var = 9.75; 
            echo '<p>12.-> $var = 9.75. Valor de la variable: ', $var, '</p>';
            echo '<p>13.-> El Tipo de la variable es ', gettype($var), '</p>'; 

            $var = "Hola Caracola"; 
            echo '<p>14.-> $var = "Hola Caracola". Valor de la variable: ', $var, '</p>';
            echo '<p>15.-> El Tipo de la variable es ', gettype($var), '</p>'; 

            $var = null; 
            echo '<p>16.-> $var = null. Valor de la variable: ', $var, '</p>';
            echo '<p>17.-> El Tipo de la variable es ', gettype($var), '</p>'; 

            //Prueba a ver el valor y tipo de una variable no definida previamente
            $a; 
            echo '<p>18.-> $a variable no creada previamente valor: ', $a, '</p>';
            echo '<p>19.-> El Tipo de la variable no creada es ', gettype($var), '</p>'; 


            /* 20)Visualiza el código ascii del valor 64 al 122 en carácter usando la función ascii  .. puedes usar la función printf o  bien char() ..*/
            echo '<p>20.-> Código ascii del valor 64 al 122</p>', '<p>';
            for ($i = 64; $i <= 122; $i++){
               echo $i, ' = ', chr($i);
            }
            echo '</p>';

            //21)Visualiza el contenido de la función time() y explica su valor
            echo '<p>21.-> Valor de la función time(): ', time(), 
                    '</p><p>Número de segundos transcurridos desde el 1/1/1970</p>';

            //22)Obtén la fecha actual y visualiza su valor con formato dia-mes-año en número usa la función date() para ello
             echo '<p>22.-> Fecha actual: ', date("d-m-Y"), '</p>';

            //23,24,y 25)Obtener los días, luego horas y luego minutos transcurridos desde el 1/1/1970 (round() o floor() para redondear
            $fecha1 = new DateTime("1970-01-01");
            $fecha2 = new DateTime(date("Y-m-d"));
            $diferencia = $fecha1->diff($fecha2);
            echo '<p>23.-> Días desde el 01/01/1970: ', $diferencia->days, ' días</p>';

            echo '<p>24.-> Horas desde el 01/01/1970: ', floor($diferencia->days * 24), ' horas</p>';

            echo '<p>25.-> Minutos desde el 01/01/1970: ', floor($diferencia->days * 24 * 60), ' minutos</p>';

            //Usando la función setlocale(...) y strftime(...)
            //Puede ser que tengas que habilitar el idioma en el sistema con locale-gen
            //26)  Obtén la fecha actual con formato por ejemplo domingo, 28 de octubre de 2018
            //27)  Ahora con formato en inglés  Sunday, 28 October 2018
            //28) y con formato en francés  dimanche, 28 octobre 2018
            setlocale(LC_ALL,"es_ES");
            echo '<p>26.-> Fecha con formato personalizado en español: ', strftime("%A, %d de %B de %Y"), '</p>';

            setlocale(LC_ALL,"en_UK");
            echo '<p>27.-> Fecha con formato personalizado en inglés: ', strftime("%A, %d de %B de %Y"), '</p>';

            setlocale(LC_ALL,"fr_FR");
            echo '<p>28.-> Fecha con formato personalizado en francés: ', strftime("%A, %d de %B de %Y"), '</p>';

            // 29-30)Asigna a una variable la fecha de tu cumpleaños
            // Realiza una operación y obtén tu edad en años, meses y días (valor entero).
            // tienes 23 años, 10 meses y 4 días





            //31-32)Asigna a una variable una fecha de 30/10/1969 (mira las funciones strtotime() o bien mktime() para ello
            // Obtén su edad en años, en meses y luego en días siempre redondeando
            // tienes xx años
            // tienes xx meses
            // tienes xx días


            //33-36). Usa la función getdate(...) y visualiza con la función print_r(.) el valor que retorna, comenta el resultado
            //. Si escribo getdate(1) podrías explicar el contenido del array que nos retorna
            //. Obtener la edad de una persona nacida el 1/1/1969
            //37-64)Explica el siguiente código observando el resultado que se produce fuente obtenido en parte de http://php.net/manual/es/function.strtotime.php
            echo "<hr>";
            echo strtotime("now"), " -> Convierte la fecha actual a fecha Unix", "<br/>";
            echo date('d-m-Y', strtotime("now")), " -> Muestra el día, mes y año actual", "<br/>";
            echo strtotime("27 September 1970"), " -> Muestra la fecha Unix de la fecha 27 de Septiembre de 1970", "<br/>";
            echo date('d-m-Y',strtotime("10 September 2000")), " -> Muestra la fecha 27 de Septiembre de 1970 en formato d-m-Y", "<br/>";
            echo strtotime("+1 day"), " -> Muestra la fecha Unix de mañana", "<br/>";
            echo date('d-m-Y',strtotime("+1 day")), " -> Muestra la fecha de mañana en formato d-m-Y", "<br/>";
            echo strtotime("+1 week"), " -> Muestra la fecha Unix dentro de una semana", "<br/>";
            echo date('d-m-Y',strtotime("+1 week")), " -> Muestra la fecha en formato d-m-Y de dentro de una semana", "<br/>";
            echo strtotime("+1 week 2 days 4 hours 2 seconds"), " -> Muestra la fecha Unix de dentro de 1 semana, 2 días, 4 horas y 2 segundos", "<br/>";
            echo date('d-m-Y',strtotime("+1 week 2 days 4 hours 2 seconds")), " -> Muestra la fecha en formato d-m-Y de dentro de 1 semana, 2 días, 4 horas y 2 segundos", "<br/>";
            echo strtotime("next Thursday"), " -> Muestra la fecha Unix del jueves que viene", "<br/>";
            echo date('d-m-Y',strtotime("next Thursday")), " -> Muestra la fecha en formato d-m-Y del jueves que viene", "<br/>";
            echo strtotime("last Monday"), " -> Muestra la fecha Unix del último lunes", "<br/>";
            echo date('d-m-Y',strtotime("last Monday")), " -> Muestra la fecha en formato d-m-Y del pasado lunes", "<br/>";
            echo "<hr>";
        
        ?>
    </body>
</html>
