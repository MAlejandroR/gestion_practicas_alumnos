<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>Operador Ternario</title>
    </head>
    <body>
        <?php

            $numero = mt_rand(1,1000);
            $texto = ($numero % 2 == 0) ? "El número $numero es par" : "El número $numero es impar";
            echo $texto;

            header( "refresh:2;url=./index.php" );
        
        ?>
    </body>
</html>