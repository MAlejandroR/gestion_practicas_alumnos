<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>Constantes</title>
    </head>
    <body>
        <?php

            define("EDAD", 20);
            const EDAD_CONST = 20;

            $total1 = 100 - EDAD;
            $total2 = 100 - EDAD_CONST;

            echo "<p>Constante declarada con define -> Tengo " . EDAD . " años</p>";
            echo "<p>Constante declarada con const -> Tengo " . EDAD_CONST . " años</p>";
            echo "<p>Operación con define -> Me faltan $total1 años para los 100</p>";
            echo "<p>Operación con const -> Me faltan $total2 años para los 100</p>";

            header( "refresh:2;url=./index.php" );
        
        ?>
    </body>
</html>