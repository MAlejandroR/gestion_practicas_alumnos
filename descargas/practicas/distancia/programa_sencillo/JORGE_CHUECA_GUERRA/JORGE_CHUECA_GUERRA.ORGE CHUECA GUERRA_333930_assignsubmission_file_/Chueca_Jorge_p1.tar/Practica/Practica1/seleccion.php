<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>Selección</title>
    </head>
    <body>
        <?php

            $edad=mt_rand(1,150);
    
            switch ($edad){
                case ($edad <= 11):
                    echo "Con $edad años somos niños";
                    break;
                case ($edad <= 17):
                    echo "Con $edad años somos adolescentes";
                    break;
                case ($edad <= 35):
                    echo "Con $edad años somos jóvenes";
                    break;
                case ($edad <= 65):
                    echo "Con $edad años somos adultos";
                    break;
                case ($edad <= 110):
                    echo "Con $edad años somos Jubilados";
                    break;
                default:
                    echo "La edad $edad no está contenplada en nuestra encuesta";
                    break;
            }

            header( "refresh:2;url=./index.php" );
        
        ?>
    </body>
</html>