<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>Funciones</title>
    </head>
    <body>
        <?php

            $a = 7;
            $b = 8;

            mostrarValores($a, $b);

            duplicarValor($a, $b);

            mostrarValores($a, $b);

            function duplicarValor(&$a, $b) {
                mostrarValores($a, $b);
                $a *= 2;
                $b *= 2;
                mostrarValores($a, $b);
            }

            function mostrarValores($a, $b) {
                echo "a: " . $a . " - b: " . $b . "\n";
            }

            //Dentro de la función no podemos crear una variable global, ya que
            // una función es un bloque local, no global

            header( "refresh:5;url=./index.php" );
        
        ?>
    </body>
</html>