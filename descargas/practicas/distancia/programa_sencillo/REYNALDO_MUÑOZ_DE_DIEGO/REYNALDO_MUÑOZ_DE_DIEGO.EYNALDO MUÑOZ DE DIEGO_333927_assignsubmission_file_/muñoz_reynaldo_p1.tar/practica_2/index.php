<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Documento sin título</title>
<link href="css/estilo.css" rel="stylesheet" type="text/css">
</head>

<body>
<div id = "contenedor">
<?php
 
 
//Defino dos variables con mi nombre y apellidos
$nombre ="Reynaldo";
$apellido ="Muñoz";
 
//Visualizo el texto con echo y print, por ejemplo en mi caso (deben de aparecer las comillas del ejemplo
// mi nombre es "Manuel" y mi apellido es "Romero"

//1)con echo pasando varios argumentos (separadados por coma)
echo 'Mi nombre es', '"', $nombre, '"', ' y mi apellido ', '"', $apellido,'"'; 
echo "<br/>";
 
//2)con print
print ('Mi nombre es "' . $nombre . '" y mi apellido "' . $apellido . '"');
echo "<br/>";
 
//3,4 y 5)Explica en el fichero diferencias entre echo y print y semejanzas.

echo "Diferencias entre echo y print:<br>
	<p>print devuelve un valor int que siempre es 1, por lo que puede ser utilizado en expresiones mientras que echo es tipo void, no hay valor devuelto y no 			       puede ser utilizado en expresiones.</p>
	
    <p>Según algunas fuentes echo es ligeramente más rápido que print.</p>";

echo "<hr>";
 
//6) Indica Por qué puedes pasar los argumentos sin usar paréntesis
 
 
/*7) Sintaxis heredoc,*/
//Asigna a una variable llamada informe un texto de cinco líneas,
//la etiqueta de finalización es FIN
//Posteriormente visualizas el texto
// El contenido de 'informe' es:
//   ........
// aquí aparecer el contenido del informe
// debe de respetarse el número de 5 líneas asignadas previamente";
//Tener cuidado con que la etiqueta no lleve en esa línea ningún otro carácter (espacios en blanco o tabulacones)

$informe = <<<FIN
<pre>
Contenido de la primera linea,
y este el de la segunda,
el de la tercera,
este otro de la cuarta,
y por fin de la quinta
</pre>
FIN;

echo "El contenido del informe es:<br/>";
echo $informe;


echo "<hr>";
/*PROBANDO VARIABLES (del 8 al 19)*/
//Crea una variable y asígnale un valor

$variable = 50;
 
//visualiza el valor de la variable y el tipo que eś
echo $variable . ": El tipo de dato de la variable es " . gettype($variable);
echo "<br/><br/>";

 
//Cambia la variable a los siguientes tipos :boolean, float, string y null,  y visualizar su valor y tipo 
 
$variable = true;
echo $variable . ": El tipo de dato de la variable es " . gettype($variable);
echo "<br/><br/>";

$variable = 2.78;
echo $variable . ": El tipo de dato de la variable es " . gettype($variable);
echo "<br/><br/>";

$variable = "Mi casa";
echo $variable . ": El tipo de dato de la variable es " . gettype($variable);
echo "<br/><br/>";

$variable = NULL;
echo $variable . ": El tipo de dato de la variable es " . gettype($variable);
echo "<br/><br/>";

//Prueba a ver el valor y tipo de una variable no definida previamente
$variable;
echo $variable . ": El tipo de dato de la variable es " . gettype($variable);
echo "<br/><br/>";

echo "<hr>";
 
/* 20)Visualiza el código ascii del valor 64 al 122 en carácter usando la función ascii  .. puedes usar la función printf o  bien char() ..*/
for ($var=64; $var<123; $var++){
	echo chr($var) . ", ";	
}

echo "<hr>";
 
//21)Visualiza el contenido de la función time() y explica su valor

echo time();

echo "<br/>";
echo "Devuelve el momento actual medido como el número de segundos desde la Época Unix (1 de Enero de 1970 00:00:00 GMT).";

echo "<br/>";
echo "<hr>";
 
//22)Obtén la fecha actual y visualiza su valor con formato dia-mes-año en número usa la función date() para ello

echo date ('d-m-Y');

echo "<br/>";
echo "<hr>";
//23,24,y 25)Obtener los días, luego horas y luego minutos transcurridos desde el 1/1/1970 (round() o floor() para redondear

$tiempoTranscurrido=time();

$dias= floor($tiempoTranscurrido/(60*60*24));
$horas = floor($tiempoTranscurrido/(60*60));
$minutos = floor($tiempoTranscurrido/60);

echo "Días transcurridos " . $dias . "<br>";
echo "Horas transcurridos " . $horas . "<br>";
echo "Minutos transcurridos " . $minutos . "<br>";

echo "<hr/>";
//Usando la función setlocale(...) y strftime(...)
//Puede ser que tengas que habilitar el idioma en el sistema con locale-gen
//26)  Obtén la fecha actual con formato por ejemplo domingo, 28 de octubre de 2018
//27)  Ahora con formato en inglés  Sunday, 28 October 2018
//28) y con formato en francés  dimanche, 28 octobre 2018

echo setlocale(LC_TIME, 'es_ES');
echo "<br/>";
echo strftime("%A, %d de %B de %Y");
echo "<br/>";
echo "<br/>";
echo setlocale(LC_TIME, 'en_EN');
echo strftime("%A, %d %B %Y");
echo "<br/>";
echo "<br/>";
echo setlocale(LC_TIME, 'fr_FR');
echo strftime("%A, %d %B %Y");
echo "<br/>";
echo "<hr>";


// 29-30)Asigna a una variable la fecha de tu cumpleaños
// Realiza una operación y obtén tu edad en años, meses y días (valor entero).
// tienes 23 años, 10 meses y 4 días

$fechaNacimiento = date_create('1967-03-25');
$fechaActual = date_create('now');
$edad = date_diff($fechaNacimiento, $fechaActual);
echo $edad->format('Tengo %y años, %m meses y %d días');

echo "<hr>";

 
 
//31-32)Asigna a una variable una fecha de 30/10/1969 (mira las funciones strtotime() o bien mktime() para ello
// Obtén su edad en años, en meses y luego en días siempre redondeando
// tienes xx años
// tienes xx meses
// tienes xx días

$fechaAsignada = date_create('1969-10-30');
$actual = date_create('now');
$laedad = date_diff($fechaAsignada, $actual);
echo $laedad->format('Tienes %y años<br/>tienes %m meses<br/>tienes %d días');

echo "<hr>";

 
//33-36). Usa la función getdate(...) y visualiza con la función print_r(.) el valor que retorna, comenta el resultado
//. Si escribo getdate(1) podrías explicar el contenido del array que nos retorna
//. Obtener la edad de una persona nacida el 1/1/1969
//37-64)Explica el siguiente código observando el resultado que se produce fuente obtenido en parte de http://php.net/manual/es/function.strtotime.php

echo strtotime("now"), "<br/>";
echo "Devuelve la fecha actual en cantidad de segundos, sin formato<br/><br/>";

echo date('d-m-Y', strtotime("now")), "<br/>";
echo "Lo mismo que lo anterior pero devolviendo la fecha con formato día, mes y año<br/><br/>";

echo strtotime("27 September 1970"), "<br/>";
echo "Devuelve la fecha pasada por parámetro en cantidad de segundos, sin formato<br/><br/>";

echo date('d-m-Y',strtotime("10 September 2000")), "<br/>";
echo "Lo mismo que lo anterior pero devolviendo la fecha con formato día, mes y año<br/><br/>";

echo strtotime("+1 day"), "<br/>";
echo "Suma a la fecha actual 1 día y la devuelve sin formato<br/><br/>";

echo date('d-m-Y',strtotime("+1 day")), "<br/>";
echo "Lo mismo que lo anterior pero devolviendo la fecha con formato día, mes y año<br/><br/>";

echo strtotime("+1 week"), "<br/>";
echo "Suma a la fecha actual 1 semana y la devuelve sin formato<br/><br/>";

echo date('d-m-Y',strtotime("+1 week")), "<br/>";
echo "Lo mismo que lo anterior pero devolviendo la fecha con formato día, mes y año<br/><br/>";

echo strtotime("+1 week 2 days 4 hours 2 seconds"), "<br/>";
echo "Suma a la fecha actual 1 semana, 2 días, 4 horas y dos segundos y la devuelve sin formato<br/><br/>";

echo date('d-m-Y',strtotime("+1 week 2 days 4 hours 2 seconds")), "<br/>";
echo "Lo mismo que lo anterior pero devolviendo la fecha con formato día, mes y año<br/><br/>";

echo strtotime("next Thursday"), "<br/>";
echo "Nos muestra la fecha del próximo jueves sin formato<br/><br/>";

echo date('d-m-Y',strtotime("next Thursday")), "<br/>";
echo "Lo mismo que lo anterior pero devolviendo la fecha con formato día, mes y año<br/><br/>";

echo strtotime("last Monday"), "<br/>";
echo "Nos muestra la fecha del último domingo sin formato<br/><br/>";

echo date('d-m-Y',strtotime("last Monday")), "<br/>";
echo "Lo mismo que lo anterior pero devolviendo la fecha con formato día, mes y año<br/><br/>";
echo "<hr>";
?>
<div id="pie">
  <p>Reynaldo Muñoz de Diego -- DAW -- DWES</p></div>
</div>
</div>

</body>
</html>