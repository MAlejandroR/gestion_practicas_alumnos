<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Documento sin título</title>
<link href="css/estilo.css" rel="stylesheet" type="text/css">
</head>

<body>
<div id="contenedor">
<h1>Lista de programas básicos de php</h1>
<h2>Práctica 1</h2>
<ul>
  <li><a href="variables.php">Variables en php</a></li>
  <li><a href="constantes.php">Constantes en php</a></li>
  <li><a href="asignacion.php">Asignación en php</a></li>
  <li><a href="seleccion.php">Selección en php</a></li>
  <li><a href="ternario.php">Operador ternario en php</a></li>
  <li><a href="iteracion.php">Iteraciones en php</a></li>
  <li><a href="funciones.php">Funciones</a></li>
</ul>
<hr/>

<div id="pie">
  <p>Reynaldo Muñoz de Diego -- DAW -- DWES</p></div>
</div>
</body>
</html>