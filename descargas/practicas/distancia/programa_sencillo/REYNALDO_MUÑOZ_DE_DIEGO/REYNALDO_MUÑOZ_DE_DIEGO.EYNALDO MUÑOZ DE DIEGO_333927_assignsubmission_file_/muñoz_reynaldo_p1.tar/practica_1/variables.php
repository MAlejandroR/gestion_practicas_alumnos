<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Variables</title>
<link href="css/estilo.css" rel="stylesheet" type="text/css">
</head>

<body>
<div id="contenedor">
<h1>Variables</h1>

<?php

	$var1=125;
	print $var1 . "<br/>";
	
	$var2="0874";
	printf ("%d", $var2); //representación en decimal
	echo "<br/>";
	
	$var3=0xAbC12;
	printf ("%x", $var3); //representación en hexadecimal
	echo "<br/>";
	
	$var4="0b1100";
	printf ("%b", $var3); //representación en binario
	echo "<br/>";
	
	$var5="Esto es una cadena de caracteres";
	print $var5 . "<br/>"; // representación valor string entre comillas dobles
	
	$var6='Esto es otra cadena de caracteres';
	print $var6 . "<br/>"; // representación valor string entre comillas simples
	
	$var7=
		" Esto es una cadena 
		multilínea 
		y termina aquí";
	print $var7 . "<br/>";
	
    $var7=
		"<pre>
	   	   Esto es una cadena 
		multilínea 
		y termina aquí
		</pre>";
	print $var7 . "<br/>";
	
	$var8=1.23432230003322014000002234101;
	printf ("%e", $var8); //representación en científica
	echo "<br/>";
	
	$var9=1234E-2;
	printf ("%e", $var9); //representación en científica
	echo "<br/>";
	
	$var10=null;
	print (var_dump($var10));
	echo "<br/>";
	
	$var11=true;
	print ($var11 ? 'true': 'false');
	echo "<br/>";
	
	$var12=false;
	print ($var12 ? 'true': 'false');
	echo "<br/>";
?>

<hr>

<?php
	echo "<h3>En 5 segundos volveremos al menú...</h3>"; 
	header("Refresh:5; url=index.php");
	exit();
?>
</div>
</body>
</html>