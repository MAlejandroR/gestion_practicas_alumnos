<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Asignación</title>
<link href="css/estilo.css" rel="stylesheet" type="text/css">
</head>

<body>
<div id ="contenedor">
<h1>Asigna a una variable valores de diferente procedencia</h1>


<hr>
<h2>Soluciones</h2>
<?php
	
	$miVariable = 45;
	echo "Un valor constante numérico (45): " . $miVariable;
	echo "<br/>";
	
	$miVariable = "Este es el mensaje";;
	print "Un valor constante string (Este es el mensaje): " . $miVariable;
	echo "<br/>";
	
	$miVariable = 0xABC12;
	print "Un valor constante numérico con valor hexadecimal (0xABC12): " . hexdec($miVariable);
	echo "<br/>";
	
	$miVariable = 110011;
	print "Un valor constante numérico con valor binario (110011): " . bindec($miVariable);
	echo "<br/>";
	
	$miVariable = 245/78;
	print "Un valor de una expresión numérica (245/78): " . $miVariable;
	echo "<br/>";
	
	$miVariable = "pal" . "abr" . "a" . " en trocitos";
	print "Un valor de una expresión de cadena de caracteres: " . $miVariable;
	echo "<br/>";
	
	$miVariable = print("Un valor que devuelva una función , por ejemplo la función <em><strong>print</strong></em>: " . sqrt (81) . "<br/>");

	$miVariable = ($numero = 89);
	print "El valor de una expresión que sea una asignación: " . $miVariable;
	echo "<br/>";

?>


<?php
	echo "<h3>En 5 segundos volveremos al menú...</h3>"; 
	header("Refresh:5; url=index.php");
	exit();
?>
</div>
</body>
</html>