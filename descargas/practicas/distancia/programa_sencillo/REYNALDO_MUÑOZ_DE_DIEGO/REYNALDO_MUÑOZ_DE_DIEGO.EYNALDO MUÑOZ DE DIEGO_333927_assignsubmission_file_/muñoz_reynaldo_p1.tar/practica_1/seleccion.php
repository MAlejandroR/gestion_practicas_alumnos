<!doctype html>
<html>
<head>
<meta charset="utf-8">
<link href="css/estilo.css" rel="stylesheet" type="text/css">
<title>Selección - Swith</title>
</head>

<body>
<div id="contenedor">
<h1>Swith</h1>

<hr/>
<h2>Solución</h2>
<?php

	$edad=rand(0, 150);
	
	echo "La edad generada aleatoriamente es: " . $edad;
	echo "<br/><br/>";

	switch ($edad) {
		case ($edad<12):
			echo "<h3>Eres un niño</h3>";
			break;
		case ($edad >11 && $edad <=17):
			echo "<h3>Eres un adolescente</h3>";
			break;
		case ($edad>17 && $edad<=35):
			echo "<h3>Eres joven</h3>";
			break;
		case ($edad>35 && $edad<=65):
			echo "<h3>Eres adulto</h3>";
			break;
		case ($edad>65 && $edad <=110):
			echo "<h3>Estas jubilado</h3>";
			break;
		default:
			echo "<h3>Edad no contemplada en nuestra encuesta</h3>";
		

		}

?>
<hr/>
<?php
	echo "<h3>En 2 segundos volveremos al menú...</h3>"; 
	header("Refresh:2; url=index.php");
	exit();
?>
</div>
</body>
</html>