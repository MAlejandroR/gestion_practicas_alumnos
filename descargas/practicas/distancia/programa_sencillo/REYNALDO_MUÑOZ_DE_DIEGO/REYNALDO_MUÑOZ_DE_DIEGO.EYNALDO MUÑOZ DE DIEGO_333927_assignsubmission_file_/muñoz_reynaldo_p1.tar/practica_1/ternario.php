<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Operador ternario</title>
<link href="css/estilo.css" rel="stylesheet" type="text/css">
</head>

<body>
<div id="contenedor">

<h1>Operador Ternario en php</h1>
<p>Usando el operador ternario obtén un número aleatorio de 1 a 1000 y visualiza con un texto si el número es par o impar .</p>
<p>Volver al index después de 2 segundos</p>
<hr>
<h2>Solución</h2>

<?php

$numeroAleatorio=rand (1, 1000);

echo ($numeroAleatorio%2==0) ? "El número $numeroAleatorio es par" : "El número $numeroAleatorio es impar";

?>

<hr>


<?php
	echo "<h3>En 2 segundos volveremos al menú...</h3>"; 
	header("Refresh:2; url=index.php");
	exit();
?>
</div>

</body>
</html>