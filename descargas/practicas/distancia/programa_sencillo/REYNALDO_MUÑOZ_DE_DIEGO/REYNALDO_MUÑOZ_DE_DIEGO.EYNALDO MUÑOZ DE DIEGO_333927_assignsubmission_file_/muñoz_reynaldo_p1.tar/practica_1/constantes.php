<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Constantes</title>

<link href="css/estilo.css" rel="stylesheet" type="text/css">
</head>

<body>
<div id="contenedor">

  <?php


	echo "<h2>Ejercicio con define y echo</h2><br/>";
	define ("EDAD", 52);
	echo "Mi edad es de " . EDAD . " años<br/>";
	echo "Me quedan " . (100-EDAD) . " años para tener 100";
	echo "<br/>----------------------------------";
	echo "<h2>Ejercicio con const y print</h2><br/>";
	const EDAD2=52;
	print "Mi edad es de " . EDAD2 . " años<br/>";
	print "Me quedan " . (100-EDAD2) . " años para tener 100";

?>

<hr>

<?php
	echo "<h3>En 2 segundos volveremos al menú...</h3>"; 
	header("Refresh:2; url=index.php");
	exit();
?>


<p>
</p>
</div>
</body>
</html>