<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Iteración</title>
<link href="css/estilo.css" rel="stylesheet" type="text/css">
</head>

<body>
<div id="contenedor">
<h1><strong>Iteraciones en php</strong></h1>
<p>Suma los 100 primeros números pares</p>
<p>Volver al index después de 2 segundos</p>
<hr>
<h2>Solución</h2>

<?php 
	$suma=0;
	for ($num=0; $num<=200; $num++) {
		
		if ($num%2==0) {
			$suma=$suma+$num;
		} 	
	}
	
	echo $suma;

?>
<hr>
    
<?php
	echo "<h3>En 2 segundos volveremos al menú...</h3>"; 
	header("Refresh:2; url=index.php");
	exit();
?>
</div>
</body>
</html>