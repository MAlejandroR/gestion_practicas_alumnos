<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Funciones</title>
<link href="css/estilo.css" rel="stylesheet" type="text/css">
</head>

<body>
<div id ="contenedor">

<h1>Funciones</h1>

<hr>
<h2>Solución</h2>

<?php
	$var1= 15;
	$var2= 25;
	echo $var1 . "<br/>" . $var2 . "<br/><br/>";
	
	function duplicar(&$v1, $v2) {
		$v1 = $v1*2;
		$v2 = $v2*2;
		//Mostramos los valores duplicados
		echo "Resultado de ejecutar la función: <br/>" . $v1 . "<br/>" . $v2 . "<br/><br/>";
		
		//Devolvemos el mayor de los valores
		if ($v1>$v2) {
			return $v1;
		} else {
			return $v2;
		}
		
	}
	
	//Ejectuamos la función pasando como parámetros nuestras variable y mostramos el resultado mayor
	echo "El resultado mayor de ejecutar la función es " . duplicar($var1, $var2);
	
	echo "<br/><br/>Mostramos los valores una vez ejecutada la función:<br/>";
	echo $var1 . "<br/>" . $var2 . "<br/>";
	echo "Comprobamos que la variable pasada por referencia ha duplicado su valor<br/>
	 frente al valor de la variable pasada por valor que permanece inalterado";

?>

<hr>


<?php
	echo "<h3>En 5 segundos volveremos al menú...</h3>"; 
	header("Refresh:5; url=index.php");
	exit();
?>
</div>
</body>
</html>