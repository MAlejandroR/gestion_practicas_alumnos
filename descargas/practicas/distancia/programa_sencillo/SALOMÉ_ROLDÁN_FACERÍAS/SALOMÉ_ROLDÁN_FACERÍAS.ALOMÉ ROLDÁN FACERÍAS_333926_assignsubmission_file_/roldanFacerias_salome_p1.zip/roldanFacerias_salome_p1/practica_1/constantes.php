
<!doctype html>
<html lang="en">
<head>
   <meta http-equiv="refresh" content="2; index.php" >
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <title>Practica1</title>
</head>
<?php
echo"<body>";
echo'<div">';
   echo'<h1>Constantes en PHP</h1>';
    define("edaddef", 21);
    const edadconst= 70;
    echo'<div>Constante declarada con define </div> Tengo '.edaddef.' años (Constante declarada con define)</div>';

    echo'<div>Constante declarada con const&nbsp&nbsp</div>Tengo '.edadconst.'años (Constante declarada con const)</div>';

    echo'<div>Operación con define.</div>Para los 100, me faltan '.(100 - edaddef).' años (Operación de constante con define)</div>';
    echo'<div>Operación con const.</div>Para los 100, me faltan '.(100 - edadconst).' años (Operación de constante con const)</div>';


echo'</div>';
echo'</div>';


    echo'<h3><a href="index.php">Volver</a></h3>';

        
echo'</div>';
        

echo'</body>';
?>  
</html>