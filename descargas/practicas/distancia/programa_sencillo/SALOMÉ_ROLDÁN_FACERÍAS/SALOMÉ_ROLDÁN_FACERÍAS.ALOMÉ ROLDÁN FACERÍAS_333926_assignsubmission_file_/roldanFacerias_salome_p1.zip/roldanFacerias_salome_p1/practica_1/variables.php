
<!doctype html>
<html lang="en">
<head>
   <meta http-equiv="refresh" content="5; index.php" >
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <title>Practica1</title>
</head>
   <?php
print "<body>";

print"<div>";
    print"<h1>Variables en PHP</h1>";
    print"<table border=1>";
       print" <tr>";
         print"<th>Valores Asignados</th>";
            print"<th>Mostrando Valores</th>";
        print"</tr>";

$v=125;
    print'<tr><td>$v='.$v.'</td> <td>Variable decimal, valor '.$v.'</td>';
print"</tr>";
$v='0274';
   print' <tr><td>$v='.$v.'</td><td> Variable octal, valor decimal '.octdec($v).' y en octal '.$v.'<br />';
print"</tr>";
$v='0xAbC12';
print'<tr><td>$v='.$v.'</td><td>Variable hexadecimal, valor decimal '.hexdec($v).' y en hexadecimal '.$v.'</td>';
print"</tr>";
$v='01100';
print'<tr><td>$v='.$v.'</td><td>Variable binaria, valor decimal '.bindec($v).' y en binario  '.$v.'</td>';
print"</tr>";
$v='1.2343223000332';
print'<tr><td>$v='.$v.'</td><td>Variable float, valor '.$v.' y en notación científica es '.sprintf("%.3e", $v).' </td>';
print"</tr>";
$v='1.234000e+1';
$fval = (float) $v; 
print'<tr><td>$v='.$v.'</td><td>Variable float, valor '.$fval.' y en notación científica es '.$v.'</td>';
print"</tr>";
$v='null';
$v1 =null;
print'<tr><td>$v='.strval($v).'</td><td>Variable null  es '.$v1.'y en string es '.$v.' </td>';
print"</tr>";
$v='true';
print'<tr><td>$v='.$v.'</td><td>Variable boolean, valor '.boolval($v).' y en string es '.$v.'</td>';
print"</tr>";
$v=False;
$v1='false';
print'<tr><td>$v='.strval($v1).'</td><td>Variable boolean, valor '.boolval($v).' y en string es '.$v1.'</td>';
print"</tr>";
$v ="Esto es una cadena de caracteres";
print'<tr><td>$v= "'.$v.'"</td><td>Variable string, valor '.$v.'</td>';
print"</tr>";
$v ='Esto es una cadena de caracteres';
print'<tr><td>$v= '.$v.'</td><td>Variable string, valor '.$v.'</td>';
print"</tr>";

 $v= <<<FIN
Esto que ves, 
 es una cadena
multilínea
y termina aquí
FIN;
print'<tr><td>$v='.$v.'</td><td>Variable string, valor '.$v.'</td>';
print"</tr>";

 $v= <<<FIN
<pre>
Esto que ves, 
 es una cadena
multilínea
y termina aquí
</pre>
FIN;
print'<tr><td>$v='.$v.'</td><td>Variable string, valor '.$v.'</td>';
print"</tr>";  
print"</table>";
print"</div>";

print"<div>";
    print"<h3><a href='index.php'>Volver</a></h3>";
print"</div>";

print"</div>";

print "</body>";

?>  
</html>