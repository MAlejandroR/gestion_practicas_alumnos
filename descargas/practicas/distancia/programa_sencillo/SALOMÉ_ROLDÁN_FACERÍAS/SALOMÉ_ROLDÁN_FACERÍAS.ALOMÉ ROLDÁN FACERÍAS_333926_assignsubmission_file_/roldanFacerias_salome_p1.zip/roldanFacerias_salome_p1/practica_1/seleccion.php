
<!doctype html>
<html lang="en">
<head>
   <meta http-equiv="refresh" content="2; index.php" >
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
        <title>Practica1</title>
</head>
<?php
echo"<body>";
echo'</div>';
echo'<div>';
   echo'<h1>Selecciones  en PHP</h1>';
$numaleatorio = rand(0,150);

switch (true){
case $numaleatorio >= 0 and $numaleatorio <=11;
 echo'<div>Eres un niño y tienes '.$numaleatorio.'años</div>';
break;
case $numaleatorio >=12 and $numaleatorio <=17;
echo'<div>Eres un adolescente y tienes '.$numaleatorio.'años</div>';
break;
case $numaleatorio >=18 and $numaleatorio <=35;
echo'<div>Eres un joven y tienes '.$numaleatorio.'años</div>';
break;
case $numaleatorio >=36 and $numaleatorio <=65;
echo'<div>Eres un adulto y tienes '.$numaleatorio.'años</div>';
break;
case $numaleatorio >=66 and $numaleatorio <=110;
echo'<div>Eres un jubilado y tienes '.$numaleatorio.'años</div>';
break;
default:
echo '<div>Edad no contemplada para la encuesta. Edad : '.$numaleatorio.'años</div>';
}
echo'<br />';
  echo'<div><a href="seleccion.php">Probar otra edad</a></pan> </div>';

echo'</div>';
echo'</div>';

echo'<div >';
    echo'<h3><a href="index.php">Volver</a></h3>';

        
echo'</div>';
        

echo'</body>';
?>  
</html>