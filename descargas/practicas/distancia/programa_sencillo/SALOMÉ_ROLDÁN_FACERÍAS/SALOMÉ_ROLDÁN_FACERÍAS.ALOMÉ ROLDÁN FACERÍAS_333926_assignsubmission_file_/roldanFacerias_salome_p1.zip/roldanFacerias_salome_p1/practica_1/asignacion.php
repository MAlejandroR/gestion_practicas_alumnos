<!doctype html>
<html lang="en">
<head>
   <meta http-equiv="refresh" content="5; index.php" >
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    
    <title>Practica1</title>
</head>
<body>

<body>
 <?php
  echo'<div>';
      echo'<h1>Variables en PHP</h1>';
      echo'<table border="1">';
          echo'<tr>';
              echo'<th>Expresión asignada</th>';
              echo'<th>Valor de la expresión</th>';
          echo'</tr>';
$a = 4;
    echo'<tr><td>$a=9</td> <td>'.$a.'</td>';
    echo'</tr>';
$a = 8.4;
    echo'<tr><td>$a=6.9</td> <td>'.$a.'</td>';
    echo'</tr>';
$a = 0b101101;
    echo'<tr><td>$a=0b101101</td> <td>'.$a.'</td>';
    echo'</tr>';
$a = "hola Caracola";
    echo'<tr><td>$a="hola Caracola"</td> <td>'.$a.'</td>';
    echo'</tr>';
$a = 9+6;
    echo'<tr><td>$a=9+6</td> <td>'.$a.'</td>';
    echo'</span>';
    echo'</tr>';
$a = "hola"."Caracola";
    echo'<tr><td>$a="hola"."Caracola"</td> <td>'.$a.'</td>';
    echo'</span>';
    echo'</tr>';
$a = print("Hola Caracolal");
    echo'<tr><td>$a= print("Hola Caracolal")</td> <td>'.$a.'</td>';
    echo'</tr>';
$a = ($v=9);
    echo'<tr><td>$a=($v=5)</td> <td>'.$a.'</td>';
    echo'</tr>';
    echo' </table>';
    echo'</div>';
    echo'<div>';
    echo'<h3><a href="index.php">Volver</a></h3>';
    echo'</div>';

    echo'</div>';
?>  
</body>

</html>
