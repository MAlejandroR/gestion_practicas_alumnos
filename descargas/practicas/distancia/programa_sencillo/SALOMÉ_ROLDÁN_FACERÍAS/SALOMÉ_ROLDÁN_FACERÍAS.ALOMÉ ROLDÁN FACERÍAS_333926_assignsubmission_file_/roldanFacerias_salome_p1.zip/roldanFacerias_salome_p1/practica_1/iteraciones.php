
<!doctype html>
<html lang="en">
<head>
   <meta http-equiv="refresh" content="2; index.php" >
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
   
    <title>Practica1</title>
</head>
<body>
  
<?php
     echo'<h1>Iteraciones en PHP</h1>';

// mostrar por pantalla los numeros pares menores que 100
$cont = 0;     // contar los números generados
$n = 100;   // cuantos pares se deben generar
$par = 0; // el numero par generado
while ( $cont <= $n){
	if ($cont %2 ==0){
	$par = $par + $cont;
	}
	$cont++;
}

    echo'<div>la suma de los primeros 100 numeros pares es '.$par.'</div>';
echo'<div >';
    echo'<h3><a href="index.php">Volver</a></h3>';

        
echo'</div>';
    ?>

</body>
</html>