
<!doctype html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport"
              content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
       
        <title>Practica2</title>
    </head>
    <body>
       <?php
        
        //Variables con mi nombre 
        $nom='"Salome"';
        $ape='"Roldan"';
        $informe = <<<FIN
<pre>
Este es un informe que tiene cinco líneas
esta es la primera
a continuación va la segunda
la tercera ya en el medio
la cuarta que es la penúltima
y la última la quinta
</pre>
FIN;
        
        

        echo "<h1>Probando instrucciones de php </h1> <ol>";
        echo "<li>Mi nombre es $nom y mi apellido es $ape <br /> </li>" ;
        print "<li> Mi nombre es $nom y mi apellido  es $ape <br /> </li> " ;
        echo "<li> echo puede imprimir más de una cadena separadas por comas, print solo puede imprimir una cadena </li>";
        echo "<li> print  devuelve un valor int que según la documentación siempre es 1, por lo que puede ser utilizado en expresiones mientras que echo es tipo void, no hay valor devuelto y no puede ser utilizado en expresiones </li>";
        echo "<li> Ambos son iguales en .velocidad </li>";
        echo "<li> Tanto echo como print puede usarse con paréntesis y sin paréntesis porque no es realmente una función </li>";
        echo"<li> $informe</li>";
        $v1=25;
        echo "<li>Valor de la variable \$v1 es  $v1 </li>";
        echo "<li>Tipo de la variable es ". gettype($v1)."</li>";
        $v2=true;
        echo "<li>Valor de la variable \$v2 es $v2</li>";
        echo "<li> Tipo de la varialbe es " . gettype($v2)."</li>";
        $v3=7.25;
        echo "<li>Valor de la variable \$v3 es $v3 </li> ";
        echo "<li> Tipo de la variable es ". gettype($v3)."</li>";
       
         $v4="Hola Caracola";
        echo "<li>Valor de la variable \$v4 es $v4</li>";
        echo "<li> Tipo de la variable es ". gettype($v4). "</li>";
        $v5=null;
        echo "<li>Valor de la variable \$v5 es $v5 </li>";
        echo "<li> Tipo de la variable es ". gettype($v5). "</li>";
        $a='';
        echo "<li>Variable no creada previamente \$a valor $a </li>";
        echo "<li> Tipo de la variable no creada es ". gettype($a). "</li> ";
        echo "<li> Código ascii del valor 64 al 122<br />
        </li> ";
         $n=64;
        while ($n<(121)){
       
        for ($a=0; $a<4;$a++){
            printf("%d = %c ",($n+$a),($n+$a));
        }
        
        $n+=$a;

    }
        echo "<li> Valor de la función time() ".time()."<br >
         Número de segundos transcurridos desde el 1/1/1970 </li> ";
        $fecha = date("d-m-Y", time());
        echo "<li> Fecha actual $fecha </li>";
        $date1 = new DateTime("1970-01-01 00:01:01");
        $date2 = new DateTime("now");
        $diff = $date1->diff($date2);
        echo "<li> Días desde el 1/1/1970 " .$diff->days ." días </li>";
        echo "<li> horas desde el 1/1/1970 " .($diff->days * 24 )." horas </li>";
        echo "<li> minutos desde el 1/1/1970 ".(($diff->days * 24 ) * 60 ). " minutos </li>";
        setlocale(LC_ALL, "es_ES.utf8");
        $fechaes = strftime("%A, %d de %B de %Y");
        echo "<li> Fecha con formato personalizado  en español $fechaes </li>";
        setlocale(LC_ALL, "fr_FR.utf8");
        $fechafr = strftime("%A, %d de %B de %Y");
        echo "<li> Fecha con formato personalizado en francés $fechafr</li>";
        setlocale(LC_ALL, "en_US.utf8");
        $fechaus = strftime("%A, %d of %B de %Y");
        echo "<li> Fecha con formato personalizado en inglés $fechaus</li>";
        $fecha_de_nacimiento = "1998-04-08";
        $fecha_actual = date ("Y-m-d");


// separamos en partes las fechas
$array_nacimiento = explode ( "-", $fecha_de_nacimiento );
$array_actual = explode ( "-", $fecha_actual );

$anos =  $array_actual[0] - $array_nacimiento[0]; // calculamos años
$meses = $array_actual[1] - $array_nacimiento[1]; // calculamos meses
$dias =  $array_actual[2] - $array_nacimiento[2]; // calculamos días

//ajuste de posible negativo en $días
if ($dias < 0)
{
    --$meses;

    //ahora hay que sumar a $dias los dias que tiene el mes anterior de la fecha actual
    switch ($array_actual[1]) {
           case 1:     $dias_mes_anterior=31; break;
           case 2:     $dias_mes_anterior=31; break;
           case 3: 
                if (bisiesto($array_actual[0]))
                {
                    $dias_mes_anterior=29; break;
                } else {
                    $dias_mes_anterior=28; break;
                }
           case 4:     $dias_mes_anterior=31; break;
           case 5:     $dias_mes_anterior=30; break;
           case 6:     $dias_mes_anterior=31; break;
           case 7:     $dias_mes_anterior=30; break;
           case 8:     $dias_mes_anterior=31; break;
           case 9:     $dias_mes_anterior=31; break;
           case 10:     $dias_mes_anterior=30; break;
           case 11:     $dias_mes_anterior=31; break;
           case 12:     $dias_mes_anterior=30; break;
    }

    $dias=$dias + $dias_mes_anterior;
}

//ajuste de posible negativo en $meses
if ($meses < 0)
{
    --$anos;
    $meses=$meses + 12;
}
function bisiesto($anio_actual){
    $bisiesto=false;
    //probamos si el mes de febrero del año actual tiene 29 días
      if (checkdate(2,29,$anio_actual))
      {
        $bisiesto=true;
    }
    return $bisiesto;
};
        
        echo "<li> Fecha $fecha_de_nacimiento</li>";
        echo "<li> Fecha de nacimeinto $fecha_de_nacimiento  fecha actual  $fecha_actual tienes $anos años con $meses meses y $dias días</li>";

function calcular_edad($fecha){
$fecha_nac = new DateTime(date('Y/m/d',strtotime($fecha))); // Creo un objeto DateTime de la fecha ingresada
$fecha_hoy =  new DateTime(date('Y/m/d',time())); // Creo un objeto DateTime de la fecha de hoy
$edad = date_diff($fecha_hoy,$fecha_nac); // La funcion ayuda a calcular la diferencia, esto seria un objeto
return $edad;
}
 
 
$edad = calcular_edad('1969-10-30');

        echo "<li> Fecha  1969-10-30 <br /> </li>";
        echo "<li> Fecha de nacimiento 1969-10-30 fecha actual $fecha_actual tiene {$edad->format('%Y')} años y {$edad->format('%m')} meses</li>";
        $hoy = getdate();
        
        echo "<li></li>";
         print_r($hoy);
        echo "<li> La anterior salida es un print_r de lo que retorna getdate(), cuyo significado es que devuelve un array asociativo que contiene la información de el momento local actual. </li>";
        $fechadevuelta=getdate(1/1/1969);
        echo "<li> </li>";
        print_r($fechadevuelta);
        
        echo "<li> La anterior salida es un print_r de lo que retorna getdate(1), cuyo significado es que devuelve un array asocativo que contiene la información de la fecha de timestamp</li>";
        echo '<li>strtotime("now") = '.strtotime("now").' </li>';
        echo '<li> Significado de strtotime("now") es la  marca de tiempo dada en el now</li>';
        echo '<li>date("d-m-Y", strtotime("now"))'.date('d-m-Y', strtotime("now")).'</li>';
        echo'<li> Significado de date("d-m-Y", strtotime("now")) es la  marca de tiempo dada en el now con el formato de dia-mes-año</li>';
        echo' <li> strtotime("27 September 1970")'.strtotime("27 September 1970").' </li>';
        echo'<li> Significado de strtotime("27 September 1970")es la  marca de tiempo, nos devuelve el tiempo </li>';
        echo'<li> date("d-m-Y",strtotime("10 September 2000"))'.date('d-m-Y',strtotime("10 September 2000")).'</li>';
        echo'<li> Significado de date("d-m-Y",strtotime("10 September 2000")) es la  marca de tiempo dada , nos deuelve el dato en formato de dia-mes-año</li>';
        echo'<li> strtotime("+1 day")'.strtotime("+1 day").' </li>';
        echo'<li> Significado de strtotime("+1 day") es la  marca de tiempo, nos devuelve el dia de hoy mas uno </li>';
        echo'<li> date("d-m-Y",strtotime("+1 day"))'.date('d-m-Y',strtotime("+1 day")).' </li>';
        echo'<li> Significado de date("d-m-Y",strtotime("+1 day")) es la  marca de tiempo, nos devuelve el dia de hoy mas uno, en  el formato de dia-mes-año</li>';
        echo'<li> strtotime("+1 week") '.strtotime("+1 week").' </li>';
        echo'<li> Significado de strtotime("+1 week") es la  marca de tiempo, nos devuelve la fecha de dentro de una semana </li>';
        echo'<li> date("d-m-Y",strtotime("+1 week"))'.date('d-m-Y',strtotime("+1 week")).' </li>';
        echo'<li> Significado de date("d-m-Y",strtotime("+1 week")) es la  marca de tiempo, nos devuelve la fecha de dentro de una semana, en  el formato de dia-mes-año</li>';
        echo'<li> strtotime("+1 week 2 days 4 hours 2 seconds") '.strtotime("+1 week 2 days 4 hours 2 seconds").' </li>';
        echo'<li> Significado de strtotime("+1 week 2 days 4 hours 2 seconds") es la  marca de tiempo, nos devuelve la fecha de dentro de una semana, dos dias, cuatro horas y dos segundos </li>';
        echo'<li> date("d-m-Y",strtotime("+1 week 2 days 4 hours 2 seconds"))'.date('d-m-Y',strtotime("+1 week 2 days 4 hours 2 seconds")).' </li>';
        echo'<li> Significado de date("d-m-Y",strtotime("+1 week 2 days 4 hours 2 seconds")) es la  marca de tiempo, nos devuelve la fecha de dentro de una semana, dos dias, cuatro horas y dos segundos, en  el formato de dia-mes-año </li>';
        echo'<li> strtotime("next Thursday")'.strtotime("next Thursday").' </li>';
        echo'<li> Significado de  strtotime("next Thursday") es la  marca de tiempo, nos devuelve la fecha del próximo jueves  </li>';
        echo'<li> date("d-m-Y",strtotime("next Thursday"))'.date('d-m-Y',strtotime("next Thursday")).' </li>';
        echo'<li> Significado de date("d-m-Y",strtotime("next Thursday")) es la  marca de tiempo, nos devuelve la fecha del próximo jueves, en  el formato de dia-mes-año </li>';
        echo'<li> strtotime("last Monday")'.strtotime("last Monday").' </li>';
        echo'<li> Significado de strtotime("last Monday")es la  marca de tiempo, nos devuelve la fecha del pasado lunes</li>';
        echo'<li> date("d-m-Y",strtotime("last Monday"))'.date('d-m-Y',strtotime("last Monday")).' </li>';
        echo'<li> Significado de date("d-m-Y",strtotime("last Monday")) es la  marca de tiempo, nos devuelve la fecha del pasado lunes, en  el formato de dia-mes-año </li></ol>';
            ?>
    </body>
</html>
