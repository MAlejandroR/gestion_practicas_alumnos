<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Practica1</title>
</head>
<body>
<?php
    echo "<h1>Lista de programas básico de pruebas</h1>";
    echo "<h2><a href='./variables.php'>Variables en php</a></h2>";
    echo "<h2><a href='./constantes.php'>Constantes en php</a></h2>";
    echo "<h2><a href='./asignacion.php'>Asignación en php</a></h2>";
    echo "<h2><a href='./seleccion.php'>Selección en php</a></h2>";
    echo "<h2><a href='./ternario.php'>Operador Ternario en php</a></h2>";
    echo "<h2><a href='./iteraciones.php'>Iteraciones en php</a></h2>";
    echo "<h2><a href='./funciones.php'>Funciones </a></h2>";
?>
</body>
</html>
