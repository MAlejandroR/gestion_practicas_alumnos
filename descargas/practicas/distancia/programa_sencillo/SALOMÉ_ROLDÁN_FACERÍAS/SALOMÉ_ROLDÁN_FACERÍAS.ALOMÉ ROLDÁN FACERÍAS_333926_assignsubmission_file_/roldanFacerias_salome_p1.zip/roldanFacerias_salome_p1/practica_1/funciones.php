
<!doctype html>
<html lang="en">
<head>
   <!--<meta http-equiv="refresh" content="2; index.php" >-->
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">

    <title>Practica1</title>
</head>
<body>
 <?php

 echo'<div>';
 $a =7;
 $b=8;
    echo' <h1>Funciones: paso de parámetros</h1>';
    echo'<div>Programa principal, antes de invocar a la función. $a = '.$a.' $b = '.$b.'</div>';
 
// Llamada a la función

 $a = duplicarcantidad($a, $b);

echo'<div>Programa principal, después de invocar a la función. <span class="variable">$a = '.$a.' $b = '.$b.'</div>';
echo'</div>';

echo'</div>';
echo'<div>';
    echo'<h3><a href="index.php">Volver</a></h3>';
echo'</div>';
 //Función duplicar
 function duplicarcantidad($a, $b) {
echo'<div>Dentro de la función,  antes de modificar parámetros: $a = '.$a.' $b = '.$b.'</div>';
$a=$a *2;
$b=$b*2;
echo'<div>Dentro de la función,  después  de modificar parámetros $a = '.$a.' $b = '.$b.'</div>';
return $a; 

}


?>  
</body>

</html>
