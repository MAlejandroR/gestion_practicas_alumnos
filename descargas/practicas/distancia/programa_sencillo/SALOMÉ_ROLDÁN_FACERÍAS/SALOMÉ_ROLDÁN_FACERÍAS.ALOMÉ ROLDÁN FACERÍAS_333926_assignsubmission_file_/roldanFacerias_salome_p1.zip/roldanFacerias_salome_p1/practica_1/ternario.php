
<!doctype html>
<html lang="en">
<head>
   <meta http-equiv="refresh" content="2; index.php" >
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <title>Practica1</title>
</head>
<?php
echo"<body>";
echo'<div>';
   echo'<h1>Ternario en PHP</h1>';
$numaleatorio = rand(0,1000);

$variable = ($numaleatorio%2 == 0) ? $numaleatorio." es un numero par" : $numaleatorio." es un numero impar " ;

    echo'<div> '.$variable.'</div>';
echo'<br />';
   echo' <div><a href="ternario.php">Probar otro número</a></div>';


echo'</div>';
echo'</div>';

echo'<div>';
    echo'<h3><a href="index.php">Volver</a></h3>';

        
echo'</div>';
        

echo'</body>';
?>  
</html>