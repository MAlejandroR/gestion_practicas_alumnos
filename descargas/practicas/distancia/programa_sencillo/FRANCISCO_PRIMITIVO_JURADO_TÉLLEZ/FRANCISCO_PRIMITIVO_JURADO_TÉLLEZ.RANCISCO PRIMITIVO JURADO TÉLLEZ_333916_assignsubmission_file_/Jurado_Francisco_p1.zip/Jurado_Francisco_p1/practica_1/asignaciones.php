
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="./css/estilo.css" type="text/css">
    <title>Practica 1</title>
</head>
<<body>
    <div class="seccion" >
        <?php
            $a= 2;	
            echo "Para la procedencia 2 el valor es $a<br />";
            $a= "Valor String";
            echo "Para la procedencia "Valor String" el valor es $a<br />";
            $a= 0x3344f;
            echo "Para la procedencia 0x3344f el valor es $a<br />";
            $a= 0b11112;	
            echo "Para la procedencia 0b11112 el valor es $a<br />";
            $a= (3+1*22);
            echo "Para la procedencia (3+1*22) el valor es $a<br />";
            $a="cadena"." "."de"." "."caracteres";	
            echo "Para la procedencia "cadena"." "."de"." "."caracteres" el valor es $a<br />";
            $a= print("cadena de caracteres");
            echo "Para la procedencia print("cadena de caracteres") el valor es $a<br />";
            $a= ($v="asignacion");
            echo "Para la procedencia ($v="asignacion") el valor es $a<br />";

            sleep(2);
            header('Location: index.php');
        ?>
    </div> 
 </body>
 </html>