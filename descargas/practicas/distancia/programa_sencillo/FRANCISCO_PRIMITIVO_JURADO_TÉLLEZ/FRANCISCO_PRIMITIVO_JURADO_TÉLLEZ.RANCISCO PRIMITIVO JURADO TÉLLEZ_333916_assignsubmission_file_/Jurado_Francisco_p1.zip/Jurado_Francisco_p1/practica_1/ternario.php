<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="./css/estilo.css" type="text/css">
    <title>Practica 1</title>
</head>
<<body>
    <div class="seccion" >
        <?php
           $num = rand(1, 1000);
            echo 'El numero aleatorio '.$num.' es ';
            echo ($num%2==0) ? 'PAR' : 'IMPAR';
        ?>
    </div> 
 </body>
 </html>