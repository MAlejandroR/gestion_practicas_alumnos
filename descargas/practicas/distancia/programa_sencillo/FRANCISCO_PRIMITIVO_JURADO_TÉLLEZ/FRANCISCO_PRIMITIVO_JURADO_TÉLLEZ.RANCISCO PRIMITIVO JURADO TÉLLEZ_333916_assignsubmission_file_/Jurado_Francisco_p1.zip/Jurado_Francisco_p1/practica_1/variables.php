<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="./css/estilo.css" type="text/css">
    <title>Practica 1</title>
</head>
<body>
    <div class="seccion"> 
        <?php
            $var1 = print 2344444;
            $var2 = print 0.44;
            $var3 = print 0xBbAb34;
            $var4 = print "Cadena de caracteres con comilla doble";
            $var5 = print 'Cadena de caracteres con comilla simple';
            $var6 = print 1333.343243;
            $var7 = print 1234E-2;
            $var8 = print null;
            $var9 = print true;
            $var10 = print false;

            sleep(5);
            header('Location: index.php');
        ?>
    </div>

</body>

 </html>
