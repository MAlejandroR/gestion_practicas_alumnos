<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="./css/estilo.css" type="text/css">
    <title>Practica 1</title>
</head>
<<body>
    <div class="seccion" >
        <?php
           $edad = rand(1, 150);

            if($edad <= 11){
                $num = 0;
            }elseif($edad <= 17){
                $num = 1;
            }elseif($edad <= 35){
                $num = 2;
            }elseif($edad <= 65){
                $num = 3;
            }elseif($edad <= 110){
                $num = 4;
            }else{
                $num = 5;
            }
           switch ($num) {
            case 0:
                $msj = "La persona con edad $edad es niño";
                break;
            case 1:
                $msj = "La persona con edad $edad es adolescente";
                break;
            case 2:
                $msj = "La persona con edad $edad es joven";
                break;
            case 3:
                $msj = "La persona con edad $edad es adulto";
                break;
            case 4:
                $msj = "La persona con edad $edad es jubilado";
                break;
            case 5:
                $msj = "Edad no contenplada en nuestra encuesta (1 a 110)";
                break;
           }
           echo $msj;
        ?>
    </div> 
 </body>
 </html>