<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="./css/estilo.css" type="text/css">
    <title>Practica 1</title>
</head>
<<body>
    <div class="seccion" >
        <?php
            $total = 0;
            for($i=0; $i<=100; $i++){
               if ($i%2==0) {
                    $total += $i;
               }
            }
            echo 'El total de la suma de los primeros 100 pares es: '.$total

            sleep(2);
            header('Location: index.php');
        ?>
    </div> 
 </body>
 </html>