<!DOCTYPE html>
 
<html>
<head>
    <meta charset="UTF-8">
    <title></title>
</head>
<body>
<?php
 
 
$nombre = 'Francisco';
$apellido = 'Jurado';
echo 'Mi nombre es "$nombre" y mi apellido es "$apellido"';
 //1)con echo pasando varios argumentos (separadados por coma)
 
echo 'Mi nombre'.' es '.'"$nombre"'.'y mi apellido es'.'"$apellido"';
 
//2)con print

print 'Mi nombre es "$nombre" y mi apellido es "$apellido"';

//3,4 y 5)Explica en el fichero diferencias entre echo y print y semejanzas.

//Por lo prinicipal son funciones muy parecidas, sin embargo mientras que con la función echo podemos imprimir directamente varias cadenas a la vez, 
//con la función print solo podremos imprimir una cadena cada vez que sea llamada.
 
 
/*PROBANDO VARIABLES (del 8 al 19)*/
$a = rand(1, 1000);
 
echo 'La variable '.$a.' es de tipo '.gettype($a);
 
//Cambia la variable a los siguientes tipos :boolean, float, string y null,  y visualizar su valor y tipo 

$a=true;
echo 'La variable '.$a.' es de tipo '.gettype($a);
$a=1.1444;
echo 'La variable '.$a.' es de tipo '.gettype($a);
$a='Prueba cadena';
echo 'La variable '.$a.' es de tipo '.gettype($a);
$a=null;
echo 'La variable '.$a.' es de tipo '.gettype($a);
 
//Prueba a ver el valor y tipo de una variable no definida previamente
 
echo 'La variable no definida '.$prueba;
 
//21)Visualiza el contenido de la función time() y explica su valor
$fecha = date("d m Y", time());
echo 'Fecha actual: '.$fecha;

//22)Obtén la fecha actual y visualiza su valor con formato dia-mes-año en número usa la función date() para ello
$fecha = date("d m Y", time());
echo 'Fecha actual: '.$fecha;
 
//23,24,y 25)Obtener los días, luego horas y luego minutos transcurridos desde el 1/1/1970 (round() o floor() para redondear
 
 
//Usando la función setlocale(...) y strftime(...)
//Puede ser que tengas que habilitar el idioma en el sistema con locale-gen
//26)  Obtén la fecha actual con formato por ejemplo domingo, 28 de octubre de 2018
//27)  Ahora con formato en inglés  Sunday, 28 October 2018
//28) y con formato en francés  dimanche, 28 octobre 2018
 
 
// 29-30)Asigna a una variable la fecha de tu cumpleaños
// Realiza una operación y obtén tu edad en años, meses y días (valor entero).
// tienes 23 años, 10 meses y 4 días
 
 
 
 
 
//31-32)Asigna a una variable una fecha de 30/10/1969 (mira las funciones strtotime() o bien mktime() para ello
// Obtén su edad en años, en meses y luego en días siempre redondeando
// tienes xx años
// tienes xx meses
// tienes xx días
 
 
//33-36). Usa la función getdate(...) y visualiza con la función print_r(.) el valor que retorna, comenta el resultado
//. Si escribo getdate(1) podrías explicar el contenido del array que nos retorna
//. Obtener la edad de una persona nacida el 1/1/1969
//37-64)Explica el siguiente código observando el resultado que se produce fuente obtenido en parte de http://php.net/manual/es/function.strtotime.php
echo "<hr>";
echo strtotime("now"), "<br/>";
echo date('d-m-Y', strtotime("now")), "<br/>";
echo strtotime("27 September 1970"), "<br/>";
echo date('d-m-Y',strtotime("10 September 2000")), "<br/>";
echo strtotime("+1 day"), "<br/>";
echo date('d-m-Y',strtotime("+1 day")), "<br/>";
echo strtotime("+1 week"), "<br/>";
echo date('d-m-Y',strtotime("+1 week")), "<br/>";
echo strtotime("+1 week 2 days 4 hours 2 seconds"), "<br/>";
echo date('d-m-Y',strtotime("+1 week 2 days 4 hours 2 seconds")), "<br/>";
echo strtotime("next Thursday"), "<br/>";
echo date('d-m-Y',strtotime("next Thursday")), "<br/>";
echo strtotime("last Monday"), "<br/>";
echo date('d-m-Y',strtotime("last Monday")), "<br/>";
echo "<hr>";
?>
 
</body>
</html>