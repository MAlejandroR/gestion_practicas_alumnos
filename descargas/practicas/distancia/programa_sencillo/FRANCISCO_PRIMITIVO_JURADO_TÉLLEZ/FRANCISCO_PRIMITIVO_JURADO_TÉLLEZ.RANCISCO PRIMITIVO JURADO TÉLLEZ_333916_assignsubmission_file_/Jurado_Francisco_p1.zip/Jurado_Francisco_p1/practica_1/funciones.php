<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="./css/estilo.css" type="text/css">
    <title>Practica 1</title>
</head>
<<body>
    <div class="seccion" >
        <?php

          function  calcularMayor($a, $b){
            $valor1 = $a*2;
            $valor2 = $b*2;

            return ($valor1>$valor2) ? $valor1 : $valor2;
          }

          $a = rand(1, 1000);
          $b = rand(1, 1000);

          echo 'El valor inicial de "a" es: '.$a;
          echo 'El valor inicial de "b" es: '.$b;

          $final = calcularMayor($a, $b);
          echo 'El valor mayor es: '.$final;

          sleep(2);
            header('Location: index.php');
        ?>
    </div> 
 </body>
 </html>