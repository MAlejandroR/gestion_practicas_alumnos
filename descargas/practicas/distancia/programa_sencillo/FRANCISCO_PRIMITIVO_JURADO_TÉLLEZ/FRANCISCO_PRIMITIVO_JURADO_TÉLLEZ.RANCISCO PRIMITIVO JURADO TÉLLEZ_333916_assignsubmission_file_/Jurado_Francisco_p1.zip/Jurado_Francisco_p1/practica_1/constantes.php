<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="./css/estilo.css" type="text/css">
    <title>Practica 1</title>
</head>
<<body>
    <div class="seccion" >
        <?php
            const EDAD = 22;
            $años_restantes = 100 - EDAD;
            echo $años_restantes;
            
            sleep(2);
            header('Location: index.php');
        ?>
    </div> 
 </body>
 </html>
