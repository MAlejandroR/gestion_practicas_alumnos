<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        //un valor constante numerico
        define("constanteNumerico", 30);
        //valor constante string
        define("constanteString", "buenos dias");
        //valor constante numerico valor hexadecimal
        define("numHexa", 0xFFF1A);
        //constante numerico valor binario
        define("numBina", 0b11001101);
        //valor de una expresión numerica
        $expreNum="25";
        //valor de una expresion de cadena caracteres
        $expreCarac="Esto es una cadena de caracteres";
        //valor que devuelva una funcion, print
        //$devFun= print "Devolviendo funcion \"print\".";
        //valor de una expresion que sea una asignación
        $a= "Practica 1";
        $b=$a." del modulo DWES";      
        
      
        
        ?>
        <h2>Asignación en PHP</h2>
        <br />
        <table border="1">
            <tr>
                <th> Expresion</th> <th>Valor</th>
            </tr>
            <tr>
                <td>define("constanteNumerico", 30);</td>
                <td><?php echo constanteNumerico; ?></td>
            </tr>
            <tr>
                <td>define("constanteString", "buenos dias");</td>
                <td><?php echo constanteString; ?></td>
            </tr>
            <tr>
                <td>define("numHexa", 0xFFF1A);</td>
                <td><?php echo numHexa; ?></td>
            </tr>
            <tr>
                <td>define("numBina", 0b11001101);</td>
                <td><?php echo numBina; ?></td>
            </tr>
            <tr>
                <td>$expreNum="25";</td>
                <td><?php echo $expreNum ?></td>
            </tr>
            <tr>
                <td>$expreCarac="Esto es una cadena de caracteres";</td>
                <td><?php echo $expreCarac ?></td>
            </tr>
            <tr>
                <td>$devFun= print "Devolviendo funcion \"print\".";</td>
                <td><?php $devFun= print "Devolviendo funcion \"print\".";?></td>
            </tr>
            <tr>
                <td>$a= "Practica 1";
        $b=$a." del modulo DWES";</td>
                <td><?php echo $b; ?></td>
            </tr>
            
        </table>
        
        <!-- retorno al index despues de 5 segundos -->
        <meta HTTP-EQUIV="refresh" content="5; url=index.php">
    </body>
</html>
