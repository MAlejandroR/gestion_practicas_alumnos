<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        //defino variables con mi nombre y apellido
        $nombre="Luis Miguel";
        $apellido="Martinez";
        
        //1) visualizo el contenidode las variables con echo con varios argumentos
        echo "1) Visualizando con \"echo\": ", "Mi nombre es \"$nombre\" "," y mi apellido \"$apellido\".<br /><br />";
        
        //2) con print
        print "2) Visualizando con \"print\": "."Mi nombre es \"$nombre\" y mi apellido \"$apellido\".";
        
        //3,4 y 5)diferencia entre echo y print, y semejanzas.
        echo "<br /><br />";
        echo "3,4 y 5) Semejanzas y diferencias entre \"echo\" y \"print\" <br />";
$comparativa = <<<COMPARATIVA
        Semejanzas: <br />
         -  Nos permiten mostrar un output en pantalla.<br />
         -  No es necesario el uso de parentisis al momento de llamarlas.<br />
            
        Diferencias:<br />
         -  Con echo podemos imprimir varias cadenas a la vez (separadas con ,),
           print solo nos permite imprimir una cadena cada vez que es llamada.<br />
         -  Print devuelve un valor int, por lo que puede ser utilizado en expresiones, 
            mientras que echo es tipo void(no devuelve valor) y no puede ser utilizado en expresiones.<br />
             \$texto= print "Hola";  // Se imprime "Hola" y $texto toma el valor 1 <br/>
            \$texto=echo"Hola";    //da error
COMPARATIVA;
        echo $comparativa;
        
        //6) Indica por qué puedes pasar los argumentos sin usar paréntesis
        echo "<br /><br /> 6)En print y echo se pueden pasar los argumentos sin usar parénteis por que"
        . "no son verdaderamente funciones, son constructores del lenguaje";
        
        //7)Sintaxis heredoc
$informe= <<<FIN
    El contenido del 'informe' es:<br />
        Segunda linea,<br />
        Tercera linea, <br />
        Cuarta linea,<br />
        Quinta y última línea.<br />
FIN;
    echo "<br /><br />7) sintaxis heredoc:<br />";
    echo $informe;
    
    //del 8 al 19 probando variables
    echo "<br /> del 8 al 19 probando variables: <br/>";
    //creo variable y asigno un valor entero
    $numero= 4;
    //visualizo el valor y el tipo
    echo "la variable \$numero tiene un valor de $numero , y su tipo es: ". gettype($numero);
    
    echo "<br /><br />Cambio variable a tipo boolean<br />";
    $numero=true;
    echo "la variable \$numero tiene un valor de $numero , y su tipo es: ". gettype($numero);
    
    echo "<br /><br />Cambio variable a tipo float<br />";
    $numero=4.3;
    echo "la variable \$numero tiene un valor de $numero , y su tipo es: ". gettype($numero);
    
    echo "<br /><br />Cambio variable a tipo string<br />";
    $numero="Esto es un String";
    echo "la variable \$numero tiene un valor de $numero , y su tipo es: ". gettype($numero);
    
    echo "<br /><br />Cambio variable a tipo null<br />";
    $numero=NULL;
    echo "la variable \$numero tiene un valor de $numero , y su tipo es: ". gettype($numero);
    
    echo "<br /><br />Mostrando variable \$num que no ha sido definida<br />";
    echo "la variable \$num tiene un valor de $num , y su tipo es: ". gettype($num);
    
    //20) visualizar el codigo axxcii del valor 64 al 122 usando la funcion ascii
    echo "<br /><br />20) Mostrando valor ASCII del 64 al 122 <br />";
    for($i=64; $i<=122; $i++){
        printf(" |  %d => %c   ", $i, $i);
    }
    
    //21) visualiza el valor de la función time() y explica su valor
    echo "<br /><br />21) valor de la funcion time(): <br />";
    echo time();
    echo "<br /> La funcion time() nos muestra los segundos transcurridos desde el 1-1-1970";
    
    //22)Obtén la fecha actual y visualiza su valor dia-mes-año en número usa funcion date
    echo "<br /><br />22) fecha actual con formato dia-mes-año usando funcion date()<br />";
    $fecha=date("d-m-Y");
    echo $fecha;
    
    //23, 24,25 Obtener días, horas, minutos desde 1-1-*1970 
    echo "<br /><br />23, 24, 25) dias, horas, minutos desde 1/1/1970 <br />";
    echo "dias: ".round(time()/(60*60*24));
    echo "<br /> horas: ".round(time()/(60*60));
    echo"<br /> minutos: ".round(time()/60);
    
    //26) fecha actual formato domingo,28 de octubre de 2018
    echo "<br /><br />26) fecha actual formato domingo,28 de octubre de 2018 <br />";
    setlocale(LC_ALL, "es_ES.utf8");
    $fecha2= strftime("%A, %d de %B de %Y");
    echo $fecha2;
    
    //27 fecha actual con formato en ingles
    echo "<br /><br />27) fecha actual formato en ingles <br />";
    setlocale(LC_ALL, "en_US.UTF8");
    $fecha3= strftime("%A, %d %B %Y");
    echo $fecha3;
    
    //28 fecha actual con formato en frances
    echo "<br /><br />28) fecha actual formato en frances <br />";
    setlocale(LC_ALL, "fr_fr.utf8");    
    $fecha4= strftime("%A, %d of %B %Y");
    echo $fecha4;
    
    //29)Asigna a una variable la fecha de tu cumpleaños
    echo "<br /><br />29-30) Asigna a una variable la fecha de tu cumpleaños <br />";
    echo " Nací el 04-03-1977.<br />";
    $cumpleaños = date_create("1977-03-04");
    $hoy= date_create(date("Y-m-d"));
    
    $edad = date_diff($hoy, $cumpleaños);
    $diferenceformat='tengo %Y años, %m meses y  %d dias';
    echo $edad->format($diferenceformat);
    
    //31-32 asina a una variable la fecha 30/10/1969
    echo "<br /><br />31-32) Asigna a una variable la fecha 30/10/1969";
    $año69= strtotime("1969-10-30");
    $actual=strtotime(now);
    $segundos=$actual-$año69;
    
    echo "<br />tienes ".round($segundos/(60*60*24*365))." años";
    echo "<br />tienes ".round($segundos/(60*60*24*30))." meses";
    echo "<br />tienes ".round($segundos/(60*60*24))." dias";
    
    
    
    //33-36 funcion getdate()
    echo "<br /><br /> 33-36) funcion getdate";
    echo "<br />Visualización de la funcion getdate():<br />";
    print_r(getdate());
    echo "<br />Nos muestra por este orden la información de la fecha y hora actual: <br />";
    echo "segundos, minutos, hora, días del mes(número), día de la semana(numero),"
    . "mes (numero), año, día del año, día de la semana (letra), mes, segundos desde "
            . "el 1-1-1970<br />";
     
    echo"<br/> mostrando información de getdate(1)<br />";
    print_r(getdate(1));
    echo"<br/> nos da la información de fecha y hora transcurridos 1 segundo desde 1-1-1970";
    
    //EDAD de una persona nacida el 1-1-1969
    echo "<br /><br />EDAD de una persona nacida el 1-1-1969: <br/>";
    echo "años: ".(getdate()[year]-1969);
    echo "<br />meses: ".getdate()[mon];
    echo "<br />dias: ".getdate()[mday];
    
    
    //echo 
    //echo "dias: ".round(time()/(60*60*24));
    
    
    //echo "<br />".strtotime("2019-1-1");
    
    
    
    //37-64
    echo "<br /><br /> 37-64)";
    echo "<br />strtotime('now'): ". strtotime("now");
    echo "<br />  muestra los segundos del 1-1-1977";
    
    echo "<br /><br />date('d-m-Y', strtotime('now'')):";
    echo date('d-m-Y', strtotime("now"));
    echo "<br />Muestra la fecha actual en formato dia-mes-año";
    
    echo "<br /><br /> strtotime('27 September 1970''): ";
    echo strtotime("27 September 1970"); 
    echo "<br />Muestra el número de segundos desde 1-1-1970 hasta 27-sep-1970 ";
    
    echo "<br /><br /> date('d-m-Y', strtotime('10 September 2000')): ";
    echo date('d-m-Y', strtotime("10 September 2000")); 
    echo "<br />Muestra la fecha data en formato d-m-Y ";
    
    echo "<br /><br /> strtotime('+1 day'): ";
    echo strtotime("+1 day"); 
    echo "<br />suma a los segundos transcurridos desde 1-1-1970, los segundos de un día (86400) ";
    
    echo "<br /><br /> date('d-m-Y',strtotime('+1 day')): ";
    echo date('d-m-Y',strtotime("+1 day")); 
    echo "<br /> Suma un día a la fecha actual";
    
    echo "<br /><br /> strtotime('+1 week'): ";
    echo strtotime("+1 week"); 
    echo "<br /> suma a los segundos transcurridos desde 1-1-1970, los segundos de una semana ";
    
    echo "<br /><br /> date('d-m-Y',strtotime('+1 week')): ";
    echo date('d-m-Y', strtotime("+1 week")); 
    echo "<br /> Suma una semana a la fecha actual ";
    
    echo "<br /><br /> strtotime('+1 week 2 days 4 hours 2 seconds'): ";
    echo strtotime("+1 week 2 days 4 hours 2 seconds"); 
    echo "<br /> suma a los segundos transcurridos desde 1-1-1970, los segundos de una semana 2 dias 4 horas 2 segundos ";
    
    echo "<br /><br /> date('d-m-Y',strtotime('+1 week 2 days 4 hours 2 seconds')): ";
    echo date('d-m-Y', strtotime("+1 week 2 days 4 hours 2 seconds")); 
    echo "<br /> Muestra la fecha dentro de 1 semana, 2 dias, 4 horas 2 segundos ";
    
    echo "<br /><br /> strtotime('next Thursday'): ";
    echo strtotime("next Thursday"); 
    echo "<br /> muestra los segundos desde 1-1-1970 hasta el proximo jueves";
    
    echo "<br /><br /> date('d-m-Y',strtotime('next Thursday')): ";
    echo date('d-m-Y', strtotime("next Thursday")); 
    echo "<br /> Muestra la fecha del proximo jueves ";
    
    echo "<br /><br /> strtotime('last Monday'): ";
    echo strtotime("last Monday"); 
    echo "<br /> muestra los segundos desde 1-1-1970 hasta el pasado Lunes";
    
    echo "<br /><br /> date('d-m-Y',strtotime('last Monday')): ";
    echo date('d-m-Y', strtotime("last Monday")); 
    echo "<br /> Muestra la fecha del pasado lunes ";
    
        ?>
    </body>
</html>
