<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <h2>Seleccion en PHP</h2>
        <?php
        // genero edad aleatoria
        $edad=rand(1,150);
        
        //mostramos la edad en pantalla
        echo "Edad: ".$edad."<br />";
        
        switch (true){
            case($edad >=0 && $edad <=11):
                echo "Tienes entre 0 y 11 años. ¡Eres un niño";
                break;
            case($edad >= 12 && $edad <= 17):
                echo "Tienes entre 12 y 17 años. ¡Eres un adolescente";
                break;
            case($edad >= 18 && $edad <= 35):
                echo "Tienes entre 12 y 17 años. ¡Eres un joven";
                break;
            case($edad >= 36 && $edad <= 65):
                echo "Tienes entre 36 y 65 años. ¡Eres un adulto";
                break;
            case($edad >= 66 && $edad <= 110):
                echo "Tienes entre 66 y 110 años. ¡Eres un jubilido";
                break;
            default :
                echo "Edad no contemplada en nuestra encuesta";
                    break;                
        }//fin switch
        
        ?>
        
        <!-- pausa de 2 segundos y redireccionamiento -->
        <meta HTTP-EQUIV="refresh" content="2; url=index.php">
        
    </body>
</html>
