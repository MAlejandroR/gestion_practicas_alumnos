<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <h2>Variables en PHP</h2>
        <?php
        $decimal=245;        
        echo"<br /> Valor asignado: \$decimal=245. Variable: ".gettype($decimal). ", valor: $decimal";
        
        $octal=0447;
        echo"<br />Valor asignado: \$octal=0342. Variable: ".gettype($octal). ", valor decimal: $octal, valor octal: ".decoct($octal);
        
        $hexa=0xFFA1;
        echo"<br />Valor asignado: \$hexa=0xFFA1. Variable: ".gettype($hexa). ", valor decimal: $hexa, valor hexadecimal: ". dechex($hexa);
        
        $bin=0b1100110;
        echo"<br />Valor asignado: \$bin=0b1100110. Variable: ".gettype($bin). ", valor decimal: $bin, valor hexadecimal: ". decbin($bin);
        
        $cadena1="Esto es una cadena entre comillas dobles";
        echo"<br />Valor asignado: \$cadena1=\"Esto es una cadena entre comillas dobles\". Variable: ".gettype($cadena1). ", valor: $cadena1";
        
        $cadena2='Esto es una cadena entre comillas simples';
        echo"<br />Valor asignado: \$cadena2='Esto es una cadena entre comillas simples'.  Variable: ".gettype($cadena2). ", valor: $cadena2";
        
        $numero2=1.12345678901234567890123456789;
        echo"<br />Valor asignado: \$numero2=1.12345678901234567890123456789;.  Variable: ".gettype($numero2);
        printf(", valor en notación cientifica: %e", $numero2);
        
        $numero3=2112E-2;
        echo"<br />Valor asignado: \$numero3=2112E-2.  Variable: ".gettype($numero3), ", valor: $numero3";
        printf(", valor en notación cientifica: %e", $numero3);
        
        $valorNulo=NULL;
        echo"<br />Valor asignado: \$valorNulo=NULL.  Variable: ".gettype($valorNulo). ", valor: $valorNulo";
        
        $boleano=false;
        echo"<br />Valor asignado: \$boleano=false.  Variable: ".gettype($boleano). ", valor: $boleano";
        
        $boleano=true;
        echo"<br />Valor asignado: \$boleano=true.  Variable: ".gettype($boleano). ", valor: $boleano";
        
        $cadena3=<<<CADENA3
             Cadena multilínea,
                sin <br />,
                se muestro todo seguido
CADENA3;
          
        echo"<br />Valor asignado: \$cadena3=<<<CADENA3
             Cadena multilínea,
                sin <br />,
                se muestro todo seguido
CADENA3;.  Variable: ".gettype($cadena3). ", valor: $cadena3";
        
        
        $cadena4=<<<CADENA4
                <pre>
                Otra cadena multilinea 
                que nos pemite
                mantener saltos
                de linea
                </pre>
CADENA4;
        
        
        echo"<br />Valor asignado: \$cadena4=<<<CADENA4
                <pre>
                Otra cadena multilinea 
                que nos pemite
                mantener saltos
                de linea
                </pre>
CADENA4;.  Variable: ".gettype($cadena4). ", valor: $cadena4";
               
        
        ?>
        
        <!-- retorno al index despues de 5 segundos -->
        <meta HTTP-EQUIV="refresh" content="5; url=index.php">
    </body>
</html>
