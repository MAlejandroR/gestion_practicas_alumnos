<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        
        <h2>Lista de programas básico de puebas</h2>
        
        <ul>            
            <li><a href="variables.php">Variables en php</a></li>
            <li><a href="constantes.php">Constantes en php</a></li>
            <li><a href="asignacion.php">Asignación en php</a></li>
            <li><a href="seleccion.php">Selección en php</a></li>
            <li><a href="ternario.php">Operador Ternario en php</a></li>
            <li><a href="iteraciones.php">Iteraciones en php</a></li>
            <li><a href="funciones.php">Funciones</a></li>
        </ul>        
        
    </body>
</html>
