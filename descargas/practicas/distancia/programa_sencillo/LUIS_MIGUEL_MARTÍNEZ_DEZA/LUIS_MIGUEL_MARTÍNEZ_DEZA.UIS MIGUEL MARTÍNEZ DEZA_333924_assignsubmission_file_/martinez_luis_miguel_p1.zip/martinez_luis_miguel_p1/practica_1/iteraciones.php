<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        $suma=0;
        // suma de los 100 primeros numeros
        for($i=1; $i<=100; $i++){
            $suma+=$i;
        }
        
        //mostramos resultado de la suma
        echo "La suma de los 100 primeros número es: ".$suma;
        ?>
        
        <!-- pausa de 2 segundos y redireccionamiento -->
        <meta HTTP-EQUIV="refresh" content="2; url=index.php">

    </body>
</html>
