<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <H2>Operador Ternario</H2>
        <?php
        // numero aleatorio de 1 a 1000
        $numero=rand(1, 1000);
        
        //mostramos el numero obtenido
        echo "Numero aleatorio: ".$numero."<br />";
        
        //comprobamos si es par
        echo ($numero%2 == 0)? "El número es PAR": "el número es IMPAR";
        
        ?>
     
       <!-- pausa de 2 segundos y redireccionamiento -->
        <meta HTTP-EQUIV="refresh" content="2; url=index.php">
    </body>
</html>
