<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        $a=10;
        $b=20;
        echo "<br />Variable \$a valor INICIAL: $a";
        echo "<br />Variable \$b valor INICIAL: $b <br />";
        
        function duplica(&$a, $b){
            $a*=2;
            $b*=2;
            echo "<br />";
            echo ($a>$b)? "La mayor es \$a, valor $a":"La mayor es \$b, valor $b";
            echo "<br />";
        }
        
        //llamamos a la funcion
        duplica($a,$b);
        
        echo "<br />Variable \$a valor despues de funcion: $a";
        echo "<br />Variable \$b valor despues de funcion: $b";
        
        echo "<br /><br /> Si creamos una variable global que sea igual al segundo"
        . "parametro, mantendría los cambio realizados en su valor despues"
                . "de llamar a la función. "
        
        ?>
        <br /><br /><br />
        <a href="index.php">Volver</a>
    </body>
</html>
