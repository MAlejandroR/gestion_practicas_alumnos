<?php

define("EDAD",36);
define("LIMITE",100);
$restante= LIMITE - EDAD;
$tiempo=2;
printf("Mi edad es ".EDAD." y me quedan para ".$restante." llegar a 100 años.:)");

//sleep($tiempo);


?>