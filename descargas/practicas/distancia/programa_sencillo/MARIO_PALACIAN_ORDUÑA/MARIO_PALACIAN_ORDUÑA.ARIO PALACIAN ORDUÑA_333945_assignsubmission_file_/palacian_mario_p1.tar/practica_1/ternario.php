<?php
//Usando el operador ternario obtén un número aleatorio de 1 a 1000 
//visualiza con un texto si el número es par o impar . Volver al index después de 2 segundos
$aleatorio=rand(1, 1000);
echo $res=($aleatorio%2==0)? $aleatorio." es par":$aleatorio." es impar";
//falta volver al index en 2 seg
?>