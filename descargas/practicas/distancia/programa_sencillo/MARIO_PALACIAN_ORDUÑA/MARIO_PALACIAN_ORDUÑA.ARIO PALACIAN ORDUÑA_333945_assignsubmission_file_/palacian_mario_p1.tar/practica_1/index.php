<?php
echo "Lista de programas basicos de pruebas:<br>"
. "<a href='variables.php'>Variable en php.</a><br>"
. "<a href='constantes.php'>Constantes en php.</a><br>"
. "<a href='asignacion.php'>Asignacion en php.</a><br>"
. "<a href='seleccion.php'>Seleccion en php.</a><br>"
. "<a href='ternario.php'>Ternario en php.</a><br>"
. "<a href='iteraciones.php'>Iteraciones en php.</a><br>"
. "<a href='funciones.php'>Funciones en php.</a><br>"
?>