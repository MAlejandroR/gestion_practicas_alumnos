<?php
/*
   Haz un programa que a partir de precio hora y de número de horas calcule una nómina, 
 * teniendo en cuenta que:
   1-mas de 40 horas son extras (1.5 el precio base)
   2-IRPF < 600E exento
   3-Entre 600 y 800 5%
   4-Mas de 800 12 %
   Nos debe de dar detalle del bruto, descuentos y neto de salario

 */
define("PHORA", 10);
define("NHORAS", 90);
define("HEDEF", 40);

if(NHORAS > HEDEF){
    $nhextras=NHORAS-HEDEF;
    $nhnormales=NHORAS-$nhextras;
    $preciohe=PHORA*1.5;
    $totalhe=($nhextras)*($preciohe); 
    $totalhnormales=$nhnormales*PHORA;
    $total=$totalhe+$totalhnormales;
} else{
    $total=NHORAS*PHORA;
}
$irpf=$total;
$tipoirpf=null;
switch ($irpf){
    case $irpf<601:                //<600 exento
        $tipoirpf=0;
        break;
    case $irpf>600 && $irpf<801:  //-5%
        $tipoirpf=5;
        $irpf-=$irpf*0.95;
        break;
    case $irpf>800:
        $tipoirpf=12;
        $irpf-=$irpf*0.88;        //-12%
        break;
}
echo "Se han trabajado ".NHORAS." horas a ".PHORA." por hora.<br>"
        . "Total horas normales=".$totalhnormales."€ Total Horas extras=".$totalhe."€<br>"
        . "Total Bruto         =".$total."€                   Precio HE=".$preciohe."€<br>"
        . "Dto de irpf         =".$irpf."€                         Irpf=".$tipoirpf."%<br>"
        . "Salario Neto        =".($total-$irpf)."<br>";

?>
