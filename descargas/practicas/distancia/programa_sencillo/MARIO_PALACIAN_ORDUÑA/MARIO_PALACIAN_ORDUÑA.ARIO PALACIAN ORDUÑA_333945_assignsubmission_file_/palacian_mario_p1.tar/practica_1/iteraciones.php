<?php
$contador=0;
$npares=100;
$suma=0;
while($npares>=0){
    if($contador%2 == 0){
        $npares--;
        $suma+=$contador;       
        echo $suma."<br>";
    }
    $contador++;
}
echo "Suma final: ".$suma;
//falta volver al index en 2 seg
?>
