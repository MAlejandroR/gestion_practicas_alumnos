<?php
// niños (0-11)
// adolescentes (12-17) 
// jóvenes (18-35) 
// adultos (36-65) 
// jubilados (66- ...)
$aleatorio=rand(1, 150);
switch ($aleatorio){
    case $aleatorio > 0 && $aleatorio < 12:
        echo "Niños";
        break;
    case $aleatorio > 11 && $aleatorio < 18:
        echo "adolescentes";
        break;
    case $aleatorio > 17 && $aleatorio < 39:
        echo "jovenes";
        break;
    case $aleatorio > 38 && $aleatorio < 66:
        echo "adultos";
        break;
    case $aleatorio > 65 && $aleatorio < 110:
        echo "jubilados";
        break;
    case $aleatorio > 109 && $aleatorio < 151:
        echo "Edad no contenpplada";
        break;
    
}
?>
