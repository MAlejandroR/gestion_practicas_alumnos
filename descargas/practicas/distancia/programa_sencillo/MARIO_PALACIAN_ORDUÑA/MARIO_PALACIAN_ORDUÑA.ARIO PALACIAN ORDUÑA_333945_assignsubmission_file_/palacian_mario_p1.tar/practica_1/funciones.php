<?php

$porreferencia1=6;
$porreferencia2=7;
function duplicado($a,&$b) {
    echo "valor a:".($a*2)." valor b:".($b*2)."<br>";
}
function maximo($a,&$b) {
    echo "a".$a."<br>";;
    echo "b".$b."<br>";
   echo ((($a-$b)>0) && $a!=$b)? $a:$b;
}

duplicado(4,$porreferencia1);
maximo(4,$porreferencia2);
?>
