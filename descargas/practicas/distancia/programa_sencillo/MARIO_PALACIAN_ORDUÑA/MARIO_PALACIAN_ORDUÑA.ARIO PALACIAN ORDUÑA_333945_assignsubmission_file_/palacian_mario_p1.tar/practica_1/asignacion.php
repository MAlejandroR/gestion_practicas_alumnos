<?php
define("NUMERO", 5);
define("TEXTO", "texto");
define("HEXA", 0x5);
define("BINARIO", 0b101);
$exnum= abs(5);
$excadena="hola".TEXTO;
$devdunc= printf("hola");
$exasignacion=$as1="lalala".$as2="bribribri";
echo "<br>constante numerica ".NUMERO;
echo "<br>constante texto ".TEXTO;
echo "<br>constante hexadecimal ".HEXA;
echo "<br>constante binaria ".BINARIO;
echo "<br>expresion numerica ".$exnum;
echo "<br>expresion cadena ".$excadena;
echo "<br>devuelve funcion ".$devdunc;
echo "<br>expresion de asignacion ".$exasignacion;

/*
 * El valor de una expresión que sea una asignación 
 * Visualiza luego los valores especificando de dónde viene su valor 
 * Volver al index después de 5 segundos
 */
?>
