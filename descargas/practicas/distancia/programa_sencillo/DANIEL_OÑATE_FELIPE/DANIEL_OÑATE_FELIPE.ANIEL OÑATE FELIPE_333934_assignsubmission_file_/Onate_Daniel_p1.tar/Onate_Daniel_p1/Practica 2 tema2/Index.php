<!DOCTYPE html>
 
<html>
<head>
    <meta charset="UTF-8">
    <title></title>
</head>
<body>
<?php
 
 
//Defino dos variables con mi nombre y apellidos
	$varNombre = "Daniel";
	$varApellido = "Oñate";
//Visualizo el texto con echo y print, por ejemplo en mi caso (deben de aparecer las comillas del ejemplo
// mi nombre es "Manuel" y mi apellido es "Romero"
//1)con echo pasando varios argumentos (separadados por coma)
	echo "--Visualizo el texto con echo y print";
	echo '<br>';
	echo "con echo pasando varios argumentos (separadados por coma)";
	echo '<br>';
	echo 'Mi nombre es ','"',$varNombre,'"',' y mi apellido es ','"', $varApellido,'"';
	echo '<br>';
	echo '<br>';
//2)con print
	echo "--Con print";
	echo '<br>';
	print 'Mi nombre es "'.$varNombre.'" y mi apellido es "'.$varApellido.'"';
	echo '<br>';
	echo '<br>';
//3,4 y 5)Explica en el fichero diferencias entre echo y print y semejanzas.
echo "--Explica en el fichero diferencias entre echo y print y semejanzas";
	echo "Mientras que con la función echo podemos imprimir directamente varias cadenas a la vez, con la función print solo podremos imprimir una cadena cada vez";
	echo '<br>';
	echo "La función print siempre devuelve como resultado el número 1";
	echo '<br>';
	echo "Ambas funciones nos permiten mostrar un output en pantalla y ambas funciones no llevan paréntesis al momento de llamarlas";
	echo '<br>';
	echo '<br>';

//6) Indica Por qué puedes pasar los argumentos sin usar paréntesis
echo "--Indica Por qué puedes pasar los argumentos sin usar paréntesis";
	echo "A echo se le pueden pasar los argumentos sin usar parentesis porque no es una función, es una construcción del lenguaje, y no se comporta como una función";
	echo '<br>';
	echo '<br>';
 
/*7) Sintaxis heredoc,*/
//Asigna a una variable llamada informe un texto de cinco líneas,
	
//la etiqueta de finalización es FIN
//Posteriormente visualizas el texto
	
// El contenido de 'informe' es:
//   ........
// aquí aparecer el contenido del informe
// debe de respetarse el número de 5 líneas asignadas previamente";
//Tener cuidado con que la etiqueta no lleve en esa línea ningún otro carácter (espacios en blanco o tabulacones)
 echo "--Asigna a una variable llamada informe un texto de cinco líneas,posteriormente visualizas el texto";
	echo '<br>';

	$informe = <<<FIN
	
<pre>
Esta es la primera.
A continuación va la segunda.
La tercera ya en el medio.
La cuarta que es la penúltima.
Y la última la quinta.
</pre>

FIN;
	echo "Este es un informe que tiene cinco líneas";
 	echo '<br>';
	print $informe;
 	echo '<br>';
 	echo '<br>';
	
/*PROBANDO VARIABLES (del 8 al 19)*/
//Crea una variable y asígnale un valor
	$variablePruebas = 25;
//visualiza el valor de la variable y el tipo que eś
echo "--visualiza el valor de la variable y el tipo que eś";
 	echo '<br>';

	echo "El valor de la variable es: ", $variablePruebas," y su tipo es: ", gettype($variablePruebas);
 	echo '<br>';
//Cambia la variable a los siguientes tipos :boolean, float, string y null,  y visualizar su valor y tipo 
echo "--Cambia la variable a los siguientes tipos :boolean, float, string y null,  y visualizar su valor y tipo ";
	$variablePruebas = true;
 	echo '<br>';

	echo "El valor de la variable es: ", $variablePruebas," y su tipo es: ", gettype($variablePruebas);
 	echo '<br>';
	$variablePruebas = 2.3;
	echo "El valor de la variable es: ", $variablePruebas," y su tipo es: ", gettype($variablePruebas);
 	echo '<br>';
	$variablePruebas = "Hola";
	echo "El valor de la variable es: ", $variablePruebas," y su tipo es: ", gettype($variablePruebas);
	echo '<br>';
	$variablePruebas = null;
	echo "El valor de la variable es: ", $variablePruebas," y su tipo es: ", gettype($variablePruebas);
 	echo '<br>';

 
//Prueba a ver el valor y tipo de una variable no definida previamente
echo "--Prueba a ver el valor y tipo de una variable no definida previamente";
 	echo '<br>';

	echo "El valor de la variable es: ", $a," y su tipo es: ", gettype($a);
	echo '<br>';
	echo "<br>";
/* 20)Visualiza el código ascii del valor 64 al 122 en carácter usando la función ascii  .. puedes usar la función printf o  bien char() ..*/
	echo "--Visualiza el código ascii del valor 64 al 122 en carácter";
		echo '<br>';

	for ($i = 64;$i<=122 ; $i++) {
		echo $i." = ".chr($i);
		echo "<br>";
    }
	echo "<br>";
  	echo '<br>';

//21)Visualiza el contenido de la función time() y explica su valor
echo "--Visualiza el contenido de la función time() y explica su valor";
	echo '<br>';

	echo time();
	echo "<br>";
	echo "Devuelve la diferencia de segundos desde ahora hasta la fecha Unix (1 de Enero de 1970 00:00:00 GMT)";
	echo "<br>";
//22)Obtén la fecha actual y visualiza su valor con formato dia-mes-año en número usa la función date() para ello
echo "--Obtén la fecha actual y visualiza su valor con formato dia-mes-año en número";
	echo '<br>';

	$fecha = date("d.m.y");
	echo $fecha;
	echo "<br>";
  	echo '<br>';

//23,24,y 25)Obtener los días, luego horas y luego minutos transcurridos desde el 1/1/1970 (round() o floor() para redondear
	echo "--Obtener los días, luego horas y luego minutos transcurridos desde el 1/1/1970";
 	echo '<br>';

	$minutos =floor(time()/60);
	$horas = floor($minutos/60);
	$dias=floor($horas/24);
	echo $dias." Dias desde 1/1/1970";
	echo "<br>";
	echo $horas." Horas desde 1/1/1970";
	echo "<br>";
	echo $minutos." Minutos desde 1/1/1970";
	echo "<br>";
 	echo '<br>';

//Usando la función setlocale(...) y strftime(...)
//Puede ser que tengas que habilitar el idioma en el sistema con locale-gen
//26)  Obtén la fecha actual con formato por ejemplo domingo, 28 de octubre de 2018
//27)  Ahora con formato en inglés  Sunday, 28 October 2018
//28) y con formato en francés  dimanche, 28 octobre 2018
echo "--Obtén la fecha actual con formato por ejemplo domingo, 28 de octubre de 2018";
 	echo '<br>';

	setlocale(LC_ALL, "es_ES");
	echo strftime("%A, %d %B %G");
	echo "<br>";
	setlocale(LC_ALL, "en_UK");
	echo strftime("%A, %d de %B de %G");
	echo "<br>";
	setlocale(LC_ALL, "fr_FR");
	echo strftime("%A, %d %B %G");
	echo "<br>";
 	echo '<br>';

// 29-30)Asigna a una variable la fecha de tu cumpleaños
// Realiza una operación y obtén tu edad en años, meses y días (valor entero).
// tienes 23 años, 10 meses y 4 días
echo "--Asigna a una variable la fecha de tu cumpleaños ,ealiza una operación y obtén tu edad en años, meses y días";
 	echo '<br>';

	$miFechaCumple = new DateTime('24-10-1994');
	$fechaActual = new DateTime('now');
	$diferencia = $miFechaCumple->diff($fechaActual);
	echo $diferencia->format('%y años, %m meses y %d días');
	echo "<br>";
 	echo '<br>';

//31-32)Asigna a una variable una fecha de 30/10/1969 (mira las funciones strtotime() o bien mktime() para ello
// Obtén su edad en años, en meses y luego en días siempre redondeando
// tienes xx años
// tienes xx meses
// tienes xx días
echo "--Asigna a una variable una fecha de 30/10/1969, Obtén su edad en años, en meses y luego en días siempre redondeando";
 	echo '<br>';

	$fecha = new DateTime('30-10-1969');
	$diferencia = $fecha->diff($fechaActual);
	echo $diferencia->format('tienes %y años');
	echo "<br>";
	echo $diferencia->format('tienes %m meses');
	echo "<br>";
	echo $diferencia->format('tienes %d días');
	echo "<br>";
 	echo '<br>';


//33-36). Usa la función getdate(...) y visualiza con la función print_r(.) el valor que retorna, comenta el resultado
//. Si escribo getdate(1) podrías explicar el contenido del array que nos retorna
//. Obtener la edad de una persona nacida el 1/1/1969
echo "--------------------------------------------------------------------------------------";
//37-64)Explica el siguiente código observando el resultado que se produce fuente obtenido en parte de http://php.net/manual/es/function.strtotime.php
echo "<hr>";
echo strtotime("now"), "<br>";
echo date('d-m-Y', strtotime("now")), "<br>";
echo strtotime("27 September 1970"), "<br>";
echo date('d-m-Y',strtotime("10 September 2000")), "<br>";
echo strtotime("+1 day"), "<br>";
echo date('d-m-Y',strtotime("+1 day")), "<br>";
echo strtotime("+1 week"), "<br>";
echo date('d-m-Y',strtotime("+1 week")), "<br>";
echo strtotime("+1 week 2 days 4 hours 2 seconds"), "<br>";
echo date('d-m-Y',strtotime("+1 week 2 days 4 hours 2 seconds")), "<br>";

echo strtotime("next Thursday"), "<br>";
echo date('d-m-Y',strtotime("next Thursday")), "<br>";

echo strtotime("last Monday"), "<br>";
echo date('d-m-Y',strtotime("last Monday")), "<br>";
echo "<hr>";
echo '<br>';
echo '<br>';

echo <<<FIN
	
<pre>
En este fragmento de código, se observa como manipula diferentes fechas y formatos para mostrar, mostrando cada dos líneas el timestamp de una fecha, y luego ese timestamp formateado.
En la primera línea vemos como muestra la fecha actual, lo que mostrara el timestamp de ella ("now").
En la siguiente observamos que mete el timestamp de la fecha actual en la funcion date, asignándole el formato deseado dia-mes-año.
A continuación, en las dos siguientes líneas hace el mismo proceso pero pasandole una fecha escrita ("27 September 1970" y "10 September 2000").
En las dos siguientes se ve que hace el mismo proceso, pero asignando como fecha la actual más 1 día("+1 day").
A continuación realiza los mismos pasos, asignando esta vez como fecha, la actual más 1 semana("+1 week").
En las dos siguientes líneas, vuelve a mostrar por pantalla el timestamp de la fecha, esta vez, la actual mas 1 semana, 2 días, 4 horas y 2 segundos, y luego lo muestra con formato de fecha("+1 week 2 days 4 hours 2 seconds").
En las siguientes líneas vuelve a hacer el mismo proceso, esta vez pasando como parametro el siguiente jueves("next Thursday").
A continuación, en las dos últimas vuelve a repetir el proceso pasando como parametro el último lunes("last Monday").
</pre>

FIN;
?>
 
</body>
</html>