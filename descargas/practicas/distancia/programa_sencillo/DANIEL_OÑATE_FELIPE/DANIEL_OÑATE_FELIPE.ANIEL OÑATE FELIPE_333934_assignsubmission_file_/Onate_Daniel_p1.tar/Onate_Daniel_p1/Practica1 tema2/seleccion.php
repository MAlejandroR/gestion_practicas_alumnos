<!DOCTYPE html>
	<html>
	<head>
		<title>Ejercicio 4</title>
		<meta http-equiv="refresh" content="2;URL=./Index.php"/>
	</head>
	<body>
		<h1>Selección en php</h1>
		<?php
		$edadAleatoria = rand(1,150);
		switch($edadAleatoria){
			case $edadAleatoria>=0 && $edadAleatoria<=11:
				echo $edadAleatoria." años, edad comprendida en el rango niños";
				break;
			case $edadAleatoria>=12 && $edadAleatoria<=17:
				echo $edadAleatoria." años, edad comprendida en el rango adolescentes";
				break;
			case $edadAleatoria>=18 && $edadAleatoria<=35:
				echo $edadAleatoria." años, edad comprendida en el rango jóvenes";
				break;
			case $edadAleatoria>=36 && $edadAleatoria<=65:
				echo $edadAleatoria." años, edad comprendida en el rango adultos";
				break;
			case $edadAleatoria>=66 && $edadAleatoria<=110:
				echo $edadAleatoria." años, edad comprendida en el rango jubilados";
				break;
			default:
				echo $edadAleatoria." años, no contemplada en nuestra encuesta";
				break;
		}
		?>
	</body>

</html> 