<!DOCTYPE html>
	<html>
	<head>
		<title>Ejercicio 6</title>
		<meta http-equiv="refresh" content="2;URL=./Index.php"/>
	</head>
	<body>
		<h1>Iteraciones en php</h1>
		<?php
			$cont=0;
			$acum=0;
			for($i=2;$i<=200;$i+=2){
				$acum+=$i;
				$cont++;
			}
			echo "La suma de los ".$cont." primeros números pares es: ".$acum;
		?>
	</body>

</html> 