<!DOCTYPE html>
	<html>
	<head>
		<title>Ejercicio 2</title>
		<meta http-equiv="refresh" content="2;URL=./Index.php"/>
	</head>
	<body>
		<h1>Constantes en php</h1>
		<?php
		const EDAD = 25;
		
		echo "Tengo ".EDAD." años, me quedan ".(100-EDAD)." años para llegar a 100";
		?>
	</body>

</html> 