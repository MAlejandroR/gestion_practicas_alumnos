<!DOCTYPE html>
	<html>
	<head>
		<title>Ejercicio 7</title>
	</head>
	<body>
		<h1>Funciones</h1>
		<?php
			$a=3;
			$b=7;
			$textoB1= "Los valores de las variables antes de invocar a la función son:";
			mostrarValores($a, $b, $textoB1);

			cambioValores($a,$b);
			
			$textoB2= "Los valores de las variables antes de invocar a la función son:";
			mostrarValores($a, $b, $textoB2);
			
		?>
	</body>

</html> 

<?php
		function CambioValores(&$a, $b)
		{
			$textoF1="Los valores de las variables dentro de la función, antes de modificar los parámetros, son:";
			mostrarValores($a, $b, $textoF1);
			
			$ret=0;
			$a = $a*2;
			$b = $b*2;
			
			$textoF2="Los valores de las variables dentro de la función, despues de modificar los parámetros, son:";
			mostrarValores($a, $b, $textoF2);

			if($a>=$b){
				$ret=$a;
			}else{
				$ret=$b;
			}
		}
		
		function mostrarValores($a, $b, $texto){
			echo $texto;
			echo '<br />';
			echo "- a= ".$a;
			echo '<br />';
			echo "- b= ".$b;
			echo '<br />';
		}

?>