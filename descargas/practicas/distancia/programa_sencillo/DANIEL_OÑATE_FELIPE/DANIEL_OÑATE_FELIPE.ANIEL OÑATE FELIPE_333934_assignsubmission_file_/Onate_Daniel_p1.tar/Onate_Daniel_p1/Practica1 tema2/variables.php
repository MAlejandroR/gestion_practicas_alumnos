 <!DOCTYPE html>
	<html>
	<head>
		<title>Ejercicio 1</title>
		<meta http-equiv="refresh" content="5;URL=./Index.php"/>
	</head>
	<body>
		<h1>Variables en php</h1>
		<table border=1px>
			<tr>
				<th>Valores Asignados</th>
			</tr>
			<tr>
				
				<td>
					<?php
					$varEntero = 94;
					print "varEntero = 94, valor ".$varEntero;
					?>
				</td>
			</tr>
			<tr>
				
				<td>
					<?php
					$varOctal = 0345;
					print "varOctal = 0345, valor ".$varOctal;
					?>
				</td>
			</tr>
			<tr>
				
				<td>
					<?php
					$varHexadecimal = 0xABC39;
					print "varHexadecimal = 0xABC39, valor ".$varHexadecimal;
					?>
				</td>
			</tr>
			<tr>
				<td>
					<?php
					$varBinaria = 0b01101;
					print "varBinaria = 0b01101, valor ".($varBinaria);
					?>
				</td>
			</tr>
			<tr>
				<td>
					<?php
					$varString = "Cadena número 1 del ejercicio";
					print "varString = Cadena número 1 del ejercicio con comilla doble, valor ".$varString;
					?>
				</td>
			</tr>
			<tr>
				
				<td>
					<?php
					$varString2 = 'Cadena número 2 del ejercicio';
					print "varString2 = Cadena número 2 del ejercicio con comilla simple, valor ".$varString2;
					?>
				</td>
			</tr>
			<tr>
				<td>
					<?php
					$varStringMultilinea = <<< FIN

Cadena
Multilínea
Hasta aqui

FIN;
					print "varStringMultilinea String multilinea sin pre, valor ".$varStringMultilinea;
					?>
				</td>
			</tr>
			<tr>
				<td>
					<?php
					$varStringMultilinea2 = <<< FIN
<pre>

Cadena
Multilínea
Hasta aqui

</pre>
FIN;
					print "varStringMultilinea2 String multilinea con pre, valor ".$varStringMultilinea2;
					?>
				</td>
			</tr>
			<tr>
				<td>
					<?php
					$varFloat = 1.2343223000332;
					print "varFloat =  1.2343223000332, valor ".$varFloat;
					?>
				</td>
			</tr>
			<tr>
				<td>
					<?php
					$varNotCientifica = 3.628000e+1;
					print "varNotCientifica = 3.628000e+1, valor ".$varNotCientifica;
					?>
				</td>
			</tr>
			<tr>
				<td>
					<?php
					$varNull = null;
					print "varNull = null, valor ".$varNull;
					?>
				</td>
			</tr>
			<tr>
				<td>
					<?php
					$varTrue = true;
					print "varTrue = true, valor ".$varTrue;					
					?>
				</td>
			</tr>
			<tr>
				<td>
					<?php
					$varFalse = false;
					print "varFalse = false, valor ".$varFalse;					
					?>
				</td>
			</tr>
		</table>
	</body>

</html> 