 <!DOCTYPE html>
	<html>
	<head>
		<title>Practica 1</title>
	</head>
	<body>
		<h1>Lista de programas básico de pruebas</h1>
		<ol>
				<li><a href="variables.php">Variables en php</a></li>
				<li><a href="constantes.php">Constantes en php</a></li>
				<li><a href="asignacion.php">Asignación en php</a></li>
				<li><a href="seleccion.php">Selección en php</a></li>
				<li><a href="ternario.php">Operador ternario en php</a></li>
				<li><a href="iteraciones.php">Iteraciones en php</a></li>
				<li><a href="funciones.php">Funciones</a></li>
		</ol>
	</body>
</html> 