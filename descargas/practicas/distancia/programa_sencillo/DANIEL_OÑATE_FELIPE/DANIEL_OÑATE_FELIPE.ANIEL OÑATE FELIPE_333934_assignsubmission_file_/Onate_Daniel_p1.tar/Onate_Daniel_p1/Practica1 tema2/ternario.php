<!DOCTYPE html>
	<html>
	<head>
		<title>Ejercicio 5</title>
		<meta http-equiv="refresh" content="2;URL=./Index.php"/>
	</head>
	<body>
		<h1>Operador ternario en php</h1>
		<?php
			$numAleatorio = rand(1,1000);
			echo $numAleatorio%2==0?"Número: ".$numAleatorio.", par":"Número: ".$numAleatorio.", impar";
			/*if($numAleatorio % 2 == 0){
				echo "Número: ".$numAleatorio.", par";
			}else{
				echo "Número: ".$numAleatorio.", impar";
			}*/
		?>
	</body>

</html> 