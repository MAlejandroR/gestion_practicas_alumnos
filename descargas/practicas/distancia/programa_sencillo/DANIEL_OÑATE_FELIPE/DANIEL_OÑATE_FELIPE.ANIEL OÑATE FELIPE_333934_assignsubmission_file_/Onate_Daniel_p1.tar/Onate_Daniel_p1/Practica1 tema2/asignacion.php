<!DOCTYPE html>
	<html>
	<head>
		<title>Ejercicio 3</title>
		<meta http-equiv="refresh" content="5;URL=./Index.php"/>
	</head>
	<body>
		<?php $variable=1; ?>
		<h1>Asignación en php</h1>
		<table>
			<tr>
				<th>Valor de variable</th>
			</tr>
			<tr>
				<td>
					<?php
						$variable = 23;
						echo "Expresión asignada 23, valor de la expresión ".$variable;
					?>
				</td>
			</tr>
			<tr>
				<td>
					<?php
						$variable = "Prueba String";
						echo "Expresión asignada Prueba String, valor de la expresión ".$variable;
					?>
				</td>
			</tr>
			<tr>
				<td>
					<?php
						$variable = 0xABC124;
						echo "Expresión asignada 0xABC124, valor de la expresión ".$variable;
					?>
				</td>
			</tr>
			<tr>
				<td>
					<?php
						$variable = 0b01001;
						echo "Expresión asignada 0b01001, valor de la expresión ".$variable;
					?>
				</td>
			</tr>
			<tr>
				<td>
					<?php
						$variable = 7+3;
						echo "Expresión asignada 7+3, valor de la expresión ".$variable;
					?>
				</td>
			</tr>
			<tr>
				<td>
					<?php
						$variable = "Prueba "."String";
						echo "Expresión asignada Prueba .String, valor de la expresión ".$variable;
					?>
				</td>
			</tr>
			<tr>
				<td>
					<?php
						$variable = print("PruebaString");
						echo "Expresión asignada print(PruebaString), valor de la expresión ".$variable;
					?>
				</td>
			</tr>
			<tr>
				<td>
					<?php
						$variable = $a=3;
						echo "Expresión asignada $a=3, valor de la expresión ".$variable;
					?>
				</td>
			</tr>
		</table>
	</body>

</html> 