<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Instrucciones</title>
        <style>          
            *{
                background: #222;
            }
            
            h1 {
                font-size: 3em;
                text-transform: uppercase;
                text-align: center;
                text-decoration: underline;
                color: #fd2e42;
            }
            
            h2 {
                text-align: center;
                text-transform: uppercase;
                color: white;
            }
            
            #content {
                margin: 50px auto;
                width: 70%;
                color: #b0abab;
            }
            
            hr {
                border-top: 2px solid #fd2e42;
            }
        </style>
    </head>
    <body>        
        <div id="content">            
            <h1>Probando instrucciones de php</h1>
            <hr />
        <?php
            //Defino dos variables con mi nombre y apellidos
            $name = "Dylan";
            $lastname = "Galindo";
            //Visualizo el texto con echo y print, por ejemplo en mi caso (deben de aparecer las comillas del ejemplo
            // mi nombre es "manolo" y mi apellido es "romero"
            echo "<h2>Defino dos variables con mi nombre y apellidos</h2>";
            echo "Mi nombre es \"$name\" y mi apellido es \"$lastname\" (echo) <br>";
            print "Mi nombre es \"$name\" y mi apellido es \"$lastname\" (print) <br>";
            //1)con echo pasando varios argumentos (separadados por coma)
            print "<hr /><h2>Defino dos variables con mi nombre y apellidos pasando varios argumentos</h2>";
            echo "1. Mi nombre es \"$name\" ", "y mi apellido es \"$lastname\"", "(ECHO = con varios argumentos)<br>";
            //2)con print            
            print "2. No se puede separar con comas, print no lo permite solo impreme una cadena... (PRINT = con varios argumentos)<br>";
            //print "2. Mi nombre es \"$name\" ", "y mi apellido es \"$lastname\"", "(PRINT = con varios argumentos)";
            //En tal caso seria pasar como la siguiente varios prints...
            print "Con varios print, quedaria el resultado deseado...<br>";
            print "2. Mi nombre es \"$name\"";
            print "y mi apellido es \"$lastname\"";
            print "(PRINT = con varios argumentos)";
            
            //Explica en el fichero diferencias entre echo y print y semejanzas.
            print "<hr /> <h2>Explica en el fichero diferencias entre echo y print y semejanzas.</h2>";
            echo "echo: puedes imprimir varias cadenas a la vez (varios argumentos).<br>";
            print "print: solo imprime una cadena cada vez que sea llamada la función (un argumento) y nos devuelve un valor booleano normalmente 1<br>";
            echo "Ambos son constructores de lenguaje que muestran cadenas de texto con algunas diferencias "
                . "mencionadas anteriormente, no es necesario poner entre parentesis a la funcion ya que es un contructor del lenguaje...";
            //Por qué puedo pasar los argumentos sin usar paréntesis
            print "<hr />";
            echo "<h2>Por qué puedo pasar los argumentos sin usar paréntesis</h2>";
            echo "echo y print no son como tal una función (es un constructor de lenguaje) de tal manera que <b>no es necesario usar los paréntesis.</b> "
            . "Además en echo para pasar varios argumentos no tiene que ir entre paréntesis";
           
            /*Sintaxis heredoc,*/
             print "<hr /> <h2>Sintaxis heredoc</h2>";
            //Asigna a una variable llamada informe un texto de cinco líneas,
            //la etiqueta de finalización es FIN
            //Posteriormente visualizas el texto
            // El contenido de 'informe' es
            // aquí aparecer el contenido del infoorme
            // respetando el número de 5 líneas asignadas previamente";
            //Tener cuidado con que la etiqueta no lleve en esa línea ningún otro carácter (espacios en blanco o tabulacones)
            $informe = <<<FIN
Esta es una cadena
de caracteres que se asignará
a la variable informe
y termina con la palabra 
con la que hemos empezado
FIN;
            echo "El contenido de 'informe' tiene 5 líneas y es: <br/><pre>".$informe."<br></pre>";
            
            /*PROBANDO VARIABLES*/
            print "<hr /><h2>PROBANDO VARIABLES</h2>";
            //Crea una variable y asígnale un valor
            $info = 24;
            //visualiza el valor de la variable y el tipo que eś
            echo "<b>Contenido:</b> $info <br><b>Tipo de variable:</b> ".gettype($info);
            //Cambia a los siguientes tipos (boolean, float, string y null y visualizar su valor)            
            $info = true;
            echo '<br><br />';
            echo "<b>Contenido:</b> $info <br><b>Tipo de variable:</b> ".gettype($info);
            
            $info = 55.95;
            echo '<br><br />';
            echo "<b>Contenido:</b> $info <br><b>Tipo de variable:</b> ".gettype($info);
            
            $info = "Ahora es string...";
            echo '<br><br />';
            echo "<b>Contenido:</b> $info <br><b>Tipo de variable:</b> ".gettype($info);
            
            $info = null;
            echo '<br><br />';
            echo "<b>Contenido:</b> $info <br><b>Tipo de variable:</b> ".gettype($info);         
            
            //Prueba a ver el valor y tipo de una variable no definida previamente
            echo "<p>Prueba a ver el valor y tipo de una <b>variable no definida previamente</b></p>";
            echo "<b>Contenido:</b> $error <br><b>Tipo de variable:</b> ".gettype($error);
            
            /*VISUALIZA LAS VARIABLES USANDO LA FUNCION printf*/
            print "<hr /><h2>VISUALIZA LAS VARIABLES USANDO LA FUNCION printf</h2>";
            $info = 24;
            echo "<p>Var int con printf: ".printf($info)."</p>";
            
            $info = 24.865;
            echo printf("Sacando 1 decimal de (24.865): %1\$.1f",$info);
            
            $info = true;
            echo "<p>Var booleana (true) con printf: ".printf($info)."</p>";
            
            $info = "Ahora es string...";
            echo "<p>Var=string con printf: ".printf($info)."</p>"; // Muestra longitud del txt = 18
            
            $info = null;
            echo "<p>Var=null con printf: ".printf($info)."</p>";
            
            //Visualiza el contenido de la función time() y explica su valor
            print "<hr /><h2>Visualiza el contenido de la función time() y explica su valor</h2>";            
            echo "<p><b>Devuelve la fecha Unix actual, tiempo pasado desde (1 de Enero de 1970 00:00:00 GMT) en segundos</b></p>";
            $fechaActual_unix = time();
            echo "<b>Funcion time():</b> $fechaActual_unix";
            //Obtén la fecha actual y visualiza su valor con formato dia-mes-año en número
            echo "<p><b>Obtén la fecha actual y visualiza su valor con formato dia-mes-año en número</b></p>";
            $fecha_actual = date('d-m-Y'); // Fecha actual (formato en nº dia-mes-año)...
            echo "<b>Fecha actual:</b> $fecha_actual";
            //Obtener los días, luego meses y luego años transcurridos desde el 1/1/1970 (round() o floor() para redondear
            echo "<p><b>Obtener los días, luego meses y luego años transcurridos "
                . "desde el 1/1/1970 round() o floor() para redondear</b></p>";
            // Convertir la fecha unix (segundo) en dias
            $dia = $fechaActual_unix / (60 * 60 * 24); //(seg, min, hora) 86400s = 24h
            // Hasta hora nos dara un nº float (17822.574571759), tenemos que redondear...
            $dia = floor($dia); //Floor redonde a la baja, y a la alta el round($dia); 
            // Para los meses y años
            $mes = $fechaActual_unix / (60 * 60 * 24 * 30);//(seg, min, hora, mes)
            $mes = round($mes); //2592000
            $anio = floor($fechaActual_unix / (365 * 24 * 3600)); // bisiestos... 366
            print "<b>Días:</b> $dia, <b>Meses:</b> $mes, <b>Años:</b> $anio";
            
            // Obtén la fecha actual con formato por ejemplo
            // Lunes, día 25 de enero de 2013
            echo "<p><b>Obtén la fecha actual con formato por ejemplo:</b></p>";
            setlocale(LC_ALL, "es_ES.utf8"); // En español la fecha...
            echo strftime("%A, día %d de %B de %Y")."<br>"; //hora actual
            $s = "Lunes"; $d = 25; $m = 01; $a = 2013;
            print strftime("$s, día $d de $m de $a")." (Fecha dada en variables...)";
            
            //Asigna a una variable la fecha de tu cumpleaños
            echo "<p><b>Asigna a una variable la fecha de tu cumpleaños</b></p>";
            $cumpleaños = new DateTime("1994-06-25"); //DateTime(YYYY-MM-DD);
            // Realiza una operación y obtén tu edad en años, meses y días (valor entero).
            // tienes 23 años, 10 meses y 4 días             
            $fecha_actual = new DateTime(); // Fecha actual...
            // Con la funcion diff (DateTime::diff) Devuelve la diferencia entre dos objetos DateTime
            $resultado = $fecha_actual->diff($cumpleaños);
            echo "Tienes ".$resultado->y." años, ".$resultado->m." meses y ".$resultado->d." días (usando funcion diff 'DateTime::diff')";

            //Asigna a una variable una fecha de 30/10/1969
            // Obtén su edad en años, en meses y luego en días siempre redondeando
              //tienes 23 años
              // tienes 286 meses
              // tienes 8737 días
            $fecha_cumple = "25/06/1994";
/*            
            // Separamos el string cumpleaños en variables...
            $separa = explode("/",$cumpleaños);
            $dia = (int)$separa[0];// primer bloque 25
            $mes = (int)$separa[1];
            $anio = (int)$separa[2];

            // restamos año actual con el año de nacimiento para saber la edad...
            print "<br><br />";
            print "<p>Obtén su edad en años, en meses y luego en días siempre redondeando</p>";            
            // Meses y dias...
            $f1 = mktime(0,0,0,date("m"),date("d"),date("Y")); // Fecha actual (seg)
            $f2 = mktime(0,0,0,$mes,$dia,$anio); // Fecha cumple en unix (segundos)
            $tiempo = $f1 - $f2;
            $meses = floor($tiempo / (60 * 60 * 24 * 30));// (seg, min, hora, mes) 86400s = 24h
            $dias = floor($tiempo / (60 * 60 * 24)); //(seg, min, hora) 86400s = 24h
            print "Tienes ".(date("Y") - $anio)." años <br>"; // Pero no controlamos el mes...
            print "Tienes $meses meses <br>";
            print "Tienes $dias días <br>";
*/
            print "<br><br />";
            print "<p>Obtén su edad en años, en meses y luego en días siempre redondeando (Cumple = $fecha_cumple)</p>";     
            // Damos formato a la fecha para DateTime(YYYY-MM-DD)... para los años...
            $fecha = date_create_from_format('d/m/Y', $fecha_cumple);
            $cumpleaños = new DateTime(date_format($fecha, 'Y-m-d')); // Cumpleaños "25/06/1994" en "1994-06-25"
            // Con la funcion diff (DateTime::diff) Devuelve la diferencia entre dos objetos DateTime
            $resultado = $fecha_actual->diff($cumpleaños);
            print "Tienes ".$resultado->y." años <br>";
            
            // Calcular meses y dias en Unix (seg)...
            // Separamos el string $fecha_cumple en variables...
            $separa = explode("/",$fecha_cumple);
            $dia = (int)$separa[0];// primer bloque 25
            $mes = (int)$separa[1];
            $anio = (int)$separa[2];       
            // Meses y dias en Unix (seg)...
            $f1 = mktime(0,0,0,date("m"),date("d"),date("Y")); // Fecha actual (seg)
            $f2 = mktime(0,0,0,$mes,$dia,$anio); // Fecha cumple en unix (segundos)
            $tiempo = $f1 - $f2;
            // Sacamos el redondeo de los meses que han pasado, dias...
            $meses = floor($tiempo / (60 * 60 * 24 * 30));// (seg, min, hora, mes) 86400s = 24h
            $dias = floor($tiempo / (60 * 60 * 24)); //(seg, min, hora) 86400s = 24h
            print "Tienes $meses meses <br>";
            print "Tienes $dias días <br>";
            
            echo "<hr />";
            // Usa la función getdate(...) y visualiza con la función print_r(.) el valor que retorna, comenta el resultado
            echo "<p><b>Usa la función getdate(...) y visualiza con la función print_r(.) "
                . "el valor que retorna, comenta el resultado</b></p>";
            echo print_r(getdate());
            print "<p>Devuelve un array asociativo que contiene información de la fecha/hora"
                . " (con la marca de tiempo timestamp). Algunos de los elementos son los"
                . " segundos, hora, minutos, segundos desde la Época Unix...</p>";
            // Si escribo getdate(1) podrías explicar el contenido del array que nos retorna
            echo "<p><b>Si escribo getdate(1) podrías explicar el contenido del array que nos retorna</b></p>";
            echo print_r(getdate(1));
            print "<p>Nos retorna todo los 1º valores, es decir, el segundo 1, minuto 0, el 1º año epoca unix...</p>";
            
            // Obtener la edad de una persona nacida el 1/1/1969
            echo "<p><b>Obtener la edad de una persona nacida el 1/1/1969</b></p>";
            $nacimiento = "1/1/1969"; // Fecha para saber la edad...
            // Damos formato a la fecha para DateTime(YYYY-MM-DD)...
            $fecha = date_create_from_format('d/m/Y', $nacimiento);
            $edad = new DateTime(date_format($fecha, 'Y-m-d'));
            $fecha_actual = new DateTime(); // Fecha actual...
            // Con la funcion diff (DateTime::diff) Devuelve la diferencia entre dos objetos DateTime
            $resultado = $fecha_actual->diff($edad);
            echo "Naciste $nacimiento fecha actual ".date('d-m-Y').", tienes ".$resultado->y." años. <br>";
            echo "Naciste $nacimiento fecha actual ".date('d-m-Y').", tienes ".$resultado->m." meses.<br>";
            echo "Naciste $nacimiento fecha actual ".date('d-m-Y').", tienes ".$resultado->d." días.";
            
            // Explica el siguiente código observando el resultado que se produce fuente obtenido en parte de http://php.net/manual/es/function.strtotime.php
            echo "<hr>";
            echo "<h2>Explica los siguiente códigos observando el resultado que se produce </h2>";
            print "<p><b>Función strtotime(\"now\") nos indica la fecha actual en la epoca de Unix (el nº de segundos desde el 1 de Enero del 1970 00:00:00 UTC)</b></p>";
            echo strtotime("now"), "<br/>";
            print "<p><b>Con date('d-m-Y', strtotime(\"now\")) dar un formato a la fecha unix date('format', timestamp)</b></p>";
            echo date('d-m-Y', strtotime("now")), "<br/>";
            print "<p><b>Función strtotime(\"27 September 1970\") convertimos la fecha en fecha Unix (segundos)</b></p>";
            echo strtotime("27 September 1970"), "<br/>";
            print "<p><b>Con date('d-m-Y',strtotime(\"10 September 2000\")) cambiar el formato (10 September 2000) a 'd-m-Y'</b></p>";
            echo date('d-m-Y',strtotime("10 September 2000")), "<br/>";
            print "<p><b>Función strtotime(\"+1 day\") no muestra la fecha actual en Unix 'segundos' pero sumando un día (es decir fecha de mañana en Unix)</b></p>";
            echo strtotime("+1 day"), "<br/>";
            print "<p><b>Con date('d-m-Y',strtotime(\"+1 day\")) lo mismo que el anterior fecha Unix de mañana en formato 'd-m-Y'</b></p>";
            echo date('d-m-Y',strtotime("+1 day")), "<br/>";
            print "<p><b>Función strtotime(\"+1 week\") sumar a la fecha Unix actual una semana...</b></p>";
            echo strtotime("+1 week"), "<br/>";
            print "<p><b>Con date('d-m-Y',strtotime(\"+1 week\")) lo mismo que el anterior sumar una semana a la fecha unix actual con formato 'd-m-Y'</b></p>";
            echo date('d-m-Y',strtotime("+1 week")), "<br/>";
            print "<p><b>Función strtotime(\"+1 week 2 days 4 hours 2 seconds\") fecha Unix actual sumarle una semana, 2 días, 4 horas y 2 segundos...</b></p>";
            echo strtotime("+1 week 2 days 4 hours 2 seconds"), "<br/>";
            print "<p><b>Con date('d-m-Y',strtotime(\"+1 week 2 days 4 hours 2 seconds\")) lo mismo que el anteriors sumar 1 semana, 2 días, 4h y 2s pero con formato 'd-m-Y'</b></p>";
            echo date('d-m-Y',strtotime("+1 week 2 days 4 hours 2 seconds")), "<br/>";
            print "<p><b>Función strtotime(\"next Thursday\") mostra el jueves de la semana o el próximo si ya hemos superado (1º jueves que viene)... en fecha Unix</b></p>";
            echo strtotime("next Thursday"), "<br/>";
            print "<p><b>Con date('d-m-Y',strtotime(\"next Thursday\")) mostra el jueves de la semana o el próximo si ya hemos superado, con formato 'd-m-Y'</b></p>";
            echo date('d-m-Y',strtotime("next Thursday")), "<br/>";
            print "<p><b>Función strtotime(\"last Monday\") muestra la fecha del LUNES pasado en fecha Unix (segundos)</b></p>";
            echo strtotime("last Monday"), "<br/>";
            print "<p><b>Con date('d-m-Y',strtotime(\"last Monday\")) muestra la fecha del LUNES pasado, dando formato a la fecha Unix = 'd-m-Y'</b></p>";
            echo date('d-m-Y',strtotime("last Monday")), "<br/>";
            echo "<hr>"
        ?>
        </div>
    </body>
</html>
