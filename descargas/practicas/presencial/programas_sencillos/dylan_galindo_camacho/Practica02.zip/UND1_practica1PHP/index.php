<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>Lista de programas básicos</title>
        <link rel="stylesheet" type="text/css" href="style.css">
    </head>
    <body>
        <div id="content">
            <h1>Lista de programas básico de pruebas</h1>
            <hr />
            <ul>
                <li><a href="http://localhost/UND1_practica1PHP/pages/variables.php">Variables en php</a></li>
                <li><a href="http://localhost/UND1_practica1PHP/pages/constantes.php">Constantes en php</a></li>
                <li><a href="http://localhost/UND1_practica1PHP/pages/asignacion.php">Asignación en php</a></li>
                <li><a href="http://localhost/UND1_practica1PHP/pages/seleccion.php">Selección en php</a></li>
                <li><a href="http://localhost/UND1_practica1PHP/pages/opTernario.php">Operador Ternario en php</a></li>
                <li><a href="http://localhost/UND1_practica1PHP/pages/iteraciones.php">Iteraciones en php</a></li>
                <li><a href="http://localhost/UND1_practica1PHP/pages/funciones.php">Funciones</a></li>
            </ul>
        </div>        
    </body>
</html>
