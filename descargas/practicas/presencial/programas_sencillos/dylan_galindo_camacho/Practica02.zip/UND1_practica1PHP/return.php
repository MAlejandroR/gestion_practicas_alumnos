<?php 
    $txt = $_GET['info'];
    header("Refresh:$txt; url=http://localhost/UND1_practica1PHP/index.php");
?>

<!doctype html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Volver a inicio</title>
        <link rel="stylesheet" type="text/css" href="style.css">
    </head>
    <body>
        <div id="info">
            <p>En <?php print $txt ?> segundos volveras a INICIO...</p>
            <div id="img">.</div>
        </div>
    </body>
</html>
