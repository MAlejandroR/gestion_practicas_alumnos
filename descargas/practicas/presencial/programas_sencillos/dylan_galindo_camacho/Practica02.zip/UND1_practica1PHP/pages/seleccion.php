<?php
    /* Selección en php
        - Usando la selección del tipo switch, haz un programa que genere una edad 
            aleatoria entre 1 y 150 años y nos diga si somos niños (0-11) adolescentes 
           (12-17) jóvenes (18-35) adultos (36-65) jubilados (66- ...)
        - La edad que no esté en el intevalo 0-110 años se visualizará 'edad no 
            contenplada en nuestra encuesta'
        - Volver al index después de 2 segundos 
    */

    // edad aleatoria
    $n = rand(0, 150);
    
    if ($n > 0) {
        // Si no es un nº negativo...
        switch (true) {
            case $n <= 11:
                $txt = "Con $n años, eres un niño";
                break;
            case $n <= 17:
                $txt = "Con $n años, eres un adolescente";
                break;
            case $n <= 35:
                $txt = "Con $n años, eres un joven";
                break;
            case $n <= 65:
                $txt = "Con $n años, eres un adulto";
                break;
            case $n <= 110:
                $txt = "Con $n años, eres un jubilado";
                break;
            default:
                $txt = "$n años, es una edad no contemplada en nuestra encuesta";
                break;
        }
    } else {
        $txt = "$n años, es una edad no contemplada en nuestra encuesta";
    }

    // Clic en el BTN (Volver)
    if (isset($_GET['salir'])) {
        /*
        header("Refresh:2; url=http://localhost/UND1_practica1PHP/index.php");
        echo "En 2 segundos volveras a INICIO";            
        exit(); 
        */
        header("Refresh:0; url=http://localhost/UND1_practica1PHP/return.php?info=2");
    }    
?>

<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="UTF-8">
        <title>Selección en php</title>
        <link rel="stylesheet" type="text/css" href="../style.css">
    </head>
    <body>
        <!-- aside -->
        <div id="aside">
            <h2>Iteraciones tipo switch</h2>
            <div>
                <p><b>switch (true)</b> Puedo hacerlo gracias a la expresividad 
                    de las instrucciones en php</p>
            </div>
                
            <div id="btn">
                <form action="seleccion.php">
                    <input type="submit" name="salir" value="Volver">
                </form>            
            </div>
        </div>
        <!-- FIN aside -->
        
        <!-- Content - article --> 
        <div id="content">
            <h1>Selecciones en php</h1>
            <p><?php print $txt ?></p>
            <p><a href="">Probar otra edad</a></p>
        </div>        
    </body>
</html>