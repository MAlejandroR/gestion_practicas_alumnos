<?php
    /* Haz un ejercicio donde definas la constante edad
        - A la constante Edad le asignas tu edad.
        - Luego visualiza los años que tienes y los años que te quedan para cumplir 100 años
       Volver al index después de 2 segundos
    */

    define("edad", 24);
    const anio = 11;
    
    // Años que faltan para los 100...
    if (edad > 100)
        $define = "Tengo mas de 100 años = ".edad;
    else
        $define = 100-edad;
    
    // Const
    if (anio > 100)
        $const = "Tengo mas de 100 años = ".anio;
    else 
        $const = 100-anio;
    
    // Estilo al resultado
    function color($v) {
        $txt = "<span style='color:blue'><b>$v</b></span>";
        return $txt;
    }
    
    // Funcion para obtener el tipo de variable...
    function tipo($var) {
        return "gettype(".gettype($var).")";
    }
    
    // Clic en el BTN (Volver)
    if (isset($_GET['salir'])) {
        /*
        header("Refresh:2; url=http://localhost/UND1_practica1PHP/index.php");
        echo "En 2 segundos volveras a INICIO";            
        exit(); 
        */
        header("Refresh:0; url=http://localhost/UND1_practica1PHP/return.php?info=2");
    }
    
?>

<!doctype html>
<html lang="es">
    <head>
        <meta charset="UTF-8">
        <title>Constantes en PHP</title>
        <link rel="stylesheet" type="text/css" href="../style.css">
    </head>
    <body>
        <!-- aside -->
        <div id="aside">
            <div>
                <h2>Declarando constantes</h2>
                <div><b>define</b> No funciona en clases</div>
                <div><b>const</b> Funciona tanto en clases como fuera de ellas</div>
            </div>
        
            <div id="btn">
                <form action="constantes.php">
                    <input type="submit" name="salir" value="Volver">
                </form>            
            </div>
        </div>
        <!-- FIN aside -->
        
        <!-- Content - article --> 
        <div id="content">
            <h1>Constantes en PHP</h1>
            
            <h2>Constante declarada con Define</h2>
            <p>Tengo <?php print color(edad) ?> años (Constante declarada con 
                <?php print color($info="define")?>)</p>
            
            <h2>Constante declarada con const </h2>
            <p>Tengo <?php print color(anio) ?> años (Constante declarada con 
                <?php print color($info="const")?>)</p>
            
            <h2>Operación con define</h2>
            <p>Para los 100, me faltan <?php print color($define)?> años (Operación
                de constante con <?php print color($info="define")?>)</p>
            
            <h2>Operación con const</h2>
            <p>Para los 100, me faltan <?php print color($const)?> años (Operación 
                de constante con <?php print color($info="const")?>)</p>
        </div>
    </body>
</html>

