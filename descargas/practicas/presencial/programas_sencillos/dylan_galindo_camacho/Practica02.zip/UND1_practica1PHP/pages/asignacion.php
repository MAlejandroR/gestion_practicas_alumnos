<?php
    /* Asignación en php:    
        Asigna a una variable valores de diferente procedencia
            - Un valor constante numérico
            - Un valor constante string
            - Un valor constante numérica con valor hexadecimal
            - Un valor constante numérica con valor binario
            - Un valor de una expresión numérica
            - Un valor de una expresión de cadena de caracteres
            - Un valor que devuelva una función , por ejemplo la función print
            - El valor de una expresión que sea una asignación
        Visualiza luego los valores especificando de qué donde viene su valor
        Volver al index después de 5 segundos
    */

    const const_num = 5;
    define("const_string", "5.7");
    const const_hex = 0b100001;
    define("const_bin", 01100);
    const const_str = "hola caracola";    
    $exp_num = 5+9;
    $exp_str = "hola"."caracola";
    $fun_print = print("hola caracola");
    $exp_asig = $v=8;

    // Estilo al resultado
    function color($v) {
        $txt = "<span style='color:blue'><b>$v</b></span>";
        return $txt;
    }
    
    // Clic en el BTN (Volver)
    if (isset($_GET['salir'])) {
        /*
        header("Refresh:5; url=http://localhost/UND1_practica1PHP/index.php");
        echo "En 5 segundos volveras a INICIO";            
        exit(); 
        */
        header("Refresh:0; url=http://localhost/UND1_practica1PHP/return.php?info=5");
    }
    
?>


<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="UTF-8">
        <title>Expresión de asignación</title>
        <link rel="stylesheet" type="text/css" href="../style.css">
    </head>
    <body>
        <!-- aside -->
        <div id="aside">
            <h2>Expresión de asignación</h2>
            <div>
                <p><b>Expresión asignada</b> Siguiendo las especificaciones del enuniado.</p>
                <p><b>Valor de la expresión</b> Valor que devuelve la <b>expresión</b>. de asignacion</p>
            </div>
        
            <div id="btn">
                <form action="asignacion.php">
                    <input type="submit" name="salir" value="Volver">
                </form>            
            </div>
        </div>
        <!-- FIN aside -->
        
        <!-- Content - article --> 
        <div id="content">
            <h1>Variables en PHP</h1>
            <table border="1">
                <thead>
                    <tr>
                        <th>Expresión asignada</th>
                        <th>Valor de la expresión</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><?php $a=const_num; print "\$a=$a" ?></td>
                        <td>-<?php print color($a)?>- (const num)</td>
                    </tr>
                    <tr>
                        <td><?php $a=const_string; print "\$a=$a" ?></td>
                        <td>-<?php print color($a)?>- (define string)</td>
                    </tr>
                    <tr>
                        <td><?php $a="0b100001"; print "\$a=$a" ?></td>
                        <td>-<?php print color($a=const_hex)?>- (const hex)</td>
                    </tr>
                    <tr>
                        <td><?php $a="01100"; print "\$a=$a" ?></td>
                        <td>-<?php print color($a=const_bin)?>- (define binario)</td>
                    </tr>
                    <tr>
                        <td><?php $a=const_str; print "\$a=\"$a\"" ?></td>
                        <td>-<?php print color($a)?>- (const string)</td>
                    </tr>
                    <tr>
                        <td><?php $a= "5+9"; print "\$a=$a" ?></td>
                        <td>-<?php print color($a=$exp_num)?>- (expresión num)</td>
                    </tr>
                    <tr>
                        <td><?php $a="\"hola\".\"caracola\""; print "\$a=$a" ?></td>
                        <td>-<?php print color($a=$exp_str)?>- (expresión cadena)</td>
                    </tr>
                    <tr>
                        <td><?php $a="print(\"hola caracola\")"; print "\$a=$a" ?></td>
                        <td>-<?php print color($a=$fun_print)?>- (función print)</td>
                    </tr>
                    <tr>
                        <td><?php $a="(\$v=8)"; print "\$a=$a" ?></td>
                        <td>-<?php print color($a=$exp_asig)?>- (expresión asignación)</td>                        
                    </tr>
                </tbody>
            </table>

        </div>        
    </body>
</html>
