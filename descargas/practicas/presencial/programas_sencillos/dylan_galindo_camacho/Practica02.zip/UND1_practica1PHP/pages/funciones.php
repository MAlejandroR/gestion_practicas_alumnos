<?php 
    /* Funciones en php: 
    Haz una función que reciba dos variables $a y $b $a se ha de pasar por referencia $b por valor.
        - La función duplica el valor de los parámetros
        - La función devuelve el valor mayor de los dos
        - El programa principal creará hará lo siguientes
    
    1.-Crea dos valores en variables
    2.-Visualiza sus valores
    3.-Invoca a la función
    4.-Visualiza los valores de los parámetros
    5.-Hace lo especificado
    6.-Visualiza los valores
    7.-Después de la llamada a la función se visualizarán los valores
    8.-Plantea que pasará si creamos dentro de la función una variable global 
        que sea el igual al segundo parámetro de la función.
    */

    // valor de las variables
    $a = 7;
    $b = 8;
    $antes = ""; 
    $despues = "";
    
    // Funcion con 2 parametros...
    function funcion($a, $b) {
        global $antes;
        global $despues;        
        // 2º Antes de modificar los valores
        $antes = "Dentro de función antes de modificar parámetros: ".color("\$a=$a  \$b=$b");
        
        // 3º Despues de modificar los valores
        $a *=2;
        $b *=2;
        $despues = "Dentro de función después de modificar parámetros: ".color("\$a=$a  \$b=$b");
    }
    
    function var_global($a, $b) {
        // 4º Programa principal, Var global igual al 2º parametro
        // realizamos la operaciones...
        $a *=2;
        $b *=2;
        // Al crear una global el valor sera en asignado ya que los sustituimos...
        // Si lo ponemos antes de la operacion obtendra el valor de la opeacion...
        global $b;             
        $b = color("\$a=$a  \$b=$b"); 
        // nos retornara -> $a=14 $b=8 
        // hara la oparacion de la variable distinta a la global...
        return $b;
    }

    // Estilo al resultado
    function color($v) {
        $txt = "<span style='color:blue'><b>$v</b></span>";
        return $txt;
    }
    
    // Clic en el BTN (Volver)
    if (isset($_GET['salir'])) {
        /*
        header("Refresh:2; url=http://localhost/UND1_practica1PHP/index.php");
        echo "En 2 segundos volveras a INICIO";            
        exit(); 
        */
        header("Refresh:0; url=http://localhost/UND1_practica1PHP/return.php?info=2");
    }   
?>

<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="UTF-8">
        <title>Funciones</title>
        <link rel="stylesheet" type="text/css" href="../style.css">
    </head>
    <body>
        <!-- aside -->
        <div id="aside">
            <div>
                <h2>Funciones</h2>
                <p><b>Función</b></p>
                <p>Recibe dos parámetros (referencia y valor).</p>
                <p>Duplica los valores de los parámetros.</p>
                <p>Visualiza los valores antes y después de modificarlos.</p>
                <br>
                <p><b>Programa principal</b></p>
                <p>Crea dos variables.</p>
                <p>Visualiza sus valores.</p>
                <p>Invoca a la función.</p>
                <p>Vuelve a visualizar los valores.</p>
                <hr />
                <p><em>Plantea globalizar tanto $a como $b, y comprende el resultado</em></p>
            </div>
        
            <div id="btn">
                <form action="funciones.php">
                    <input type="submit" name="salir" value="Volver">
                </form>            
            </div>
        </div>
        <!-- FIN aside -->
        
        <!-- Content - article --> 
        <div id="content">
            <h1>Funciones: paso de parámetros</h1>
            <p>Programa principal, antes de invocar a la función: <?php print color("\$a=$a  \$b=$b")?></p>
            <p><?php //funcion($a, $b); 
                //Pasar a la funcion parametros por (referencia y valor)
                funcion(7, $b); print $antes?></p>
            <p><?php //funcion($a, $b);
                funcion(7, $b); print $despues?></p>
            <p>Programa principal, después de infocar a la función: <?php print var_global($a, $b)?></p>
        </div>        
    </body>
</html>