<?php 
    /* Operador Ternario en php
        - Usando el operador ternario obtén un número aleatorio de 1 a 1000 y 
            visualiza con un texto si el número es par o impar .
        - Volver al index después de 2 segundos
    */
    $n = rand(1, 1000);
    
    $n%2==0? $txt="El nº $n es par": $txt="El nº $n es impar";
    

    // Clic en el BTN (Volver)
    if (isset($_GET['salir'])) {
        /*
        header("Refresh:2; url=http://localhost/UND1_practica1PHP/index.php");
        echo "En 2 segundos volveras a INICIO";            
        exit(); 
        */
        header("Refresh:0; url=http://localhost/UND1_practica1PHP/return.php?info=2");
    }   
?>

<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="UTF-8">
        <title>Operador Ternario</title>
        <link rel="stylesheet" type="text/css" href="../style.css">
    </head>
    <body>
        <!-- aside -->
        <div id="aside">
            <div>
                <h2>Operador Ternario</h2>
                <p>Genera un núemro aleatorio.</p>
                <p>Evalúa con un operador ternario si es par o no.</p>
                <p>Informa de ello con un mensaje.</p>
            </div>
        
            <div id="btn">
                <form>
                    <input type="submit" name="salir" value="Volver">
                </form>            
            </div>
        </div>
        <!-- FIN aside -->
        
        <!-- Content - article --> 
        <div id="content">
            <h1>Operador Ternario</h1>
            <p><?php print $txt ?></p>
            <p><a href="">Probar otro número</a></p>
        </div>        
    </body>
</html>