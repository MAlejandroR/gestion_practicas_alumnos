<?php 
    /* Iteraciones en php:
        - Suma los 100 primeros números pares
        - Volver al index después de 2 segundos
    */
    $n = 100;
    $suma = 0;
    
    // Suma de los 100 numeros pares...
    for ($index = 0; $index < $n; $index++) {
        if ($index%2 == 0) {
            // Hay un posible error no contamos el nº 100 seria añadir un <= en el for...
            // Lo dejo asi para obtener el mismo resultado 2450 y (NO 2550)...
            $suma += $index;
        }        
    }

    // Estilo al resultado
    function color($v) {
        $txt = "<span style='color:blue'><b>$v</b></span>";
        return $txt;
    }
    
    // Clic en el BTN (Volver)
    if (isset($_GET['salir'])) {
        /*
        header("Refresh:2; url=http://localhost/UND1_practica1PHP/index.php");
        echo "En 2 segundos volveras a INICIO";            
        exit();
        */
        header("Refresh:0; url=http://localhost/UND1_practica1PHP/return.php?info=2");
    }   
?>

<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="UTF-8">
        <title>Iteraciones en php</title>
        <link rel="stylesheet" type="text/css" href="../style.css">
    </head>
    <body>
        <!-- aside -->
        <div id="aside">
            <div>
                <h2>Iteraciones tipo switch</h2>
                <p>Suma los 100 primeros números pares.</p>
                <p>Muestro el resultado</p>
            </div>
        
            <div id="btn">
                <form action="">
                    <input type="submit" name="salir" value="Volver">
                </form>            
            </div>
        </div>
        <!-- FIN aside -->
        
        <!-- Content - article --> 
        <div id="content">
            <h1>Iteraciones en php</h1>
            <p>La suma de los 100 primeros números pares es <?php print color($suma)?></p>
        </div>        
    </body>
</html>