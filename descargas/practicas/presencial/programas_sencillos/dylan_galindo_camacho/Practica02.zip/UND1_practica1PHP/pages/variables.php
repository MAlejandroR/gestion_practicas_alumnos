<?php
    /* Declaración de variables de la sección de actividades modificando
        - Cambia el valor de las variables
        - Visualiza con print en lugar que con echo
        - Volver al index después de 5 segundos
     * 
     * <td><?php const oct="0274"; print "\$v=".oct?></td>
                    <td>Variable <b>octal</b>, valor <b>decimal </b><?php $v = octdec(oct); //nº octal(str) a decimal
                        print color($v)?> y en <b>octal </b><?php print color(decoct($v))?></td>
    */

    $v = 125;
    //$txt = "<span style='color:blue'><b>$v</b></span>";
    function color($v) {
        $txt = "<span style='color:blue'><b>$v</b></span>";
        return $txt;
    }
    
    // Funcion para obtener el tipo de variable...
    function tipo($var) {
        return "gettype(".gettype($var).")";
    }
    
    // Clic en el BTN (Volver)
    if (isset($_GET['salir'])) {
        /*
        header("Refresh:5; url=http://localhost/UND1_practica1PHP/index.php");
        echo "En 5 segundos volveras a INICIO";            
        exit();
        */
        header("Refresh:0; url=http://localhost/UND1_practica1PHP/return.php?info=5");
    }
    
?>

<!doctype html>
<html lang="es">
    <head>
        <meta charset="UTF-8">
        <title>Variables en php</title>
        <link rel="stylesheet" type="text/css" href="../style.css">
    </head>
    <body>
        <!-- aside -->
        <div id="aside">
            <div>
                <h2>Mostrando variables</h2>
                <div>
                    <p><b>Valores asignados</b> son los asignaciones realizadas en el progreama php </p>
                    <p><b>Mostrando valores</b> muestra el valor de la variable y el valor convertido a la representación deseada</p>
                </div>
            </div>
        
            <div id="btn">
                <form action="variables.php">
                    <input type="submit" name="salir" value="Volver">
                </form>    
            </div>
        </div>
        <!-- FIN aside -->
        
        <!-- Content - article --> 
        <div id="content">
            <h1>Variables en php</h1>
            <table border="1">
                <thead>
                    <tr>
                        <th>Valores Asignados</th>
                        <th>Mostrando Valores</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><?php print "\$v=$v" ?></td>
                        <td>Variable <strong>decimal</strong> <?php echo tipo($v)?>, valor 
                            -<?php print"<span style='color:blue'><b>$v</b></span>" ?>-</td>
                    </tr>
                    <tr>
                        <td><?php $v="0274"; print "\$v=".$v?></td>
                        <td>Variable <strong>octal</strong> <?php echo tipo(octdec($v))?>, valor <strong>decimal</strong> <?php echo tipo(octdec($v))?>
                            -<?php $v = octdec($v); //nº octal(str) a decimal
                            print color($v)?>- y en <strong>octal</strong> <?php echo tipo($v)?> -<?php print color(decoct($v))?>-</td>
                    </tr>
                    <tr>
                        <td><?php $v="0xABC12"; print "\$v=$v"?></td>
                        <td>Variable <strong>hexadecimal</strong> <?php echo tipo(hexdec($v))?>, valor <strong>decimal</strong> <?php echo tipo(hexdec($v))?>
                            -<?php $v = hexdec($v); //nº hexadecimal a decimal
                            print color($v)?>- y en <strong>hexadecimal</strong> <?php echo tipo($v)?> -<?php print color(dechex($v))?>-</td>
                    </tr>
                    <tr>
                        <td><?php $v="01100"; print "\$v=$v"?></td>
                        <td>Variable <strong>binaria</strong> <?php echo tipo(bindec($v)); // bindec = binario -> decimal, esta String pues lo deja en decimal...?>, 
                            valor <strong>decimal</strong> <?php echo tipo(bindec($v))?>
                            -<?php $v = bindec($v); //nº binario a decimal
                            print color($v) ?>- y en <strong>binario</strong> <?php echo tipo($v)?> -<?php print color(decbin($v))?>-</td>
                    </tr>
                    <tr>
                        <td><?php $v = 1.2343223000332; print "\$v=".$v ?></td>
                        <td>Variable <strong>float</strong> <?php echo tipo($v)?>, valor -<?php print color($v)?>- y en <strong>notación científica</strong>
                            es -<?php print color(sprintf('%.6E', $v)) ?>-</td>
                    </tr>
                    <tr>
                        <td><?php $v = "1.234000e+1"; print "\$v=$v"?></td>
                        <td>Variable <strong>float</strong> <?php echo tipo((float)$v)?>, valor -<?php $v = (float)$v; print color($v)?>- y en 
                            <strong>notación científica</strong> es -<?php print color(sprintf('%.6E', $v)) ?>-</td>
                    </tr>
                    <tr>
                        <td><?php $v=null; 
                        if (is_null($v)) 
                            print "\$v=null";
                        else
                            print "\$v=$v";
                                ?></td>
                        <td>Variable <strong>null</strong> <?php echo tipo($v)?> es -<?php print color($v) ?>- y en <strong>string</strong> <?php echo tipo((string)$v)?> es 
                            -<?php 
                            if (is_null($v)) 
                                print color("null");
                            else
                                print color($v); ?>-</td>
                    </tr>
                    <tr>
                        <td><?php $v=true;
                            if ($v)
                                print "\$v=true";
                            else
                                print "\$v=false";
                        ?></td>
                        <td>Variable <strong>boolean</strong> <?php echo tipo($v)?>, valor -<?php print color($v)?>- y en <strong>string</strong> <?php echo tipo((string)$v)?> es 
                            -<?php 
                                if ($v)
                                    print color("true");
                                else
                                    print color("false");
                            ?>-</td>
                    </tr>
                    <tr>
                        <td><?php $v=false;
                            if ($v)
                                print "\$v=true";
                            else
                                print "\$v=false";
                        ?></td>
                        <td>Variable <strong>boolean</strong> <?php echo tipo($v)?>, valor -<?php print color($v)?>- y en <strong>string</strong> <?php echo tipo((string)$v)?> es 
                            -<?php 
                                if ($v)
                                    print color("true");
                                else
                                    print color("false");
                            ?>-</td>
                        </tr>
                    <tr>
                        <td><?php $v = "Esto es una cadena de caracteres"; print "\$v=\"$v\"" ?></td>
                        <td>Variable <strong>string</strong> <?php echo tipo($v)?>, valor -<?php print color($v)?>-</td>
                    </tr>
                    <tr>
                        <td><?php $v = 'Esto es una cadena de caracteres'; print "\$v='$v'" ?></td>
                        <td>Variable <strong>string</strong> <?php echo tipo($v)?>, valor -<?php print color($v)?>-</td>
                    </tr>
                    <tr>
                        <td><?php 
                        $v=<<< FIN
Esto que ves, 
 es una cadena
multilínea
y termina aquí
FIN;

                        print "\$v=<<< FIN <br><pre>".$v."<br></pre>FIN;"
                        ?></td>
                        <td>Variable <strong>string</strong> <?php echo tipo($v)?>, valor -<?php print color($v)?>-</td>
                    </tr>
                    <tr>
                        <td><?php
                        print "\$v=<<< FIN <br>"; 
                        $v=<<< FIN
<pre>
Esto que ves, 
 es una cadena
multilínea
y termina aquí
</pre>
FIN;
                        print htmlspecialchars("<pre>");
                        print $v;
                        print htmlspecialchars("</pre>");
                        print "<br>FIN;"
                        ?>
                        </td>
                        <td>Variable <strong>string</strong> <?php echo tipo($v)?>, valor -<?php print color($v) ?>-</td>
                    </tr>
                    
                </tbody>
            </table>
        </div>
    </body>
</html>
