<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Práctica1</title>
        <link rel="stylesheet" href="estilos.css">
    </head>
    <body>
        <div id="contenedor">
            <div id="contTit">
                <h1>Lista de programas básicos de pruebas</h1>
            </div>
            <div id="contList">
                <div id="lista">
                    <ul>
                        <li><a href="variables.php">Variables en php</a></li>
                        <li><a href="constantes.php">Constantes en php</a></li>
                        <li><a href="asignacion.php">Asignación en php</a></li>
                        <li><a href="seleccion.php">Selección en php</a></li>
                        <li><a href="ternario.php">Operador ternario en php</a></li>
                        <li><a href="iteraciones.php">Iteraciones en php</a></li>
                        <li><a href="funciones.php">Funciones</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </body>
</html>
