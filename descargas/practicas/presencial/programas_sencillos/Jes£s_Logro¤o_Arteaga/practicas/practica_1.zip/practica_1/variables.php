<!DOCTYPE html>
<?php
$v1 = 100;
$v2 = "0475";
$v3 = "0xAyu12";
$v4 = 0b0101;
$v5 = "Esto es una cadena de caracteres";
$v6 = 'Esto es otra cadena de caracteras';
$v7 = "Esto es una cadena<br>multilinea<br>y termina aquí";
$v8 = 1.234322300033220142039290313;
$v9 = 1234E-2;
$v10 = null;
$v11 = true;
$v12 = false;
?>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <fieldset>
            <legend> <h1>Ejercicio 1.-Declaracion de variables</h1></legend>

            <h3>Este programa asignará valores a variables y luego lo visualizará </h3>
            <?php
            print("El valor de \$v1 es $v1<br>");
            print("El valor de \$v2 es $v2<br>");
            print("El valor de \$v3 es $v3<br>");
            print("El valor de \$v4 es $v4<br>");
            print("El valor de \$v5 es $v5<br>");
            print("El valor de \$v6 es $v6<br>");
            print("El valor de \$v7 es $v7<br>");
            print("El valor de \$v8 es $v8<br>");
            print("El valor de \$v9 es $v9<br>");
            print("El valor de \$v10 es $v10<br>");
            header("refresh:8; url=index.php");
            ?>






        </fieldset>

    </body>
</html>
