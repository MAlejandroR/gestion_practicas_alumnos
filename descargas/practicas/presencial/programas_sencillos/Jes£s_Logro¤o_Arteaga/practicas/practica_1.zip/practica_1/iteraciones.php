<!DOCTYPE html>
 <?php
     $suma=0; 
 header("refresh:6; url=index.php");
        ?>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <h1>6.-Iteraciones en php</h1><br>
        <h3>Sumo los 100 primeros números pares:</h3><br>
        <?php
       for($n=0;$n<=100;$n++){
           echo"Sumo el numero ".($n*2)." y llevo un total de ".($suma=$suma+$n*2)."<br>";
           
       }
       echo"La suma total es ".$suma;
        ?>
    </body>
</html>
