<!DOCTYPE html>
<?php
$edad = rand(0, 150);
if ($edad <= 11){

$msj = "Eres un niño";
} elseif($edad <= 17){
$msj = "Eres un adolescente";    
}elseif($edad <= 35){
$msj = "Eres Joven";}
elseif($edad <= 65){
$msj = "Eres un adulto";}
elseif($edad <= 110){
$msj = "Eres juvilado";}
else{
$msj="Edad no contemplada en nuestra encuesta";
}
 header("refresh:5; url=index.php");
?>


<html>
<head>
<meta charset = "UTF-8">
<title></title>
</head>
<body>
<fieldset>
            <legend> <h1>Ejercicio 4.-Seleción en php</h1></legend>
            <?php 
            echo "Tienes una edad de ".$edad.". ".$msj
            ?>
</fieldset>
   
</body>
</html>
