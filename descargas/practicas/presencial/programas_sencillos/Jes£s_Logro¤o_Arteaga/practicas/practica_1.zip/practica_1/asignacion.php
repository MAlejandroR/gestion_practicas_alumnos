<!DOCTYPE html>
<?php
$v1 = 2;
$v2 = "Hola a todos";
$v3 = 052;
$v4 = 0101;
$v5 = 2 + 3 * 4;
$nombre = "Jesus";
$v6 = "Hola mi nombre es " . $nombre;
$v7 = print($v1);//Me lo imprime por pantalla
$v8 = $v2;
?>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <fieldset>
            <legend><h1>3.-Asignación en php</h1></legend>
            <?php
            echo"La variable [\$v1 = 2] es de tipo " . gettype($v1) . " y tiene un valor de " . $v1."<br>";
            echo"La variable [\$v2 = \"Hola a todos\"] es de tipo " . gettype($v2) . " y tiene un valor de " . $v2."<br>";
            echo"La variable [\$v3 = 052] es de tipo " . gettype($v3) . " y tiene un valor de " . $v3."<br>";
            echo"La variable [\$v4 = 0101] es de tipo " . gettype($v4) . " y tiene un valor de " . $v4."<br>";
            echo"La variable [\$v5 = 2 + 3 * 4] es de tipo " . gettype($v5) . " y tiene un valor de " . $v5."<br>";
            echo"La variable [\$v6 = \"Hola mi nombre es \" . \$nombre] es de tipo " . gettype($v6) . " y tiene un valor de " . $v6."<br>";
            echo"La variable [\$v7 = print($v1)] es de tipo " . gettype($v7) . " y tiene un valor de " . $v7."<br>";
            echo"La variable [\$v8 = \$v2] es de tipo " . gettype($v8) . " y tiene un valor de " . $v8."<br>";
             header("refresh:5; url=index.php");
            ?>
        </fieldset>
       
    </body>
</html>
