<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <fieldset>
            <legend> <h1>Ejercicio 2.-Constantes en php</h1></legend>
            <?php
            const EDAD = 26;
            echo "Tengo " . EDAD . " años, me quedan " . (100 - EDAD) . " para llegar a los 100";
            header("refresh:3; url=index.php");
            ?>
    </body>
</html>
