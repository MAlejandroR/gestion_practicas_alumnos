<!DOCTYPE html>
     <?php
  $num=rand(1,1000);
  $msj= $num%2==0? $msj='par':$msj='impar';
  header("refresh:3; url=index.php");
        ?>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <fieldset>
            <legend><h1>5.-Operador Ternario en php</h1></legend>
   <?="El número ".$num." es ".$msj;?>
            </fieldset>
        
    </body>
</html>
