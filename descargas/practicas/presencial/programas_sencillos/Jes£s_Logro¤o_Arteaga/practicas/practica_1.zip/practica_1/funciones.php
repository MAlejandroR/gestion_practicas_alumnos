<!DOCTYPE html>
<?php
        function doble($a,$b){
           return "Los parametros introducidos en la funcion son ".$a.", ".$b." , esta función devuelve el doble de ambos números: ".($a*2).", ".($b*2)."<br>";
        }
        
        function elMayor($a,$b){
            if($a>$b)return$a;
            else return$b;
        }
        header("refresh:5; url=index.php");
        ?>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <fieldset>
            <legend><h1>7.-Funciones en php</h1></legend>
            
            <?php 
            $a=2;$b=7;
            $msj=doble($a,7);//Siguiendo el enunciado lo paso por referencia y por valor
            echo"Los valores de \$a y \$b son: ".$a.", ".$b."<br>";
            echo$msj; 
            echo "Los parametros introducidos en la funcion son ".$a.", ".$b." , esta función devuelve el mayor número: ".elMayor($a,7);
            ?>
            
            
            
        </fieldset>
        
    </body>
</html>
