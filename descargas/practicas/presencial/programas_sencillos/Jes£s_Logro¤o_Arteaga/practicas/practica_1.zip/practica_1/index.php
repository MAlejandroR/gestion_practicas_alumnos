<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>LISTA DE PROGRAMAS BASICOS DE PRUEBA</title>
    </head>
    <body>
        <h1>LISTA DE PROGRAMAS BASICOS DE PRUEBA</h1>
        <a href="variables.php"><h2>VARIABLES EN PHP</h2></a><br>
        <a href="constantes.php"><h2>CONSTANTES EN PHP</h2></a><br>
        <a href="asignacion.php"><h2>ASIGNACION EN PHP</h2></a><br>
        <a href="seleccion.php"><h2>SELECCION EN PHP</h2></a><br>
        <a href="ternario.php"><h2>OPERADOR TERNARIO EN PHP</h2></a><br>
        <a href="iteraciones.php"><h2>ITERACIONES EN PHP</h2></a><br>
        <a href="funciones.php"><h2>FUNCIONES EN PHP</h2></a><br>
    </body>
</html>
