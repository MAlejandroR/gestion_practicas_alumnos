<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        //Defino dos variables con mi nombre y apellido
 $nombre="Jesús";
 $apellido="Logroño";
//Visualizo el texto con echo y print, por ejemplo en mi caso (deben de aparecer las comillas del ejemplo
// mi nombre es "Manuel" y mi apellido es "Romero"
 echo "mi nombre es \"".$nombre."\" y mi apellido es \"".$apellido."\"<br>";
//1)con echo pasando varios argumentos (separadados por coma)
 echo($nombre." "),($apellido),("<br>");
 
//2)con print
 print($nombre." ".$apellido."<br>");
//3,4 y 5)Explica en el fichero diferencias entre echo y print y semejanzas.
 echo"Las dos funciones tienen el mismo cometido, mostrar por pantalla variables o cadenas. Con la funcion echo podemos incluir varias cadenas o variables pasadas a modo de parametros separadas con comas. La función print es menos usada, su peculiaridad es que devuelve un valor booleano indicando si ha tenido exito.<br>";
//6) Indica Por qué puedes pasar los argumentos sin usar paréntesis
 echo"Esto se debe a que la orden echo no es una función como tal, sino que forma parte del lenguaje de php.<br>";
 
/*7) Sintaxis heredoc,*/
//Asigna a una variable llamada informe un texto de cinco líneas,
//la etiqueta de finalización es FIN
//Posteriormente visualizas el texto
// El contenido de 'informe' es:
//   ........
// aquí aparecer el contenido del informe
// debe de respetarse el número de 5 líneas asignadas previamente";
//Tener cuidado con que la etiqueta no lleve en esa línea ningún otro carácter (espacios en blanco o tabulacones)
 $informe = <<<FINAL
<br> <br><br><br><br>            
FINAL;
 echo"El contenido del 'informe' es: ".$informe;
 
 
 
/*PROBANDO VARIABLES (del 8 al 19)*/
//Crea una variable y asígnale un valor
 $a=2;
//visualiza el valor de la variable y el tipo que eś
 echo"El valor de la variable es ".$a." y es de tipo ".gettype($a)."<br>";
//Cambia la variable a los siguientes tipos :boolean, float, string y null,  y visualizar su valor y tipo 
 $b=(boolean)$a;
 echo"El tipo de la variable es: ". gettype($b).", y su valor: ".$b."<br>";
 $b=(float)$a;
 echo"El tipo de la variable es: ". gettype($b).", y su valor: ".$b."<br>";
 $b=(string)$a;
 echo"El tipo de la variable es: ". gettype($b).", y su valor: ".$b."<br>";
 $b=null;
 echo"El tipo de la variable es: ". gettype($b).", y su valor: ".$b."<br>";
//Prueba a ver el valor y tipo de una variable no definida previamente
 echo"El tipo de la variable no definida es: ". gettype($y).", y su valor: ".$y."<br>";
 
 
/* 20)Visualiza el código ascii del valor 64 al 122 en carácter usando la función ascii  .. puedes usar la función printf o  bien char() ..*/
 for($n=64;$n<=122;$n++){
  printf("El valor del codigo ascii con el numero $n es ".chr($n)."<br>");   
     
     
 }
 
//21)Visualiza el contenido de la función time() y explica su valor
 echo time()," Devuelve el momento actual medido como el número de segundos desde la Época Unix (1 de Enero de 1970 00:00:00 GMT).<br>" ;
//22)Obtén la fecha actual y visualiza su valor con formato dia-mes-año en número usa la función date() para ello
 
 
//23,24,y 25)Obtener los días, luego horas y luego minutos transcurridos desde el 1/1/1970 (round() o floor() para redondear
 echo "Minutos transcurridos desde el 1/1/1970: ".(round(time()/60))."<br>";
 echo "Horas transcurridas desde el 1/1/1970: ".(round(time()/(60*60)))."<br>";
 echo "Dias transcurridos desde el 1/1/1970: ".(round(time()/(60*60*24)))."<br>";
 
//Usando la función setlocale(...) y strftime(...)
//Puede ser que tengas que habilitar el idioma en el sistema con locale-gen
//26)  Obtén la fecha actual con formato por ejemplo domingo, 28 de octubre de 2018
//27)  Ahora con formato en inglés  Sunday, 28 October 2018
//28) y con formato en francés  dimanche, 28 octobre 2018
 setlocale(LC_ALL, "es_ES");
 $fecha = date("D, d m y");
 echo "$fecha<br>";
// 29-30)Asigna a una variable la fecha de tu cumpleaños
// Realiza una operación y obtén tu edad en años, meses y días (valor entero).
// tienes 23 años, 10 meses y 4 días
 $dia=16;
 $mes=8;
 $año=1993;
 echo"Tengo una edad de: ".(2019-$año)."años ".(10-$mes)."meses ".(20-$dia)."dias<br>";
 
 
 
//31-32)Asigna a una variable una fecha de 30/10/1969 (mira las funciones strtotime() o bien mktime() para ello
// Obtén su edad en años, en meses y luego en días siempre redondeando
// tienes xx años
// tienes xx meses
// tienes xx días
 $dia=30;
 $mes=10;
 $año=1969;
 echo"Tengo una edad de: ".(2019-$año-1 )."años ".(10-$mes+12)."meses ".(20-$dia+30)."dias<br>";
 
 
//33-36). Usa la función getdate(...) y visualiza con la función print_r(.) el valor que retorna, comenta el resultado
//. Si escribo getdate(1) podrías explicar el contenido del array que nos retorna
//. Obtener la edad de una persona nacida el 1/1/1969
//37-64)Explica el siguiente código observando el resultado que se produce fuente obtenido en parte de http://php.net/manual/es/function.strtotime.php
echo "<hr>";
echo strtotime("now"), "<br/>";
echo date('d-m-Y', strtotime("now")), "<br/>";
echo strtotime("27 September 1970"), "<br/>";
echo date('d-m-Y',strtotime("10 September 2000")), "<br/>";
echo strtotime("+1 day"), "<br/>";
echo date('d-m-Y',strtotime("+1 day")), "<br/>";
echo strtotime("+1 week"), "<br/>";
echo date('d-m-Y',strtotime("+1 week")), "<br/>";
echo strtotime("+1 week 2 days 4 hours 2 seconds"), "<br/>";
echo date('d-m-Y',strtotime("+1 week 2 days 4 hours 2 seconds")), "<br/>";
echo strtotime("next Thursday"), "<br/>";
echo date('d-m-Y',strtotime("next Thursday")), "<br/>";
echo strtotime("last Monday"), "<br/>";
echo date('d-m-Y',strtotime("last Monday")), "<br/>";
echo "<hr>";

        ?>
    </body>
</html>
