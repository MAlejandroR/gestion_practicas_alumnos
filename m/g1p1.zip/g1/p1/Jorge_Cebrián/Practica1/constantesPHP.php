<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
echo "<h2>Constantes en PHP</h2>";
$edad = 20;
$edadFinal = 100;
echo "Los años que tengo actualmente son: $edad <br>";
echo "Y los que me quedan para cumplir 100 años son: ".($edadFinal- $edad)."<br>";
header("Refresh:2;url=index.php");
?>
<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
    </body>
</html>