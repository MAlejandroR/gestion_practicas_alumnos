
<?php ?>
<!doctype html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Menu</title>
        <style>
            fieldset{
                width: auto;
                float: left;
                margin-left: 20%;
            }
        </style>
    </head>
    <body>
        <fieldset>
            <a href="RepresentacionDeValores.php"> <h3>Variables en php</h3></a>
            <a href="constantes.php"> <h3>Constantes en php</h3></a>
            <a href="asignacion.php"><h3>Asignacion en php</h3></a>
            <a href="seleccion.php"><h3>Seleccion en php</h3></a>
            <a href="operadoresTernarios.php"><h3>OPerador ternario en php</h3></a>
            <a href="iteraciones.php"><h3>iteracion en php</h3></a>
            <a href="funciones.php"><h3>funciones en php</h3></a>
        </fieldset>
      
    </body>
</html>

