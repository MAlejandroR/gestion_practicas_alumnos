<?php
/*
  To change this license header, choose License Headers in Project Properties.
  To change this template file, choose Tools | Templates
  and open the template in the editor.
 */

//Asignamos las siguientes variables a lo s valores mientras las mostramos
//------------------------------------------------------
echo "<h2>Variables en PHP</h2>";
print "La variable \$a vale: ".($a = 125). "<br />";
print "La variable \$b vale: ".($b = 0574). "<br />";
print "La variable \$c vale: ".($c = 0xAbC12). "<br />";
print "La variable \$d vale: ".($d = 0b1100). "<br />";
print "La variable \$e vale: ".($e = "Esto es una cadena de caracteres"). "<br />";
print "La variable \$f vale: ".($f = 'Esto es otra cadena de caracteres'). "<br />";
print "La variable \$g vale: ".($g = 1.23432230003322014000002234101). "<br />";
print "La variable \$h vale: ".($h = 1234E-2). "<br />";
print "La variable \$i vale: ".($i = null). "<br />";
print "La variable \$j vale: ".($j = true). "<br />";
print "La variable \$k vale: ".($k = false). "<br />";

header("Refresh:5;url=index.php");
?>
<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
    </body>
</html>
