<?php ?>

<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>Básico de PHP</title>
        <link rel="stylesheet" href="estilos.css" type="text/css">
    </head>
    <body>
        <fieldset>
            <h1>Lista de programas básico de pruebas</h1>
            <hr />
            <a href="variables.php"><h3>Variables en php</h3></a>
            <a href="constantes.php"><h3>Constantes en php</h3></a>
            <a href="asignacion.php"><h3>Asignación en php</h3></a>
            <a href="seleccion.php"><h3>Selección en php</h3></a>
            <a href="ternario.php"><h3>Operador ternario en php</h3></a>
            <a href="iteraciones.php"><h3>Iteraciones en php</h3></a>
            <a href="funciones.php"><h3>Funciones en php</h3></a>
        </fieldset>
    </body>
</html>
