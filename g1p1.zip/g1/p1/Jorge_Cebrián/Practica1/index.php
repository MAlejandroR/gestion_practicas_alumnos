<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <h2>Lista de programas básico de pruebas</h2>
        <a href=variablesPHP.php>Variables en php</a><br>
        <a href=constantesPHP.php>Constantes en php</a><br>
        <a href=asignacionPHP.php>Asignación en php</a><br>
        <a href=seleccionPHP.php>Selección en php</a><br>
        <a href =./operadorTernarioPHP.php>Operador Ternario en php</a><br>
        <a href=./iteracionesPHP.php>Iteraciones en php</a><br>
        <a href=./funciones.php>Funciones</a>
    </body>
</html>
